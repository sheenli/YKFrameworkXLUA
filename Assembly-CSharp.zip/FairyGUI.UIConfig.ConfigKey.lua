---@class FairyGUI.UIConfig.ConfigKey : System.Enum
---@field public DefaultFont FairyGUI.UIConfig.ConfigKey @static
---@field public ButtonSound FairyGUI.UIConfig.ConfigKey @static
---@field public ButtonSoundVolumeScale FairyGUI.UIConfig.ConfigKey @static
---@field public HorizontalScrollBar FairyGUI.UIConfig.ConfigKey @static
---@field public VerticalScrollBar FairyGUI.UIConfig.ConfigKey @static
---@field public DefaultScrollStep FairyGUI.UIConfig.ConfigKey @static
---@field public DefaultScrollBarDisplay FairyGUI.UIConfig.ConfigKey @static
---@field public DefaultScrollTouchEffect FairyGUI.UIConfig.ConfigKey @static
---@field public DefaultScrollBounceEffect FairyGUI.UIConfig.ConfigKey @static
---@field public TouchScrollSensitivity FairyGUI.UIConfig.ConfigKey @static
---@field public WindowModalWaiting FairyGUI.UIConfig.ConfigKey @static
---@field public GlobalModalWaiting FairyGUI.UIConfig.ConfigKey @static
---@field public PopupMenu FairyGUI.UIConfig.ConfigKey @static
---@field public PopupMenu_seperator FairyGUI.UIConfig.ConfigKey @static
---@field public LoaderErrorSign FairyGUI.UIConfig.ConfigKey @static
---@field public TooltipsWin FairyGUI.UIConfig.ConfigKey @static
---@field public DefaultComboBoxVisibleItemCount FairyGUI.UIConfig.ConfigKey @static
---@field public TouchDragSensitivity FairyGUI.UIConfig.ConfigKey @static
---@field public ClickDragSensitivity FairyGUI.UIConfig.ConfigKey @static
---@field public ModalLayerColor FairyGUI.UIConfig.ConfigKey @static
---@field public RenderingTextBrighterOnDesktop FairyGUI.UIConfig.ConfigKey @static
---@field public AllowSoftnessOnTopOrLeftSide FairyGUI.UIConfig.ConfigKey @static
---@field public InputCaretSize FairyGUI.UIConfig.ConfigKey @static
---@field public InputHighlightColor FairyGUI.UIConfig.ConfigKey @static
---@field public RightToLeftText FairyGUI.UIConfig.ConfigKey @static
---@field public PleaseSelect FairyGUI.UIConfig.ConfigKey @static
---@field public value__ number
local m = {}

FairyGUI.UIConfig.ConfigKey = m
return m
