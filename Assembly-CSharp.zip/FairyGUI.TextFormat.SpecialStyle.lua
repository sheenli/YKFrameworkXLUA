---@class FairyGUI.TextFormat.SpecialStyle : System.Enum
---@field public None FairyGUI.TextFormat.SpecialStyle @static
---@field public Superscript FairyGUI.TextFormat.SpecialStyle @static
---@field public Subscript FairyGUI.TextFormat.SpecialStyle @static
---@field public value__ number
local m = {}

FairyGUI.TextFormat.SpecialStyle = m
return m
