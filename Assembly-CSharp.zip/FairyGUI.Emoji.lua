---@class FairyGUI.Emoji : System.Object
---@field public url string
---@field public width number
---@field public height number
local m = {}

FairyGUI.Emoji = m
return m
