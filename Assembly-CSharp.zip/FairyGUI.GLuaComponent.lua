---@class FairyGUI.GLuaComponent : FairyGUI.GComponent
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaComponent = m
return m
