---@class FairyGUI.GLuaSlider : FairyGUI.GSlider
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaSlider = m
return m
