---@class GroupProgress : System.ValueType
---@field public groupName string
---@field public allCount number
---@field public currentCout number
---@field public Progress number
local m = {}

GroupProgress = m
return m
