---@class Sproto.SprotoRpc : System.Object
local m = {}

---@overload fun():Sproto.SprotoRpc.RpcRequest
---@param protocolObj Sproto.ProtocolBase
---@return Sproto.SprotoRpc.RpcRequest
function m:Attach(protocolObj) end

---@overload fun(buffer:string):Sproto.SprotoRpc.RpcInfo
---@param buffer string
---@param offset number
---@return Sproto.SprotoRpc.RpcInfo
function m:Dispatch(buffer, offset) end

Sproto.SprotoRpc = m
return m
