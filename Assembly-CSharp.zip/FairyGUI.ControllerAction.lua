---@class FairyGUI.ControllerAction : System.Object
---@field public fromPage string[]
---@field public toPage string[]
local m = {}

---@static
---@param type string
---@return FairyGUI.ControllerAction
function m.CreateAction(type) end

---@param controller FairyGUI.Controller
---@param prevPage string
---@param curPage string
function m:Run(controller, prevPage, curPage) end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

FairyGUI.ControllerAction = m
return m
