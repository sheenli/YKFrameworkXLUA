---@class FairyGUI.StageCamera : UnityEngine.MonoBehaviour
---@field public main UnityEngine.Camera @static
---@field public screenSizeVer number @static
---@field public Name string @static
---@field public LayerName string @static
---@field public DefaultCameraSize number @static
---@field public UnitsPerPixel number @static
---@field public constantSize boolean
---@field public cachedTransform UnityEngine.Transform
---@field public cachedCamera UnityEngine.Camera
local m = {}

function m:ApplyModifiedProperties() end

---@static
function m.CheckMainCamera() end

---@static
function m.CheckCaptureCamera() end

---@static
---@param name string
---@param cullingMask number
---@return UnityEngine.Camera
function m.CreateCamera(name, cullingMask) end

FairyGUI.StageCamera = m
return m
