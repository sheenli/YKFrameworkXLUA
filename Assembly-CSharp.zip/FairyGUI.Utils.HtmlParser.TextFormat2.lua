---@class FairyGUI.Utils.HtmlParser.TextFormat2 : FairyGUI.TextFormat
---@field public colorChanged boolean
local m = {}

FairyGUI.Utils.HtmlParser.TextFormat2 = m
return m
