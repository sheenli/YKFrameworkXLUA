---@class FlyingWormConsole3.ConsoleProRemoteServer : UnityEngine.MonoBehaviour
---@field public port number
---@field public logs FlyingWormConsole3.ConsoleProRemoteServer.QueuedLog[]
local m = {}

---@param logString string
---@param stackTrace string
---@param type UnityEngine.LogType
function m:LogCallback(logString, stackTrace, type) end

FlyingWormConsole3.ConsoleProRemoteServer = m
return m
