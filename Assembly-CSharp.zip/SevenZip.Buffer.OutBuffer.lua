---@class SevenZip.Buffer.OutBuffer : System.Object
local m = {}

---@param stream System.IO.Stream
function m:SetStream(stream) end

function m:FlushStream() end

function m:CloseStream() end

function m:ReleaseStream() end

function m:Init() end

---@param b number
function m:WriteByte(b) end

function m:FlushData() end

---@return number
function m:GetProcessedSize() end

SevenZip.Buffer.OutBuffer = m
return m
