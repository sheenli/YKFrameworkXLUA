---@class GameServerMsg : System.Object
---@field public pack NetPackage
---@field public resultData string
local m = {}

GameServerMsg = m
return m
