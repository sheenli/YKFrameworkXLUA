---@class FairyGUI.UIContentScaler.ScaleMode : System.Enum
---@field public ConstantPixelSize FairyGUI.UIContentScaler.ScaleMode @static
---@field public ScaleWithScreenSize FairyGUI.UIContentScaler.ScaleMode @static
---@field public ConstantPhysicalSize FairyGUI.UIContentScaler.ScaleMode @static
---@field public value__ number
local m = {}

FairyGUI.UIContentScaler.ScaleMode = m
return m
