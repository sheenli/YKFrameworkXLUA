---@class FairyGUI.DynamicFont.RenderInfo : System.Object
---@field public yIndent number
---@field public height number
local m = {}

FairyGUI.DynamicFont.RenderInfo = m
return m
