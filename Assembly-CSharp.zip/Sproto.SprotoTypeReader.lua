---@class Sproto.SprotoTypeReader : System.Object
---@field public Buffer string
---@field public Position number
---@field public Offset number
---@field public Length number
local m = {}

---@param buffer string
---@param offset number
---@param size number
function m:Init(buffer, offset, size) end

---@return number
function m:ReadByte() end

---@param offset number
function m:Seek(offset) end

---@param data string
---@param offset number
---@param size number
function m:Read(data, offset, size) end

Sproto.SprotoTypeReader = m
return m
