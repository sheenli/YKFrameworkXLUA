---@class FairyGUI.Timers : System.Object
---@field public repeat number @static
---@field public time number @static
---@field public gameObject UnityEngine.GameObject @static
---@field public inst FairyGUI.Timers @static
local m = {}

---@overload fun(interval:number, repeat:number, callback:(fun(param:any)), callbackParam:any)
---@param interval number
---@param repeat number
---@param callback fun(param:any)
function m:Add(interval, repeat, callback) end

---@overload fun(callback:(fun(param:any)), callbackParam:any)
---@param callback fun(param:any)
function m:CallLater(callback) end

---@overload fun(callback:(fun(param:any)), callbackParam:any)
---@param callback fun(param:any)
function m:AddUpdate(callback) end

---@param routine System.Collections.IEnumerator
function m:StartCoroutine(routine) end

---@param callback fun(param:any)
---@return boolean
function m:Exists(callback) end

---@param callback fun(param:any)
function m:Remove(callback) end

function m:Update() end

FairyGUI.Timers = m
return m
