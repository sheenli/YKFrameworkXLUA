---@class ABMgr.PackInfo : System.Object
---@field public abName string
---@field public ab UnityEngine.AssetBundle
---@field public keepInMemory boolean
local m = {}

ABMgr.PackInfo = m
return m
