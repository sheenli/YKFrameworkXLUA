---@class FairyGUI.ShaderConfig : System.Object
---@field public Get fun(name:string):UnityEngine.Shader @static
---@field public imageShader string @static
---@field public textShader string @static
---@field public textBrighterShader string @static
---@field public bmFontShader string @static
local m = {}

---@static
---@param name string
---@return UnityEngine.Shader
function m.GetShader(name) end

FairyGUI.ShaderConfig = m
return m
