---@class SevenZip.ICoder : table
local m = {}

---@abstract
---@param inStream System.IO.Stream
---@param outStream System.IO.Stream
---@param inSize number
---@param outSize number
---@param progress SevenZip.ICodeProgress
function m:Code(inStream, outStream, inSize, outSize, progress) end

SevenZip.ICoder = m
return m
