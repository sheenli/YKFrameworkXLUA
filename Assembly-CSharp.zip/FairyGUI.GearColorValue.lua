---@class FairyGUI.GearColorValue : System.Object
---@field public color UnityEngine.Color
---@field public strokeColor UnityEngine.Color
local m = {}

FairyGUI.GearColorValue = m
return m
