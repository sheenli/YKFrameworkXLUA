---@class LogicNode : UnityEngine.MonoBehaviour
---@field public threadSafe boolean
---@field public NodePriority number
---@field public IsValid boolean
---@field public Parent LogicNode
local m = {}

---@param node LogicNode
function m:AttachNode(node) end

---@param node LogicNode
function m:DetachNode(node) end

---@param logic ILogic
---@return boolean
function m:HasLogic(logic) end

---@param logic ILogic
function m:AttachLogic(logic) end

---@param logic ILogic
function m:DetachLogic(logic) end

---@virtual
function m:OnDestroy() end

---@virtual
function m:OnDisable() end

---@virtual
function m:OnEnable() end

---@virtual
---@param pauseStatus boolean
function m:OnApplicationPause(pauseStatus) end

---@virtual
function m:OnApplicationQuit() end

---@virtual
function m:OnFixedUpdate() end

---@virtual
function m:OnLateUpdate() end

---@virtual
function m:OnUpdate() end

LogicNode = m
return m
