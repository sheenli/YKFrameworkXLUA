---@class EventData_1_System_String_ : EventData
local m = {}

EventData_1_System_String_ = m
return m
