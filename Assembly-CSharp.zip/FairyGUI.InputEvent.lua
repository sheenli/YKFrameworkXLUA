---@class FairyGUI.InputEvent : System.Object
---@field public x number
---@field public y number
---@field public keyCode UnityEngine.KeyCode
---@field public character number
---@field public modifiers UnityEngine.EventModifiers
---@field public mouseWheelDelta number
---@field public touchId number
---@field public button number
---@field public position UnityEngine.Vector2
---@field public isDoubleClick boolean
---@field public ctrl boolean
---@field public shift boolean
---@field public alt boolean
local m = {}

FairyGUI.InputEvent = m
return m
