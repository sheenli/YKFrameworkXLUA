---@class BGMMgr.SoundSourceCtrl.BGMSourceStatus : System.Enum
---@field public FadeIn BGMMgr.SoundSourceCtrl.BGMSourceStatus @static
---@field public FadeOut BGMMgr.SoundSourceCtrl.BGMSourceStatus @static
---@field public Slient BGMMgr.SoundSourceCtrl.BGMSourceStatus @static
---@field public Play BGMMgr.SoundSourceCtrl.BGMSourceStatus @static
---@field public value__ number
local m = {}

BGMMgr.SoundSourceCtrl.BGMSourceStatus = m
return m
