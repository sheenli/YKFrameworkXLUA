---@class FairyGUI.TreeView.TreeNodeRenderDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param node FairyGUI.TreeNode
function m:Invoke(node) end

---@virtual
---@param node FairyGUI.TreeNode
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(node, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.TreeView.TreeNodeRenderDelegate = m
return m
