---@class StateMachine : System.Object
---@field public BetweenSwitchStateCallBack fun(from:IState, to:IState, param1:any, param2:any)
---@field public CurState IState
---@field public CurStateId number
local m = {}

---@param state IState
---@return boolean
function m:RegisterState(state) end

---@param stateId number
---@return boolean
function m:RemoveState(stateId) end

---@param stateId number
---@return IState
function m:GetState(stateId) end

---@overload fun(param1:any)
---@overload fun()
---@param param1 any
---@param param2 any
function m:StopState(param1, param2) end

---@overload fun(newStateId:number, param1:any):boolean
---@overload fun(newStateId:number):boolean
---@param newStateId number
---@param param1 any
---@param param2 any
---@return boolean
function m:SwitchState(newStateId, param1, param2) end

---@param stateId number
---@return boolean
function m:InState(stateId) end

function m:Update() end

function m:FixedUpdate() end

function m:LateUpdate() end

function m:Release() end

StateMachine = m
return m
