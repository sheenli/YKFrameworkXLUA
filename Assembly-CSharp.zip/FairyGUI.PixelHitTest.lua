---@class FairyGUI.PixelHitTest : System.Object
---@field public offsetX number
---@field public offsetY number
---@field public scaleX number
---@field public scaleY number
local m = {}

---@virtual
---@param value boolean
function m:SetEnabled(value) end

---@virtual
---@param container FairyGUI.Container
---@param localPoint UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:HitTest(container, localPoint) end

FairyGUI.PixelHitTest = m
return m
