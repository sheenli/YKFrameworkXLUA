---@class FairyGUI.NGraphics : System.Object
---@field public TRIANGLES number[] @static
---@field public TRIANGLES_9_GRID number[] @static
---@field public TRIANGLES_4_GRID number[] @static
---@field public grayed boolean
---@field public blendMode FairyGUI.BlendMode
---@field public dontClip boolean
---@field public maskFrameId number
---@field public vertexMatrix System.Nullable_1_UnityEngine_Matrix4x4_
---@field public cameraPosition System.Nullable_1_UnityEngine_Vector3_
---@field public meshModifier fun()
---@field public vertices UnityEngine.Vector3[]
---@field public uv UnityEngine.Vector2[]
---@field public colors UnityEngine.Color32[]
---@field public triangles number[]
---@field public vertCount number
---@field public meshFilter UnityEngine.MeshFilter
---@field public meshRenderer UnityEngine.MeshRenderer
---@field public mesh UnityEngine.Mesh
---@field public gameObject UnityEngine.GameObject
---@field public texture FairyGUI.NTexture
---@field public shader string
---@field public material UnityEngine.Material
---@field public materialKeywords string[]
---@field public enabled boolean
---@field public sortingOrder number
---@field public alpha number
local m = {}

---@param shader string
---@param texture FairyGUI.NTexture
function m:SetShaderAndTexture(shader, texture) end

---@param value number
function m:SetStencilEraserOrder(value) end

function m:Dispose() end

---@param context FairyGUI.UpdateContext
function m:UpdateMaterial(context) end

---@param vertCount number
function m:Alloc(vertCount) end

function m:UpdateMesh() end

---@overload fun(vertRect:UnityEngine.Rect, uvRect:UnityEngine.Rect, lineSize:number, lineColor:UnityEngine.Color, fillColor:UnityEngine.Color)
---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param color UnityEngine.Color
function m:DrawRect(vertRect, uvRect, color) end

---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param fillColor UnityEngine.Color
---@param topLeftRadius number
---@param topRightRadius number
---@param bottomLeftRadius number
---@param bottomRightRadius number
function m:DrawRoundRect(vertRect, uvRect, fillColor, topLeftRadius, topRightRadius, bottomLeftRadius, bottomRightRadius) end

---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param fillColor UnityEngine.Color
function m:DrawEllipse(vertRect, uvRect, fillColor) end

---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param points UnityEngine.Vector2[]
---@param fillColor UnityEngine.Color
function m:DrawPolygon(vertRect, uvRect, points, fillColor) end

---@param vertRect UnityEngine.Rect
---@param uvRect UnityEngine.Rect
---@param fillColor UnityEngine.Color
---@param method FairyGUI.FillMethod
---@param amount number
---@param origin number
---@param clockwise boolean
function m:DrawRectWithFillMethod(vertRect, uvRect, fillColor, method, amount, origin, clockwise) end

---@param index number
---@param rect UnityEngine.Rect
function m:FillVerts(index, rect) end

---@param index number
---@param rect UnityEngine.Rect
function m:FillUV(index, rect) end

---@overload fun(value:UnityEngine.Color[])
---@param value UnityEngine.Color
function m:FillColors(value) end

---@overload fun(triangles:number[])
function m:FillTriangles() end

function m:ClearMesh() end

---@param value UnityEngine.Color
function m:Tint(value) end

---@static
---@param verts UnityEngine.Vector3[]
---@param index number
---@param rect UnityEngine.Rect
function m.FillVertsOfQuad(verts, index, rect) end

---@static
---@param uv UnityEngine.Vector2[]
---@param index number
---@param rect UnityEngine.Rect
function m.FillUVOfQuad(uv, index, rect) end

---@static
---@param uv UnityEngine.Vector2[]
---@param baseUVRect UnityEngine.Rect
---@return UnityEngine.Rect
function m.RotateUV(uv, baseUVRect) end

FairyGUI.NGraphics = m
return m
