---@class FairyGUI.Origin180 : System.Enum
---@field public Top FairyGUI.Origin180 @static
---@field public Bottom FairyGUI.Origin180 @static
---@field public Left FairyGUI.Origin180 @static
---@field public Right FairyGUI.Origin180 @static
---@field public value__ number
local m = {}

FairyGUI.Origin180 = m
return m
