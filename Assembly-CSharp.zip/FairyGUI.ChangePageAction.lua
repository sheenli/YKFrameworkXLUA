---@class FairyGUI.ChangePageAction : FairyGUI.ControllerAction
---@field public objectId string
---@field public controllerName string
---@field public targetPage string
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

FairyGUI.ChangePageAction = m
return m
