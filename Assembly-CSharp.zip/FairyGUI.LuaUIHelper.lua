---@class FairyGUI.LuaUIHelper : System.Object
local m = {}

---@static
---@param url string
---@param baseType System.Type
---@param extendFunction XLua.LuaFunction
function m.SetExtension(url, baseType, extendFunction) end

---@static
---@param gcom FairyGUI.GComponent
---@return XLua.LuaTable
function m.ConnectLua(gcom) end

FairyGUI.LuaUIHelper = m
return m
