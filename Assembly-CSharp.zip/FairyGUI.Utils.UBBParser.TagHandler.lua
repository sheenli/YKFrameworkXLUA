---@class FairyGUI.Utils.UBBParser.TagHandler : System.MulticastDelegate
local m = {}

---@virtual
---@param tagName string
---@param _end boolean
---@param attr string
---@return string
function m:Invoke(tagName, _end, attr) end

---@virtual
---@param tagName string
---@param _end boolean
---@param attr string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(tagName, _end, attr, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return string
function m:EndInvoke(result) end

FairyGUI.Utils.UBBParser.TagHandler = m
return m
