---@class NetPushCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param package SocketPackage
function m:Invoke(package) end

---@virtual
---@param package SocketPackage
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(package, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

NetPushCallback = m
return m
