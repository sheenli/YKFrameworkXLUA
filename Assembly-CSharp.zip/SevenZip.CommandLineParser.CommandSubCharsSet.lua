---@class SevenZip.CommandLineParser.CommandSubCharsSet : System.Object
---@field public Chars string
---@field public EmptyAllowed boolean
local m = {}

SevenZip.CommandLineParser.CommandSubCharsSet = m
return m
