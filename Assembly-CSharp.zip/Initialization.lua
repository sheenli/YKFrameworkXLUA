---@class Initialization : EventDispatcherNode
---@field public Instance Initialization @static
---@field public canvas UnityEngine.Canvas
---@field public verText UnityEngine.UI.Text
---@field public mLogo UnityEngine.GameObject
---@field public DebugMode boolean
local m = {}

function m:Awake() end

---@virtual
function m:OnDestroy() end

function m:Update() end

---@param flag boolean
function m:LogValid(flag) end

Initialization = m
return m
