---@class FairyGUI.UpdateContext : System.Object
---@field public current FairyGUI.UpdateContext @static
---@field public frameId number @static
---@field public working boolean @static
---@field public OnBegin fun() @static
---@field public OnEnd fun() @static
---@field public clipped boolean
---@field public clipInfo FairyGUI.UpdateContext.ClipInfo
---@field public renderingOrder number
---@field public batchingDepth number
---@field public rectMaskDepth number
---@field public stencilReferenceValue number
---@field public alpha number
---@field public grayed boolean
local m = {}

function m:Begin() end

function m:End() end

---@param clipId number
---@param clipRect System.Nullable_1_UnityEngine_Rect_
---@param softness System.Nullable_1_UnityEngine_Vector4_
---@param reversedMask boolean
function m:EnterClipping(clipId, clipRect, softness, reversedMask) end

function m:LeaveClipping() end

FairyGUI.UpdateContext = m
return m
