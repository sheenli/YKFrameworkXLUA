---@class FairyGUI.TransitionActionType : System.Enum
---@field public XY FairyGUI.TransitionActionType @static
---@field public Size FairyGUI.TransitionActionType @static
---@field public Scale FairyGUI.TransitionActionType @static
---@field public Pivot FairyGUI.TransitionActionType @static
---@field public Alpha FairyGUI.TransitionActionType @static
---@field public Rotation FairyGUI.TransitionActionType @static
---@field public Color FairyGUI.TransitionActionType @static
---@field public Animation FairyGUI.TransitionActionType @static
---@field public Visible FairyGUI.TransitionActionType @static
---@field public Sound FairyGUI.TransitionActionType @static
---@field public Transition FairyGUI.TransitionActionType @static
---@field public Shake FairyGUI.TransitionActionType @static
---@field public ColorFilter FairyGUI.TransitionActionType @static
---@field public Skew FairyGUI.TransitionActionType @static
---@field public Unknown FairyGUI.TransitionActionType @static
---@field public value__ number
local m = {}

FairyGUI.TransitionActionType = m
return m
