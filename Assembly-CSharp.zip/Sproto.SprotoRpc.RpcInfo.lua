---@class Sproto.SprotoRpc.RpcInfo : System.ValueType
---@field public type Sproto.SprotoRpc.RpcType
---@field public session System.Nullable_1_System_Int64_
---@field public tag System.Nullable_1_System_Int32_
---@field public requestObj Sproto.SprotoTypeBase
---@field public responseObj Sproto.SprotoTypeBase
---@field public Response fun(response:Sproto.SprotoTypeBase):string
local m = {}

Sproto.SprotoRpc.RpcInfo = m
return m
