---@class XLua.Utils.MethodKey : System.ValueType
---@field public Name string
---@field public IsStatic boolean
local m = {}

XLua.Utils.MethodKey = m
return m
