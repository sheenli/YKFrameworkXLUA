---@class AutoLoadAsset : System.Object
---@field public fileName string
---@field public loaded number
---@field public isKeepInMemory boolean
local m = {}

---@virtual
---@param callback fun()
function m:Load(callback) end

AutoLoadAsset = m
return m
