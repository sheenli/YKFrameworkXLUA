---@class FairyGUI.DynamicFont : FairyGUI.BaseFont
local m = {}

---@virtual
---@param format FairyGUI.TextFormat
---@param fontSizeScale number
function m:SetFormat(format, fontSizeScale) end

---@virtual
---@param text string
function m:PrepareCharacters(text) end

---@virtual
---@param ch number
---@return boolean, System.Single, System.Single
function m:GetGlyphSize(ch) end

---@virtual
---@param ch number
---@param glyph FairyGUI.GlyphInfo
---@return boolean
function m:GetGlyph(ch, glyph) end

FairyGUI.DynamicFont = m
return m
