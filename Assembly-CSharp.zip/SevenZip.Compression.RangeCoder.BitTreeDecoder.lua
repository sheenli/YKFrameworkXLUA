---@class SevenZip.Compression.RangeCoder.BitTreeDecoder : System.ValueType
local m = {}

function m:Init() end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@return number
function m:Decode(rangeDecoder) end

---@overload fun(Models:SevenZip.Compression.RangeCoder.BitDecoder[], startIndex:number, rangeDecoder:SevenZip.Compression.RangeCoder.Decoder, NumBitLevels:number):number @static
---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@return number
function m:ReverseDecode(rangeDecoder) end

SevenZip.Compression.RangeCoder.BitTreeDecoder = m
return m
