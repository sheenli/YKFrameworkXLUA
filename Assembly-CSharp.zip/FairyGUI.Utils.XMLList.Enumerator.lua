---@class FairyGUI.Utils.XMLList.Enumerator : System.ValueType
---@field public Current FairyGUI.Utils.XML
local m = {}

---@return boolean
function m:MoveNext() end

function m:Reset() end

FairyGUI.Utils.XMLList.Enumerator = m
return m
