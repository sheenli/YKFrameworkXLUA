---@class EventListenerMgr : System.Object
local m = {}

---@overload fun(dis:EventDispatcherNode, dele:(fun(data:EventData)), type:number, _priority:number)
---@overload fun(dis:EventDispatcherNode, dele:(fun(data:EventData)), type:number)
---@overload fun(dis:EventDispatcherNode, dele:(fun(data:EventData)), type:string, _priority:number, _dispatchOnce:boolean)
---@overload fun(dis:EventDispatcherNode, dele:(fun(data:EventData)), type:string, _priority:number)
---@overload fun(dis:EventDispatcherNode, dele:(fun(data:EventData)), type:string)
---@param dis EventDispatcherNode
---@param dele fun(data:EventData)
---@param type number
---@param _priority number
---@param _dispatchOnce boolean
function m:AddListener(dis, dele, type, _priority, _dispatchOnce) end

---@param dis EventDispatcherNode
---@param dele fun(data:EventData)
---@param type string
function m:DetachListener(dis, dele, type) end

function m:DetachListenerAll() end

EventListenerMgr = m
return m
