---@class FairyGUI.MovieClip : FairyGUI.Image
---@field public interval number
---@field public swing boolean
---@field public repeatDelay number
---@field public frameCount number
---@field public frames FairyGUI.MovieClip.Frame[]
---@field public playState FairyGUI.PlayState
---@field public onPlayEnd FairyGUI.EventListener
---@field public playing boolean
---@field public currentFrame number
local m = {}

---@param texture FairyGUI.NTexture
---@param frames FairyGUI.MovieClip.Frame[]
---@param boundsRect UnityEngine.Rect
function m:SetData(texture, frames, boundsRect) end

function m:Clear() end

---@overload fun(start:number, _end:number, times:number, endAt:number)
function m:SetPlaySettings() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

FairyGUI.MovieClip = m
return m
