---@class FairyGUI.Utils.HtmlParser : System.Object
---@field public inst FairyGUI.Utils.HtmlParser @static
local m = {}

---@virtual
---@param aSource string
---@param defaultFormat FairyGUI.TextFormat
---@param elements FairyGUI.Utils.HtmlElement[]
---@param parseOptions FairyGUI.Utils.HtmlParseOptions
function m:Parse(aSource, defaultFormat, elements, parseOptions) end

FairyGUI.Utils.HtmlParser = m
return m
