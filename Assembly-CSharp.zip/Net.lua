---@class Net : EventDispatcherNode
---@field public Instance Net @static
---@field public pingTime number
---@field public HttpServerUrl string
---@field public timeOut number
---@field public hearInterval number
---@field public RequestNotify fun(eStatus:Net.Status)
---@field public NetErrorCallback fun(nType:Net.eNetError, actionId:number, strMsg:string)
---@field public CommonCallback fun(reader:NetReader):boolean
---@field public HeadFormater IHeadFormater
---@field public NetSuccess number
---@field public EventProority number
local m = {}

---@param package SocketPackage
function m:OnPushCallback(package) end

---@param package NetPackage
---@param bytes string
function m:OnServerResponse(package, bytes) end

---@param eState Net.Status
function m:RequestDelegate(eState) end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnApplicationQuit() end

function m:Close() end

function m:ConnectedServer() end

---@overload fun(actionId:number, actionParam:string)
---@param actionId number
---@param actionParam string
---@param bShowLoading boolean
function m:Send(actionId, actionParam, bShowLoading) end

---@param url string
---@param msgId number
function m:SendHttpGet(url, msgId) end

---@param url string
---@param msgId number
---@param bytes string
function m:SendHttpPost(url, msgId, bytes) end

---@param eventData EventData
function m:HandleEvent(eventData) end

Net = m
return m
