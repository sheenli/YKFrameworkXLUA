---@class GameAction : System.Object
---@field public ActionId number
---@field public Head PackageHead
local m = {}

---@param value fun(obj:ActionResult)
function m:add_Callback(value) end

---@param value fun(obj:ActionResult)
function m:remove_Callback(value) end

---@param bs string
---@return string
function m:Send(bs) end

---@param reader NetReader
---@return boolean
function m:TryDecodePackage(reader) end

---@param result ActionResult
function m:OnCallback(result) end

---@return string
function m:GetResponseData() end

GameAction = m
return m
