---@class Sproto.SprotoTypeDeserialize.gen_key_func_2_TK_TV_ : System.MulticastDelegate
local m = {}

---@virtual
---@param v any
---@return any
function m:Invoke(v) end

---@virtual
---@param v any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(v, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return any
function m:EndInvoke(result) end

Sproto.SprotoTypeDeserialize.gen_key_func_2_TK_TV_ = m
return m
