---@class FairyGUI.TreeNode : System.Object
---@field public data any
---@field public parent FairyGUI.TreeNode
---@field public tree FairyGUI.TreeView
---@field public cell FairyGUI.GComponent
---@field public level number
---@field public expanded boolean
---@field public isFolder boolean
---@field public text string
---@field public numChildren number
local m = {}

---@param child FairyGUI.TreeNode
---@return FairyGUI.TreeNode
function m:AddChild(child) end

---@param child FairyGUI.TreeNode
---@param index number
---@return FairyGUI.TreeNode
function m:AddChildAt(child, index) end

---@param child FairyGUI.TreeNode
---@return FairyGUI.TreeNode
function m:RemoveChild(child) end

---@param index number
---@return FairyGUI.TreeNode
function m:RemoveChildAt(index) end

---@overload fun(beginIndex:number)
---@overload fun()
---@param beginIndex number
---@param endIndex number
function m:RemoveChildren(beginIndex, endIndex) end

---@param index number
---@return FairyGUI.TreeNode
function m:GetChildAt(index) end

---@param child FairyGUI.TreeNode
---@return number
function m:GetChildIndex(child) end

---@return FairyGUI.TreeNode
function m:GetPrevSibling() end

---@return FairyGUI.TreeNode
function m:GetNextSibling() end

---@param child FairyGUI.TreeNode
---@param index number
function m:SetChildIndex(child, index) end

---@param child1 FairyGUI.TreeNode
---@param child2 FairyGUI.TreeNode
function m:SwapChildren(child1, child2) end

---@param index1 number
---@param index2 number
function m:SwapChildrenAt(index1, index2) end

FairyGUI.TreeNode = m
return m
