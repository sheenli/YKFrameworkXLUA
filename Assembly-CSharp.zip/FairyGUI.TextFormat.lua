---@class FairyGUI.TextFormat : System.Object
---@field public size number
---@field public font string
---@field public color UnityEngine.Color
---@field public lineSpacing number
---@field public letterSpacing number
---@field public bold boolean
---@field public underline boolean
---@field public italic boolean
---@field public gradientColor UnityEngine.Color32[]
---@field public align FairyGUI.AlignType
---@field public specialStyle FairyGUI.TextFormat.SpecialStyle
local m = {}

---@param value number
function m:SetColor(value) end

---@param aFormat FairyGUI.TextFormat
---@return boolean
function m:EqualStyle(aFormat) end

---@param source FairyGUI.TextFormat
function m:CopyFrom(source) end

FairyGUI.TextFormat = m
return m
