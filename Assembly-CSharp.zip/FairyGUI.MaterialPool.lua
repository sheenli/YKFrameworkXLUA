---@class FairyGUI.MaterialPool : System.Object
local m = {}

---@return FairyGUI.NMaterial
function m:Get() end

function m:Clear() end

function m:Dispose() end

FairyGUI.MaterialPool = m
return m
