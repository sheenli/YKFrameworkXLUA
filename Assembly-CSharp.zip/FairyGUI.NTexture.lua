---@class FairyGUI.NTexture : System.Object
---@field public Empty FairyGUI.NTexture @static
---@field public nativeTexture UnityEngine.Texture
---@field public alphaTexture FairyGUI.NTexture
---@field public root FairyGUI.NTexture
---@field public uvRect UnityEngine.Rect
---@field public rotated boolean
---@field public materialManagers System.Collections.Generic.Dictionary_2_System_String_FairyGUI_MaterialManager_
---@field public refCount number
---@field public disposed boolean
---@field public lastActive number
---@field public storedODisk boolean
---@field public width number
---@field public height number
local m = {}

---@static
function m.DisposeEmpty() end

function m:DestroyMaterials() end

---@overload fun(allowDestroyingAssets:boolean)
function m:Dispose() end

FairyGUI.NTexture = m
return m
