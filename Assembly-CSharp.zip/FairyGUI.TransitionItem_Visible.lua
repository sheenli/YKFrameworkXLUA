---@class FairyGUI.TransitionItem_Visible : FairyGUI.TransitionItem
---@field public visible boolean
local m = {}

FairyGUI.TransitionItem_Visible = m
return m
