---@class XLua.DelegateBridge : XLua.DelegateBridgeBase
---@field public Gen_Flag boolean @static
local m = {}

XLua.DelegateBridge = m
return m
