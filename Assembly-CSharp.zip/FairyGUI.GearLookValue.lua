---@class FairyGUI.GearLookValue : System.Object
---@field public alpha number
---@field public rotation number
---@field public grayed boolean
---@field public touchable boolean
local m = {}

FairyGUI.GearLookValue = m
return m
