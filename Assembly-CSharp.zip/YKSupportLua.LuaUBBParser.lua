---@class YKSupportLua.LuaUBBParser : FairyGUI.Utils.UBBParser
local m = {}

---@param peerTable XLua.LuaTable
function m:ConnectLua(peerTable) end

---@param key string
function m:AddTag(key) end

YKSupportLua.LuaUBBParser = m
return m
