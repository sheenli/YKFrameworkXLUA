---@class LocalGameCfgData : UnityEngine.ScriptableObject
---@field public openLogKEY string @static
---@field public version string
---@field public isPublic boolean
---@field public chanelType number
---@field public collectionID number
---@field public openLog boolean
---@field public OSSROOT string
---@field public OSSCollectionPath string
---@field public OSSResRootPath string
---@field public RemotelyResUrl string
---@field public CollectionIDVerFileName string
local m = {}

---@static
---@return LocalGameCfgData
function m.Create() end

---@param flag boolean
function m:SetPublic(flag) end

---@param isopen boolean
function m:SetLog(isopen) end

function m:Init() end

LocalGameCfgData = m
return m
