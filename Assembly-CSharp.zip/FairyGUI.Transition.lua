---@class FairyGUI.Transition : System.Object
---@field public autoPlayRepeat number
---@field public autoPlayDelay number
---@field public invalidateBatchingEveryFrame boolean
---@field public name string
---@field public autoPlay boolean
---@field public playing boolean
---@field public timeScale number
local m = {}

---@overload fun(onComplete:(fun()))
---@overload fun(times:number, delay:number, onComplete:(fun()))
function m:Play() end

---@overload fun(onComplete:(fun()))
---@overload fun(times:number, delay:number, onComplete:(fun()))
function m:PlayReverse() end

---@param value number
function m:ChangeRepeat(value) end

---@overload fun(setToComplete:boolean, processCallback:boolean)
function m:Stop() end

function m:Dispose() end

---@overload fun(label:string)
---@param label string
---@param aParams any[]|any
function m:SetValue(label, aParams) end

---@param label string
---@param callback fun()
function m:SetHook(label, callback) end

function m:ClearHooks() end

---@param label string
---@param newTarget FairyGUI.GObject
function m:SetTarget(label, newTarget) end

---@param label string
---@param value number
function m:SetDuration(label, value) end

---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

FairyGUI.Transition = m
return m
