---@class FairyGUI.Utils.ToolSet : System.Object
local m = {}

---@static
---@param str string
---@return UnityEngine.Color
function m.ConvertFromHtmlColor(str) end

---@static
---@param value number
---@return UnityEngine.Color
function m.ColorFromRGB(value) end

---@static
---@param value number
---@return UnityEngine.Color
function m.ColorFromRGBA(value) end

---@static
---@param c number
---@return number
function m.CharToHex(c) end

---@static
---@param rect1 UnityEngine.Rect
---@param rect2 UnityEngine.Rect
---@return UnityEngine.Rect, UnityEngine.Rect, UnityEngine.Rect
function m.Intersection(rect1, rect2) end

---@static
---@param rect1 UnityEngine.Rect
---@param rect2 UnityEngine.Rect
---@return UnityEngine.Rect, UnityEngine.Rect, UnityEngine.Rect
function m.Union(rect1, rect2) end

---@static
---@param rect UnityEngine.Rect
---@param flip FairyGUI.FlipType
---@return UnityEngine.Rect
function m.FlipRect(rect, flip) end

---@static
---@param sourceWidth number
---@param sourceHeight number
---@param rect UnityEngine.Rect
---@param flip FairyGUI.FlipType
---@return UnityEngine.Rect
function m.FlipInnerRect(sourceWidth, sourceHeight, rect, flip) end

---@static
---@param uvSrc UnityEngine.Vector2[]
---@param uvDest UnityEngine.Vector2[]
---@param min number
---@param max number
function m.uvLerp(uvSrc, uvDest, min, max) end

---@static
---@param t UnityEngine.Transform
---@param parent UnityEngine.Transform
function m.SetParent(t, parent) end

---@static
---@param matrix UnityEngine.Matrix4x4
---@param skewX number
---@param skewY number
---@return UnityEngine.Matrix4x4
function m.SkewMatrix(matrix, skewX, skewY) end

---@static
---@param p UnityEngine.Vector2
---@param a UnityEngine.Vector2
---@param b UnityEngine.Vector2
---@param c UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2, UnityEngine.Vector2, UnityEngine.Vector2, UnityEngine.Vector2
function m.IsPointInTriangle(p, a, b, c) end

FairyGUI.Utils.ToolSet = m
return m
