---@class FairyGUI.MeshColliderHitTest : FairyGUI.ColliderHitTest
local m = {}

---@virtual
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetArea(x, y, width, height) end

---@virtual
---@param container FairyGUI.Container
---@param localPoint UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:HitTest(container, localPoint) end

---@param camera UnityEngine.Camera
---@param screenPoint UnityEngine.Vector3
---@param point UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:ScreenToLocal(camera, screenPoint, point) end

FairyGUI.MeshColliderHitTest = m
return m
