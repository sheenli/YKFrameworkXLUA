---@class SevenZip.Compression.LZ.IInWindowStream : table
local m = {}

---@abstract
---@param inStream System.IO.Stream
function m:SetStream(inStream) end

---@abstract
function m:Init() end

---@abstract
function m:ReleaseStream() end

---@abstract
---@param index number
---@return number
function m:GetIndexByte(index) end

---@abstract
---@param index number
---@param distance number
---@param limit number
---@return number
function m:GetMatchLen(index, distance, limit) end

---@abstract
---@return number
function m:GetNumAvailableBytes() end

SevenZip.Compression.LZ.IInWindowStream = m
return m
