---@class FairyGUI.GearXY : FairyGUI.GearBase
---@field public tweener DG.Tweening.Tweener
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

---@virtual
---@param dx number
---@param dy number
function m:UpdateFromRelations(dx, dy) end

FairyGUI.GearXY = m
return m
