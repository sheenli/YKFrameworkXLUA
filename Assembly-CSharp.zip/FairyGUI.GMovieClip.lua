---@class FairyGUI.GMovieClip : FairyGUI.GObject
---@field public onPlayEnd FairyGUI.EventListener
---@field public playing boolean
---@field public frame number
---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public material UnityEngine.Material
---@field public shader string
local m = {}

---@param start number
---@param _end number
---@param times number
---@param endAt number
function m:SetPlaySettings(start, _end, times, endAt) end

---@virtual
function m:ConstructFromResource() end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup_BeforeAdd(xml) end

FairyGUI.GMovieClip = m
return m
