---@class FairyGUI.FitScreen : System.Enum
---@field public None FairyGUI.FitScreen @static
---@field public FitSize FairyGUI.FitScreen @static
---@field public FitWidthAndSetMiddle FairyGUI.FitScreen @static
---@field public FitHeightAndSetCenter FairyGUI.FitScreen @static
---@field public value__ number
local m = {}

FairyGUI.FitScreen = m
return m
