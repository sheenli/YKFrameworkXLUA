---@class FairyGUI.GlyphInfo : System.Object
---@field public vert UnityEngine.Rect
---@field public uv UnityEngine.Vector2[]
---@field public width number
---@field public height number
---@field public channel number
local m = {}

FairyGUI.GlyphInfo = m
return m
