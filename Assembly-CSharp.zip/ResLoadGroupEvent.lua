---@class ResLoadGroupEvent : EventData_1_System_String_
---@field public LoadGroupFinish string @static
local m = {}

ResLoadGroupEvent = m
return m
