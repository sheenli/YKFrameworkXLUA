---@class ResGroupCfg : System.Object
---@field public sceneName string
---@field public keys string[]
local m = {}

ResGroupCfg = m
return m
