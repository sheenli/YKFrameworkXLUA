---@class EventData_1_T_ : EventData
local m = {}

EventData_1_T_ = m
return m
