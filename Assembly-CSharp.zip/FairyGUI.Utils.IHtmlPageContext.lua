---@class FairyGUI.Utils.IHtmlPageContext : table
local m = {}

---@abstract
---@param owner FairyGUI.RichTextField
---@param element FairyGUI.Utils.HtmlElement
---@return FairyGUI.Utils.IHtmlObject
function m:CreateObject(owner, element) end

---@abstract
---@param obj FairyGUI.Utils.IHtmlObject
function m:FreeObject(obj) end

---@abstract
---@param image FairyGUI.Utils.HtmlImage
---@return FairyGUI.NTexture
function m:GetImageTexture(image) end

---@abstract
---@param image FairyGUI.Utils.HtmlImage
---@param texture FairyGUI.NTexture
function m:FreeImageTexture(image, texture) end

FairyGUI.Utils.IHtmlPageContext = m
return m
