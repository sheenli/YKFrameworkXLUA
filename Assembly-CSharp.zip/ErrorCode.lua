---@class ErrorCode : System.Enum
---@field public Success ErrorCode @static
---@field public ConnectError ErrorCode @static
---@field public TimeOutError ErrorCode @static
---@field public value__ number
local m = {}

ErrorCode = m
return m
