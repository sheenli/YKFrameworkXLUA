---@class FairyGUI.HitTestContext : System.Object
---@field public screenPoint UnityEngine.Vector2 @static
---@field public worldPoint UnityEngine.Vector3 @static
---@field public direction UnityEngine.Vector3 @static
---@field public forTouch boolean @static
---@field public layerMask number @static
---@field public maxDistance number @static
---@field public cachedMainCamera UnityEngine.Camera @static
local m = {}

---@static
---@param camera UnityEngine.Camera
---@return boolean, UnityEngine.RaycastHit
function m.GetRaycastHitFromCache(camera) end

---@static
---@param camera UnityEngine.Camera
---@param hit UnityEngine.RaycastHit
---@return UnityEngine.RaycastHit
function m.CacheRaycastHit(camera, hit) end

---@static
function m.ClearRaycastHitCache() end

FairyGUI.HitTestContext = m
return m
