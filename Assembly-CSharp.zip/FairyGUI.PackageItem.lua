---@class FairyGUI.PackageItem : System.Object
---@field public owner FairyGUI.UIPackage
---@field public type FairyGUI.PackageItemType
---@field public id string
---@field public name string
---@field public width number
---@field public height number
---@field public file string
---@field public decoded boolean
---@field public exported boolean
---@field public scale9Grid System.Nullable_1_UnityEngine_Rect_
---@field public scaleByTile boolean
---@field public tileGridIndice number
---@field public texture FairyGUI.NTexture
---@field public interval number
---@field public repeatDelay number
---@field public swing boolean
---@field public frames FairyGUI.MovieClip.Frame[]
---@field public componentData FairyGUI.Utils.XML
---@field public displayList FairyGUI.DisplayListItem[]
---@field public extensionCreator fun():FairyGUI.GComponent
---@field public bitmapFont FairyGUI.BitmapFont
---@field public audioClip UnityEngine.AudioClip
---@field public binary string
local m = {}

---@return any
function m:Load() end

FairyGUI.PackageItem = m
return m
