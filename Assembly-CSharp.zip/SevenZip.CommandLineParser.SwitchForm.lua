---@class SevenZip.CommandLineParser.SwitchForm : System.Object
---@field public IDString string
---@field public Type SevenZip.CommandLineParser.SwitchType
---@field public Multi boolean
---@field public MinLen number
---@field public MaxLen number
---@field public PostCharSet string
local m = {}

SevenZip.CommandLineParser.SwitchForm = m
return m
