---@class SevenZip.Compression.LZ.OutWindow : System.Object
---@field public TrainSize number
local m = {}

---@param windowSize number
function m:Create(windowSize) end

---@param stream System.IO.Stream
---@param solid boolean
function m:Init(stream, solid) end

---@param stream System.IO.Stream
---@return boolean
function m:Train(stream) end

function m:ReleaseStream() end

function m:Flush() end

---@param distance number
---@param len number
function m:CopyBlock(distance, len) end

---@param b number
function m:PutByte(b) end

---@param distance number
---@return number
function m:GetByte(distance) end

SevenZip.Compression.LZ.OutWindow = m
return m
