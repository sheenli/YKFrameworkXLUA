---@class FairyGUI.IAnimationGear : table
---@field public playing boolean
---@field public frame number
local m = {}

FairyGUI.IAnimationGear = m
return m
