---@class FairyGUI.GLuaLabel : FairyGUI.GLabel
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:ConstructFromXML(xml) end

---@virtual
function m:Dispose() end

FairyGUI.GLuaLabel = m
return m
