---@class FairyGUI.ProgressTitleType : System.Enum
---@field public Percent FairyGUI.ProgressTitleType @static
---@field public ValueAndMax FairyGUI.ProgressTitleType @static
---@field public Value FairyGUI.ProgressTitleType @static
---@field public Max FairyGUI.ProgressTitleType @static
---@field public value__ number
local m = {}

FairyGUI.ProgressTitleType = m
return m
