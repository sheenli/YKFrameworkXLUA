---@class FairyGUI.TimersEngine : UnityEngine.MonoBehaviour
local m = {}

FairyGUI.TimersEngine = m
return m
