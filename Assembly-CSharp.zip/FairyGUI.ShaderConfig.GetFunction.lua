---@class FairyGUI.ShaderConfig.GetFunction : System.MulticastDelegate
local m = {}

---@virtual
---@param name string
---@return UnityEngine.Shader
function m:Invoke(name) end

---@virtual
---@param name string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(name, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UnityEngine.Shader
function m:EndInvoke(result) end

FairyGUI.ShaderConfig.GetFunction = m
return m
