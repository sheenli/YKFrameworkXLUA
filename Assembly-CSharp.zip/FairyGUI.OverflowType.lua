---@class FairyGUI.OverflowType : System.Enum
---@field public Visible FairyGUI.OverflowType @static
---@field public Hidden FairyGUI.OverflowType @static
---@field public Scroll FairyGUI.OverflowType @static
---@field public value__ number
local m = {}

FairyGUI.OverflowType = m
return m
