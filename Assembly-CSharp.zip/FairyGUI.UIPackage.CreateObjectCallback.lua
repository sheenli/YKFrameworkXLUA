---@class FairyGUI.UIPackage.CreateObjectCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param result FairyGUI.GObject
function m:Invoke(result) end

---@virtual
---@param result FairyGUI.GObject
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(result, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.UIPackage.CreateObjectCallback = m
return m
