---@class FairyGUI.Utils.XMLIterator : System.Object
---@field public tagName string @static
---@field public tagType FairyGUI.Utils.XMLTagType @static
---@field public lastTagName string @static
local m = {}

---@overload fun(source:string) @static
---@static
---@param source string
---@param lowerCaseName boolean
function m.Begin(source, lowerCaseName) end

---@static
---@return boolean
function m.NextTag() end

---@static
---@return string
function m.GetTagSource() end

---@overload fun():string @static
---@static
---@param trim boolean
---@return string
function m.GetRawText(trim) end

---@overload fun():string @static
---@static
---@param trim boolean
---@return string
function m.GetText(trim) end

---@static
---@param attrName string
---@return boolean
function m.HasAttribute(attrName) end

---@overload fun(attrName:string, defValue:string):string @static
---@static
---@param attrName string
---@return string
function m.GetAttribute(attrName) end

---@overload fun(attrName:string, defValue:number):number @static
---@static
---@param attrName string
---@return number
function m.GetAttributeInt(attrName) end

---@overload fun(attrName:string, defValue:number):number @static
---@static
---@param attrName string
---@return number
function m.GetAttributeFloat(attrName) end

---@overload fun(attrName:string, defValue:boolean):boolean @static
---@static
---@param attrName string
---@return boolean
function m.GetAttributeBool(attrName) end

---@overload fun(result:System.Collections.Hashtable):System.Collections.Hashtable @static
---@static
---@param result System.Collections.Generic.Dictionary_2_System_String_System_String_
---@return System.Collections.Generic.Dictionary_2_System_String_System_String_
function m.GetAttributes(result) end

FairyGUI.Utils.XMLIterator = m
return m
