---@class FairyGUI.UIConfig.SoundLoader : System.MulticastDelegate
local m = {}

---@virtual
---@param url string
---@return UnityEngine.AudioClip
function m:Invoke(url) end

---@virtual
---@param url string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(url, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return UnityEngine.AudioClip
function m:EndInvoke(result) end

FairyGUI.UIConfig.SoundLoader = m
return m
