---@class FairyGUI.Utils.ZipReader : System.Object
---@field public entryCount number
local m = {}

---@param entry FairyGUI.Utils.ZipReader.ZipEntry
---@return boolean
function m:GetNextEntry(entry) end

---@param entry FairyGUI.Utils.ZipReader.ZipEntry
---@return string
function m:GetEntryData(entry) end

FairyGUI.Utils.ZipReader = m
return m
