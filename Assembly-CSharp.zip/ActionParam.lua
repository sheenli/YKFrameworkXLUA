---@class ActionParam : System.Object
---@field public HasValue boolean
---@field public Item any
local m = {}

---@return System.Collections.Generic.KeyValuePair_2_System_String_System_Object_[]
function m:ToArray() end

---@param func fun(arg1:string, arg2:any):boolean
function m:Foreach(func) end

---@param name string
---@return any
function m:Get(name) end

---@param value any
function m:SetValue(value) end

---@return any
function m:GetValue() end

ActionParam = m
return m
