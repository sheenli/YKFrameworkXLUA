---@class FairyGUI.TreeView.TreeNodeCreateCellDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param node FairyGUI.TreeNode
---@return FairyGUI.GComponent
function m:Invoke(node) end

---@virtual
---@param node FairyGUI.TreeNode
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(node, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return FairyGUI.GComponent
function m:EndInvoke(result) end

FairyGUI.TreeView.TreeNodeCreateCellDelegate = m
return m
