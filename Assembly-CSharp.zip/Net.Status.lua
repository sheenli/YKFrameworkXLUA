---@class Net.Status : System.Enum
---@field public eStartRequest Net.Status @static
---@field public eEndRequest Net.Status @static
---@field public value__ number
local m = {}

Net.Status = m
return m
