---@class Sproto.ProtocolFunctionDictionary.typeFunc : System.MulticastDelegate
local m = {}

---@virtual
---@param buffer string
---@param offset number
---@return Sproto.SprotoTypeBase
function m:Invoke(buffer, offset) end

---@virtual
---@param buffer string
---@param offset number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(buffer, offset, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return Sproto.SprotoTypeBase
function m:EndInvoke(result) end

Sproto.ProtocolFunctionDictionary.typeFunc = m
return m
