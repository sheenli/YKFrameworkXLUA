---@class SevenZip.Compression.LZ.IMatchFinder : table
local m = {}

---@abstract
---@param historySize number
---@param keepAddBufferBefore number
---@param matchMaxLen number
---@param keepAddBufferAfter number
function m:Create(historySize, keepAddBufferBefore, matchMaxLen, keepAddBufferAfter) end

---@abstract
---@param distances number[]
---@return number
function m:GetMatches(distances) end

---@abstract
---@param num number
function m:Skip(num) end

SevenZip.Compression.LZ.IMatchFinder = m
return m
