---@class Sproto.SprotoTypeSize : System.Object
---@field public sizeof_header number @static
---@field public sizeof_length number @static
---@field public sizeof_field number @static
---@field public encode_max_size number @static
local m = {}

---@static
---@param info string
function m.error(info) end

Sproto.SprotoTypeSize = m
return m
