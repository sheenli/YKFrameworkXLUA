---@class SprotoType.Package : Sproto.SprotoTypeBase
---@field public type number
---@field public HasType boolean
---@field public session number
---@field public HasSession boolean
local m = {}

---@virtual
---@param stream Sproto.SprotoStream
---@return number
function m:encode(stream) end

SprotoType.Package = m
return m
