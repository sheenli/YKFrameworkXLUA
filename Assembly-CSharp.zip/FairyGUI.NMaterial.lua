---@class FairyGUI.NMaterial : System.Object
---@field public frameId number
---@field public clipId number
---@field public stencilSet boolean
---@field public blendMode FairyGUI.BlendMode
---@field public combined boolean
---@field public material UnityEngine.Material
local m = {}

FairyGUI.NMaterial = m
return m
