---@class PackageHead : System.Object
---@field public StatusCode number
---@field public Description string
---@field public ActionId number
---@field public MsgId number
---@field public SessionId string
---@field public UserId number
---@field public StrTime string
local m = {}

PackageHead = m
return m
