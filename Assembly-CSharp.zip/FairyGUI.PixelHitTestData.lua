---@class FairyGUI.PixelHitTestData : System.Object
---@field public pixelWidth number
---@field public scale number
---@field public pixels string
local m = {}

---@param ba FairyGUI.Utils.ByteBuffer
function m:Load(ba) end

FairyGUI.PixelHitTestData = m
return m
