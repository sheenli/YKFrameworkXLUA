---@class FairyGUI.Container : FairyGUI.DisplayObject
---@field public renderMode UnityEngine.RenderMode
---@field public renderCamera UnityEngine.Camera
---@field public opaque boolean
---@field public clipSoftness System.Nullable_1_UnityEngine_Vector4_
---@field public hitArea FairyGUI.IHitTest
---@field public touchChildren boolean
---@field public onUpdate fun()
---@field public reversedMask boolean
---@field public numChildren number
---@field public clipRect System.Nullable_1_UnityEngine_Rect_
---@field public mask FairyGUI.DisplayObject
---@field public touchable boolean
---@field public contentRect UnityEngine.Rect
---@field public fairyBatching boolean
local m = {}

---@param child FairyGUI.DisplayObject
---@return FairyGUI.DisplayObject
function m:AddChild(child) end

---@param child FairyGUI.DisplayObject
---@param index number
---@return FairyGUI.DisplayObject
function m:AddChildAt(child, index) end

---@param child FairyGUI.DisplayObject
---@return boolean
function m:Contains(child) end

---@param index number
---@return FairyGUI.DisplayObject
function m:GetChildAt(index) end

---@param name string
---@return FairyGUI.DisplayObject
function m:GetChild(name) end

---@param child FairyGUI.DisplayObject
---@return number
function m:GetChildIndex(child) end

---@overload fun(child:FairyGUI.DisplayObject, dispose:boolean):FairyGUI.DisplayObject
---@param child FairyGUI.DisplayObject
---@return FairyGUI.DisplayObject
function m:RemoveChild(child) end

---@overload fun(index:number, dispose:boolean):FairyGUI.DisplayObject
---@param index number
---@return FairyGUI.DisplayObject
function m:RemoveChildAt(index) end

---@overload fun(beginIndex:number, endIndex:number, dispose:boolean)
function m:RemoveChildren() end

---@param child FairyGUI.DisplayObject
---@param index number
function m:SetChildIndex(child, index) end

---@param child1 FairyGUI.DisplayObject
---@param child2 FairyGUI.DisplayObject
function m:SwapChildren(child1, child2) end

---@param index1 number
---@param index2 number
function m:SwapChildrenAt(index1, index2) end

---@param indice number[]
---@param objs FairyGUI.DisplayObject[]
function m:ChangeChildrenOrder(indice, objs) end

---@virtual
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:GetBounds(targetSpace) end

---@return UnityEngine.Camera
function m:GetRenderCamera() end

---@param stagePoint UnityEngine.Vector2
---@param forTouch boolean
---@return FairyGUI.DisplayObject
function m:HitTest(stagePoint, forTouch) end

---@return UnityEngine.Vector2
function m:GetHitTestLocalPoint() end

---@param obj FairyGUI.DisplayObject
---@return boolean
function m:IsAncestorOf(obj) end

---@param childrenChanged boolean
function m:InvalidateBatchingState(childrenChanged) end

---@param value number
function m:SetChildrenLayer(value) end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@virtual
function m:Dispose() end

FairyGUI.Container = m
return m
