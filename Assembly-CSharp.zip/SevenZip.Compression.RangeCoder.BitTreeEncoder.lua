---@class SevenZip.Compression.RangeCoder.BitTreeEncoder : System.ValueType
local m = {}

function m:Init() end

---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
function m:Encode(rangeEncoder, symbol) end

---@overload fun(Models:SevenZip.Compression.RangeCoder.BitEncoder[], startIndex:number, rangeEncoder:SevenZip.Compression.RangeCoder.Encoder, NumBitLevels:number, symbol:number) @static
---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
function m:ReverseEncode(rangeEncoder, symbol) end

---@param symbol number
---@return number
function m:GetPrice(symbol) end

---@overload fun(Models:SevenZip.Compression.RangeCoder.BitEncoder[], startIndex:number, NumBitLevels:number, symbol:number):number @static
---@param symbol number
---@return number
function m:ReverseGetPrice(symbol) end

SevenZip.Compression.RangeCoder.BitTreeEncoder = m
return m
