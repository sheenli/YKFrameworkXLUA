---@class FairyGUI.TransitionItem_Float : FairyGUI.TransitionItem
---@field public getter fun():number
---@field public setter fun(pNewValue:number)
local m = {}

FairyGUI.TransitionItem_Float = m
return m
