---@class FairyGUI.Anymous_T : System.Object
---@field public interval number
---@field public repeat number
---@field public callback fun(param:any)
---@field public param any
---@field public elapsed number
---@field public deleted boolean
local m = {}

---@param interval number
---@param repeat number
---@param callback fun(param:any)
---@param param any
function m:set(interval, repeat, callback, param) end

FairyGUI.Anymous_T = m
return m
