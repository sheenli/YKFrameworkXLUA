---@class FairyGUI.DisplayObject : FairyGUI.EventDispatcher
---@field public name string
---@field public onPaint fun()
---@field public gOwner FairyGUI.GObject
---@field public id number
---@field public parent FairyGUI.Container
---@field public gameObject UnityEngine.GameObject
---@field public cachedTransform UnityEngine.Transform
---@field public graphics FairyGUI.NGraphics
---@field public paintingGraphics FairyGUI.NGraphics
---@field public onClick FairyGUI.EventListener
---@field public onRightClick FairyGUI.EventListener
---@field public onTouchBegin FairyGUI.EventListener
---@field public onTouchMove FairyGUI.EventListener
---@field public onTouchEnd FairyGUI.EventListener
---@field public onRollOver FairyGUI.EventListener
---@field public onRollOut FairyGUI.EventListener
---@field public onMouseWheel FairyGUI.EventListener
---@field public onAddedToStage FairyGUI.EventListener
---@field public onRemovedFromStage FairyGUI.EventListener
---@field public onKeyDown FairyGUI.EventListener
---@field public onClickLink FairyGUI.EventListener
---@field public alpha number
---@field public grayed boolean
---@field public visible boolean
---@field public x number
---@field public y number
---@field public z number
---@field public xy UnityEngine.Vector2
---@field public position UnityEngine.Vector3
---@field public width number
---@field public height number
---@field public size UnityEngine.Vector2
---@field public scaleX number
---@field public scaleY number
---@field public scale UnityEngine.Vector2
---@field public rotation number
---@field public rotationX number
---@field public rotationY number
---@field public skew UnityEngine.Vector2
---@field public perspective boolean
---@field public focalLength number
---@field public pivot UnityEngine.Vector2
---@field public location UnityEngine.Vector3
---@field public material UnityEngine.Material
---@field public shader string
---@field public renderingOrder number
---@field public layer number
---@field public isDisposed boolean
---@field public topmost FairyGUI.Container
---@field public stage FairyGUI.Stage
---@field public worldSpaceContainer FairyGUI.Container
---@field public touchable boolean
---@field public paintingMode boolean
---@field public cacheAsBitmap boolean
---@field public filter FairyGUI.IFilter
---@field public blendMode FairyGUI.BlendMode
---@field public home UnityEngine.Transform
local m = {}

---@param xv number
---@param yv number
function m:SetXY(xv, yv) end

---@param xv number
---@param yv number
---@param zv number
function m:SetPosition(xv, yv, zv) end

---@param wv number
---@param hv number
function m:SetSize(wv, hv) end

---@virtual
function m:EnsureSizeCorrect() end

---@param xv number
---@param yv number
function m:SetScale(xv, yv) end

---@param requestorId number
---@param margin System.Nullable_1_FairyGUI_Margin_
function m:EnterPaintingMode(requestorId, margin) end

---@param requestorId number
function m:LeavePaintingMode(requestorId) end

---@virtual
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:GetBounds(targetSpace) end

---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:GlobalToLocal(point) end

---@param point UnityEngine.Vector2
---@return UnityEngine.Vector2
function m:LocalToGlobal(point) end

---@param worldPoint UnityEngine.Vector3
---@param direction UnityEngine.Vector3
---@return UnityEngine.Vector3
function m:WorldToLocal(worldPoint, direction) end

---@param point UnityEngine.Vector2
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Vector2
function m:TransformPoint(point, targetSpace) end

---@param rect UnityEngine.Rect
---@param targetSpace FairyGUI.DisplayObject
---@return UnityEngine.Rect
function m:TransformRect(rect, targetSpace) end

function m:RemoveFromParent() end

function m:InvalidateBatchingState() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@virtual
function m:Dispose() end

FairyGUI.DisplayObject = m
return m
