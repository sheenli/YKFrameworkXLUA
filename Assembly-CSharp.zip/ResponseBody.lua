---@class ResponseBody : System.Object
---@field public StateCode number
---@field public StateDescription string
---@field public Vesion string
---@field public Handler string
---@field public Data any
local m = {}

ResponseBody = m
return m
