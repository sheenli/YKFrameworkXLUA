---@class FairyGUI.GearLook : FairyGUI.GearBase
---@field public tweener DG.Tweening.Tweener
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

FairyGUI.GearLook = m
return m
