---@class FairyGUI.Utils.XMLTagType : System.Enum
---@field public Start FairyGUI.Utils.XMLTagType @static
---@field public End FairyGUI.Utils.XMLTagType @static
---@field public Void FairyGUI.Utils.XMLTagType @static
---@field public CDATA FairyGUI.Utils.XMLTagType @static
---@field public Comment FairyGUI.Utils.XMLTagType @static
---@field public Instruction FairyGUI.Utils.XMLTagType @static
---@field public value__ number
local m = {}

FairyGUI.Utils.XMLTagType = m
return m
