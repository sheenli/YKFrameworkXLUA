---@class FairyGUI.UIObjectFactory.GComponentCreator : System.MulticastDelegate
local m = {}

---@virtual
---@return FairyGUI.GComponent
function m:Invoke() end

---@virtual
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return FairyGUI.GComponent
function m:EndInvoke(result) end

FairyGUI.UIObjectFactory.GComponentCreator = m
return m
