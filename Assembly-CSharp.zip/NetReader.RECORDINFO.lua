---@class NetReader.RECORDINFO : System.Object
---@field public RecordSize number
---@field public RecordReadSize number
local m = {}

NetReader.RECORDINFO = m
return m
