---@class Sproto.SprotoTypeFieldOP : System.Object
---@field public has_bits number[]
local m = {}

---@param field_idx number
---@return boolean
function m:has_field(field_idx) end

function m:clear_field() end

Sproto.SprotoTypeFieldOP = m
return m
