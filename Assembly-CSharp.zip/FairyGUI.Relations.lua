---@class FairyGUI.Relations : System.Object
---@field public handling FairyGUI.GObject
---@field public isEmpty boolean
local m = {}

---@overload fun(target:FairyGUI.GObject, relationType:FairyGUI.RelationType, usePercent:boolean)
---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
function m:Add(target, relationType) end

---@param target FairyGUI.GObject
---@param relationType FairyGUI.RelationType
function m:Remove(target, relationType) end

---@param target FairyGUI.GObject
---@return boolean
function m:Contains(target) end

---@param target FairyGUI.GObject
function m:ClearFor(target) end

function m:ClearAll() end

---@param source FairyGUI.Relations
function m:CopyFrom(source) end

function m:Dispose() end

---@param dWidth number
---@param dHeight number
---@param applyPivot boolean
function m:OnOwnerSizeChanged(dWidth, dHeight, applyPivot) end

---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

FairyGUI.Relations = m
return m
