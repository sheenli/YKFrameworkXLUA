---@class FairyGUI.GTextInput : FairyGUI.GTextField
---@field public onFocusIn FairyGUI.EventListener
---@field public onFocusOut FairyGUI.EventListener
---@field public onChanged FairyGUI.EventListener
---@field public onSubmit FairyGUI.EventListener
---@field public inputTextField FairyGUI.InputTextField
---@field public editable boolean
---@field public hideInput boolean
---@field public maxLength number
---@field public restrict string
---@field public displayAsPassword boolean
---@field public caretPosition number
---@field public promptText string
---@field public keyboardInput boolean
---@field public keyboardType number
---@field public emojies table<number, FairyGUI.Emoji>
local m = {}

---@param start number
---@param length number
function m:SetSelection(start, length) end

---@param value string
function m:ReplaceSelection(value) end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup_BeforeAdd(xml) end

FairyGUI.GTextInput = m
return m
