---@class SocketPackage : NetPackage
---@field public MsgId number
---@field public HasLoading boolean
---@field public SendTime System.DateTime
local m = {}

SocketPackage = m
return m
