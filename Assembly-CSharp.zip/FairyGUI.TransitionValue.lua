---@class FairyGUI.TransitionValue : System.Object
---@field public f1 number
---@field public f2 number
---@field public f3 number
---@field public f4 number
---@field public b1 boolean
---@field public b2 boolean
---@field public AsVec2 UnityEngine.Vector2
---@field public AsVec4 UnityEngine.Vector4
---@field public AsColor UnityEngine.Color
local m = {}

---@param source FairyGUI.TransitionValue
function m:Copy(source) end

FairyGUI.TransitionValue = m
return m
