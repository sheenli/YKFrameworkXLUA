---@class FairyGUI.Utils.IHtmlObject : table
---@field public width number
---@field public height number
---@field public displayObject FairyGUI.DisplayObject
---@field public element FairyGUI.Utils.HtmlElement
local m = {}

---@abstract
---@param owner FairyGUI.RichTextField
---@param element FairyGUI.Utils.HtmlElement
function m:Create(owner, element) end

---@abstract
---@param x number
---@param y number
function m:SetPosition(x, y) end

---@abstract
function m:Add() end

---@abstract
function m:Remove() end

---@abstract
function m:Release() end

---@abstract
function m:Dispose() end

FairyGUI.Utils.IHtmlObject = m
return m
