---@class ISceneLoad : table
---@field public fileName string
---@field public isKeepInMemory boolean
---@field public loaded number
local m = {}

---@abstract
---@param callback fun()
function m:Load(callback) end

ISceneLoad = m
return m
