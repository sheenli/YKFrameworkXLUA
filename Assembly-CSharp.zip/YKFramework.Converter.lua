---@class YKFramework.Converter : System.Object
local m = {}

---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@static
---@param value number
---@return number
function m.GetBigEndian(value) end

---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@overload fun(value:number):number @static
---@static
---@param value number
---@return number
function m.GetLittleEndian(value) end

YKFramework.Converter = m
return m
