---@class FairyGUI.Utils.XMLUtils : System.Object
local m = {}

---@static
---@param aSource string
---@return string
function m.DecodeString(aSource) end

---@static
---@param str string
---@return string
function m.EncodeString(str) end

FairyGUI.Utils.XMLUtils = m
return m
