---@class NetworkType : System.Enum
---@field public Http NetworkType @static
---@field public Socket NetworkType @static
---@field public value__ number
local m = {}

NetworkType = m
return m
