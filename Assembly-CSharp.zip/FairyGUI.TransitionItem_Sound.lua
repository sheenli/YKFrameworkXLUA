---@class FairyGUI.TransitionItem_Sound : FairyGUI.TransitionItem
---@field public sound string
---@field public volume number
---@field public audioClip UnityEngine.AudioClip
local m = {}

---@virtual
---@param owner FairyGUI.Transition
function m:Setup(owner) end

function m:Play() end

FairyGUI.TransitionItem_Sound = m
return m
