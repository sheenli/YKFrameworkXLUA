---@class FairyGUI.EventListener : System.Object
---@field public owner FairyGUI.EventDispatcher
---@field public type string
---@field public isEmpty boolean
---@field public isDispatching boolean
local m = {}

---@param callback fun(context:FairyGUI.EventContext)
function m:AddCapture(callback) end

---@param callback fun(context:FairyGUI.EventContext)
function m:RemoveCapture(callback) end

---@overload fun(callback:(fun()))
---@param callback fun(context:FairyGUI.EventContext)
function m:Add(callback) end

---@overload fun(callback:(fun()))
---@param callback fun(context:FairyGUI.EventContext)
function m:Remove(callback) end

---@overload fun(callback:(fun(context:FairyGUI.EventContext)))
---@param callback fun()
function m:Set(callback) end

function m:Clear() end

---@overload fun(data:any):boolean
---@return boolean
function m:Call() end

---@overload fun():boolean
---@param data any
---@return boolean
function m:BubbleCall(data) end

---@overload fun():boolean
---@param data any
---@return boolean
function m:BroadcastCall(data) end

FairyGUI.EventListener = m
return m
