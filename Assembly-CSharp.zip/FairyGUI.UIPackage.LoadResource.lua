---@class FairyGUI.UIPackage.LoadResource : System.MulticastDelegate
local m = {}

---@virtual
---@param name string
---@param extension string
---@param type System.Type
---@return any
function m:Invoke(name, extension, type) end

---@virtual
---@param name string
---@param extension string
---@param type System.Type
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(name, extension, type, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return any
function m:EndInvoke(result) end

FairyGUI.UIPackage.LoadResource = m
return m
