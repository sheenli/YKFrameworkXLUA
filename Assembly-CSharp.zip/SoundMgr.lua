---@class SoundMgr : UnityEngine.MonoBehaviour
---@field public Instance SoundMgr @static
---@field public IsValid boolean @static
---@field public Volume number
---@field public IsOn boolean
local m = {}

function m:Awake() end

function m:OnDestroy() end

---@overload fun(audioClipName:string, isLoop:boolean)
---@overload fun(audioClipName:string)
---@param audioClipName string
---@param isLoop boolean
---@param listener fun(obj:UnityEngine.Object)
function m:PlayAudioClipAsync(audioClipName, isLoop, listener) end

---@param clip UnityEngine.AudioClip
---@param isLoop boolean
---@return UnityEngine.AudioSource
function m:PlayAudioClip(clip, isLoop) end

function m:Release() end

SoundMgr = m
return m
