---@class LoadGroup : System.Object
---@field public fileName string
---@field public isKeepInMemory boolean
---@field public loaded number
local m = {}

---@virtual
---@param callback fun()
function m:Load(callback) end

LoadGroup = m
return m
