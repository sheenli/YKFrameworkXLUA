---@class DownAPKTask : TaskBase
local m = {}

---@virtual
function m:OnExecute() end

DownAPKTask = m
return m
