---@class StateMachine.BetweenSwitchState : System.MulticastDelegate
local m = {}

---@virtual
---@param from IState
---@param to IState
---@param param1 any
---@param param2 any
function m:Invoke(from, to, param1, param2) end

---@virtual
---@param from IState
---@param to IState
---@param param1 any
---@param param2 any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(from, to, param1, param2, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

StateMachine.BetweenSwitchState = m
return m
