---@class SceneBase : System.Object
---@field public eventMgr EventListenerMgr
---@field public isLoadingShowWait boolean
---@field public sceneTask AsynTask
---@field public parallelTask AsynTask
---@field public SceneName string
---@field public GroupName string
local m = {}

---@param task ITask
function m:AddTask(task) end

---@param task ITask
function m:AddParallelTask(task) end

---@param gropName string
function m:AddLoadGrop(gropName) end

function m:Loaded() end

---@param param any
function m:Enter(param) end

function m:OnFinished() end

function m:Leave() end

function m:ResStartTask() end

---@overload fun(dis:EventDispatcherNode, type:string, _priority:number)
---@overload fun(dis:EventDispatcherNode, type:string)
---@param dis EventDispatcherNode
---@param type string
---@param _priority number
---@param _dispatchOnce boolean
function m:AddListener(dis, type, _priority, _dispatchOnce) end

---@virtual
function m:OnDestroy() end

SceneBase = m
return m
