---@class YKSupportLua.LuaStateBase : System.Object
---@field public StateId number
local m = {}

---@param peerTable XLua.LuaTable
function m:ConnectLua(peerTable) end

---@overload fun(prevState:IState, param1:any) @virtual
---@overload fun(prevState:IState) @virtual
---@virtual
---@param prevState IState
---@param param1 any
---@param param2 any
function m:OnEnter(prevState, param1, param2) end

---@virtual
function m:OnFixedUpdate() end

---@virtual
function m:OnLateUpdate() end

---@overload fun(nextState:IState, param1:any) @virtual
---@overload fun(nextState:IState) @virtual
---@virtual
---@param nextState IState
---@param param1 any
---@param param2 any
function m:OnLeave(nextState, param1, param2) end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnRelease() end

YKSupportLua.LuaStateBase = m
return m
