---@class FairyGUI.OriginHorizontal : System.Enum
---@field public Left FairyGUI.OriginHorizontal @static
---@field public Right FairyGUI.OriginHorizontal @static
---@field public value__ number
local m = {}

FairyGUI.OriginHorizontal = m
return m
