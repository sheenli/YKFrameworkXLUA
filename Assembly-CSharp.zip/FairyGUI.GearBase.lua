---@class FairyGUI.GearBase : System.Object
---@field public disableAllTweenEffect boolean @static
---@field public tween boolean
---@field public easeType DG.Tweening.Ease
---@field public tweenTime number
---@field public delay number
---@field public controller FairyGUI.Controller
local m = {}

---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

---@virtual
---@param dx number
---@param dy number
function m:UpdateFromRelations(dx, dy) end

---@abstract
function m:Apply() end

---@abstract
function m:UpdateState() end

FairyGUI.GearBase = m
return m
