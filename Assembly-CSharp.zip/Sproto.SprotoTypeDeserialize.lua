---@class Sproto.SprotoTypeDeserialize : System.Object
local m = {}

---@overload fun(data:string)
---@overload fun(reader:Sproto.SprotoTypeReader)
---@param data string
---@param offset number
function m:init(data, offset) end

---@return number
function m:read_tag() end

---@param floor number
---@return number
function m:read_decimal(floor) end

---@param floor number
---@return number[]
function m:read_decimal_list(floor) end

---@return number
function m:read_integer() end

---@return number[]
function m:read_integer_list() end

---@return boolean
function m:read_boolean() end

---@return boolean[]
function m:read_boolean_list() end

---@return string
function m:read_binary() end

---@return string[]
function m:read_binary_list() end

---@return string
function m:read_string() end

---@return string[]
function m:read_string_list() end

---@return Sproto.SprotoTypeBase
function m:read_obj() end

---@return Sproto.SprotoTypeBase[]
function m:read_obj_list() end

---@param func fun(v:Sproto.SprotoTypeBase):any
---@return table<any, Sproto.SprotoTypeBase>
function m:read_map(func) end

function m:read_unknow_data() end

---@return number
function m:size() end

function m:clear() end

Sproto.SprotoTypeDeserialize = m
return m
