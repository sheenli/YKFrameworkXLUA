---@class FairyGUI.PlayTransitionAction : FairyGUI.ControllerAction
---@field public transitionName string
---@field public repeat number
---@field public delay number
---@field public stopOnExit boolean
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup(xml) end

FairyGUI.PlayTransitionAction = m
return m
