---@class FairyGUI.ITreeListener : table
local m = {}

---@abstract
---@param node FairyGUI.TreeNode
---@return FairyGUI.GComponent
function m:TreeNodeCreateCell(node) end

---@abstract
---@param node FairyGUI.TreeNode
---@param obj FairyGUI.GComponent
function m:TreeNodeRender(node, obj) end

---@abstract
---@param node FairyGUI.TreeNode
---@param expand boolean
function m:TreeNodeWillExpand(node, expand) end

---@abstract
---@param node FairyGUI.TreeNode
---@param context FairyGUI.EventContext
function m:TreeNodeClick(node, context) end

FairyGUI.ITreeListener = m
return m
