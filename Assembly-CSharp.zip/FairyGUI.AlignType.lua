---@class FairyGUI.AlignType : System.Enum
---@field public Left FairyGUI.AlignType @static
---@field public Center FairyGUI.AlignType @static
---@field public Right FairyGUI.AlignType @static
---@field public value__ number
local m = {}

FairyGUI.AlignType = m
return m
