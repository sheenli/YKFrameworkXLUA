---@class FairyGUI.Origin90 : System.Enum
---@field public TopLeft FairyGUI.Origin90 @static
---@field public TopRight FairyGUI.Origin90 @static
---@field public BottomLeft FairyGUI.Origin90 @static
---@field public BottomRight FairyGUI.Origin90 @static
---@field public value__ number
local m = {}

FairyGUI.Origin90 = m
return m
