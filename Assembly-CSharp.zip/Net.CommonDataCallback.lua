---@class Net.CommonDataCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param reader NetReader
---@return boolean
function m:Invoke(reader) end

---@virtual
---@param reader NetReader
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(reader, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

Net.CommonDataCallback = m
return m
