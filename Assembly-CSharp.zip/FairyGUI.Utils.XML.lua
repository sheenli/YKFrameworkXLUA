---@class FairyGUI.Utils.XML : System.Object
---@field public name string
---@field public text string
local m = {}

---@param attrName string
---@return boolean
function m:HasAttribute(attrName) end

---@overload fun(attrName:string, defValue:string):string
---@param attrName string
---@return string
function m:GetAttribute(attrName) end

---@overload fun(attrName:string, defValue:number):number
---@param attrName string
---@return number
function m:GetAttributeInt(attrName) end

---@overload fun(attrName:string, defValue:number):number
---@param attrName string
---@return number
function m:GetAttributeFloat(attrName) end

---@overload fun(attrName:string, defValue:boolean):boolean
---@param attrName string
---@return boolean
function m:GetAttributeBool(attrName) end

---@overload fun(attrName:string, seperator:number):string[]
---@param attrName string
---@return string[]
function m:GetAttributeArray(attrName) end

---@param attrName string
---@param defValue UnityEngine.Color
---@return UnityEngine.Color
function m:GetAttributeColor(attrName, defValue) end

---@param attrName string
---@return UnityEngine.Vector2
function m:GetAttributeVector(attrName) end

---@param attrName string
---@param attrValue string
function m:SetAttribute(attrName, attrValue) end

---@param selector string
---@return FairyGUI.Utils.XML
function m:GetNode(selector) end

---@overload fun(selector:string):FairyGUI.Utils.XMLList
---@return FairyGUI.Utils.XMLList
function m:Elements() end

---@overload fun(selector:string):FairyGUI.Utils.XMLList.Enumerator
---@return FairyGUI.Utils.XMLList.Enumerator
function m:GetEnumerator() end

FairyGUI.Utils.XML = m
return m
