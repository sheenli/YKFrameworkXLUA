---@class FairyGUI.IKeyboard : table
---@field public done boolean
---@field public supportsCaret boolean
local m = {}

---@abstract
---@return string
function m:GetInput() end

---@abstract
---@param text string
---@param autocorrection boolean
---@param multiline boolean
---@param secure boolean
---@param alert boolean
---@param textPlaceholder string
---@param keyboardType number
---@param hideInput boolean
function m:Open(text, autocorrection, multiline, secure, alert, textPlaceholder, keyboardType, hideInput) end

---@abstract
function m:Close() end

FairyGUI.IKeyboard = m
return m
