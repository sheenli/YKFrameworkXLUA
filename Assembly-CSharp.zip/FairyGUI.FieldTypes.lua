---@class FairyGUI.FieldTypes : System.Object
local m = {}

---@static
---@param value string
---@return FairyGUI.PackageItemType
function m.ParsePackageItemType(value) end

---@static
---@param value string
---@return FairyGUI.AlignType
function m.ParseAlign(value) end

---@static
---@param value string
---@return FairyGUI.VertAlignType
function m.ParseVerticalAlign(value) end

---@static
---@param value string
---@return FairyGUI.ScrollType
function m.ParseScrollType(value) end

---@static
---@param value string
---@return FairyGUI.ScrollBarDisplayType
function m.ParseScrollBarDisplayType(value) end

---@static
---@param value string
---@return FairyGUI.OverflowType
function m.ParseOverflowType(value) end

---@static
---@param value string
---@return FairyGUI.FillType
function m.ParseFillType(value) end

---@static
---@param value string
---@return FairyGUI.AutoSizeType
function m.ParseAutoSizeType(value) end

---@static
---@param value string
---@return FairyGUI.ListLayoutType
function m.ParseListLayoutType(value) end

---@static
---@param value string
---@return FairyGUI.ListSelectionMode
function m.ParseListSelectionMode(value) end

---@static
---@param value string
---@return FairyGUI.ProgressTitleType
function m.ParseProgressTitleType(value) end

---@static
---@param value string
---@return FairyGUI.ButtonMode
function m.ParseButtonMode(value) end

---@static
---@param value string
---@return FairyGUI.FlipType
function m.ParseFlipType(value) end

---@static
---@param value string
---@return FairyGUI.FillMethod
function m.ParseFillMethod(value) end

---@static
---@param value string
---@return DG.Tweening.Ease
function m.ParseEaseType(value) end

---@static
---@param value string
---@return FairyGUI.TransitionActionType
function m.ParseTransitionActionType(value) end

---@static
---@param value string
---@return FairyGUI.BlendMode
function m.ParseBlendMode(value) end

---@static
---@param value string
---@return FairyGUI.ChildrenRenderOrder
function m.ParseChildrenRenderOrder(value) end

---@static
---@param value string
---@return FairyGUI.GroupLayoutType
function m.ParseGroupLayoutType(value) end

FairyGUI.FieldTypes = m
return m
