---@class FairyGUI.TransitionItem_Color : FairyGUI.TransitionItem
---@field public getter fun():UnityEngine.Color
---@field public setter fun(pNewValue:UnityEngine.Color)
local m = {}

FairyGUI.TransitionItem_Color = m
return m
