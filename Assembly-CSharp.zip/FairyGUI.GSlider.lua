---@class FairyGUI.GSlider : FairyGUI.GComponent
---@field public changeOnClick boolean
---@field public canDrag boolean
---@field public onChanged FairyGUI.EventListener
---@field public onGripTouchEnd FairyGUI.EventListener
---@field public titleType FairyGUI.ProgressTitleType
---@field public max number
---@field public value number
local m = {}

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:ConstructFromXML(cxml) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:Setup_AfterAdd(cxml) end

FairyGUI.GSlider = m
return m
