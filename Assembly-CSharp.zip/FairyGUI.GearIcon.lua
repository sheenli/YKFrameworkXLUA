---@class FairyGUI.GearIcon : FairyGUI.GearBase
local m = {}

---@virtual
function m:Apply() end

---@virtual
function m:UpdateState() end

FairyGUI.GearIcon = m
return m
