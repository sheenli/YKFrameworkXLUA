---@class BaseAction : GameAction
local m = {}

BaseAction = m
return m
