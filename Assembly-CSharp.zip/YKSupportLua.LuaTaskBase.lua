---@class YKSupportLua.LuaTaskBase : System.Object
---@field public mTaskName string
---@field public mFailureInfo string
---@field public isFailure boolean
---@field public isFinished boolean
---@field public IsFailure boolean
---@field public IsFinished boolean
local m = {}

---@param peerTable XLua.LuaTable
function m:ConnectLua(peerTable) end

---@virtual
---@return string
function m:TaskName() end

---@virtual
function m:OnExecute() end

---@virtual
---@return string
function m:FailureInfo() end

---@virtual
function m:Rest() end

YKSupportLua.LuaTaskBase = m
return m
