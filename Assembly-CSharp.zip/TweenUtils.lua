---@class TweenUtils : System.Object
local m = {}

---@static
---@param tweener DG.Tweening.Tweener
---@param delay number
function m.SetDelay(tweener, delay) end

---@overload fun(tweener:DG.Tweening.Tweener, loops:number, yoyo:boolean) @static
---@static
---@param tweener DG.Tweening.Tweener
---@param loops number
function m.SetLoops(tweener, loops) end

---@static
---@param tweener DG.Tweening.Tweener
---@param target any
function m.SetTarget(tweener, target) end

TweenUtils = m
return m
