---@class Sproto.SprotoPack : System.Object
local m = {}

---@overload fun(data:string):string
---@param data string
---@param len number
---@return string
function m:pack(data, len) end

---@overload fun(data:string):string
---@param data string
---@param len number
---@return string
function m:unpack(data, len) end

Sproto.SprotoPack = m
return m
