---@class FairyGUI.UIContentScaler.ScreenMatchMode : System.Enum
---@field public MatchWidthOrHeight FairyGUI.UIContentScaler.ScreenMatchMode @static
---@field public MatchWidth FairyGUI.UIContentScaler.ScreenMatchMode @static
---@field public MatchHeight FairyGUI.UIContentScaler.ScreenMatchMode @static
---@field public value__ number
local m = {}

FairyGUI.UIContentScaler.ScreenMatchMode = m
return m
