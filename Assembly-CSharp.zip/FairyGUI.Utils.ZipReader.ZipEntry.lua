---@class FairyGUI.Utils.ZipReader.ZipEntry : System.Object
---@field public name string
---@field public compress number
---@field public crc number
---@field public size number
---@field public sourceSize number
---@field public offset number
---@field public isDirectory boolean
local m = {}

FairyGUI.Utils.ZipReader.ZipEntry = m
return m
