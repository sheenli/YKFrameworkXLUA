---@class FairyGUI.TransitionItem_Transition : FairyGUI.TransitionItem
---@field public transName string
---@field public transRepeat number
---@field public playCompleteDelegate fun()
local m = {}

---@virtual
---@param owner FairyGUI.Transition
function m:Setup(owner) end

FairyGUI.TransitionItem_Transition = m
return m
