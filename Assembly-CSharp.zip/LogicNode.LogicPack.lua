---@class LogicNode.LogicPack : System.ValueType
---@field public logic ILogic
---@field public addOrRemove boolean
local m = {}

LogicNode.LogicPack = m
return m
