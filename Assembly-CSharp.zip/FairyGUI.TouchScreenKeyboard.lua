---@class FairyGUI.TouchScreenKeyboard : System.Object
---@field public done boolean
---@field public supportsCaret boolean
local m = {}

---@virtual
---@return string
function m:GetInput() end

---@virtual
---@param text string
---@param autocorrection boolean
---@param multiline boolean
---@param secure boolean
---@param alert boolean
---@param textPlaceholder string
---@param keyboardType number
---@param hideInput boolean
function m:Open(text, autocorrection, multiline, secure, alert, textPlaceholder, keyboardType, hideInput) end

---@virtual
function m:Close() end

FairyGUI.TouchScreenKeyboard = m
return m
