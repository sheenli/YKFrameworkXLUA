---@class ActionFactory : System.Object
local m = {}

---@overload fun(actionId:number):GameAction @static
---@static
---@param actionType any
---@return GameAction
function m.Create(actionType) end

ActionFactory = m
return m
