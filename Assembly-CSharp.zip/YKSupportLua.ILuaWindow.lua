---@class YKSupportLua.ILuaWindow : table
---@field public ResName string
---@field public PackName string
---@field public isNeedHideAnimation boolean
---@field public isNeedShowAnimation boolean
local m = {}

---@abstract
function m:OnInit() end

---@abstract
function m:DoHideAnimation() end

---@abstract
function m:DoShowAnimation() end

---@abstract
function m:OnShown() end

---@abstract
function m:OnHide() end

---@abstract
function m:OnDestroy() end

---@abstract
function m:OnColseBtn() end

---@abstract
---@param ev EventData
function m:OnHandler(ev) end

---@abstract
---@param btn FairyGUI.GButton
function m:OnBtnClick(btn) end

YKSupportLua.ILuaWindow = m
return m
