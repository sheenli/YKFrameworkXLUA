---@class FairyGUI.Stats : System.Object
---@field public ObjectCount number @static
---@field public GraphicsCount number @static
---@field public LatestObjectCreation number @static
---@field public LatestGraphicsCreation number @static
local m = {}

FairyGUI.Stats = m
return m
