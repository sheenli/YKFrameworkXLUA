---@class Net.RequestNotifyDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param eStatus Net.Status
function m:Invoke(eStatus) end

---@virtual
---@param eStatus Net.Status
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(eStatus, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

Net.RequestNotifyDelegate = m
return m
