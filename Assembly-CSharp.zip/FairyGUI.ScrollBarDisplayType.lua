---@class FairyGUI.ScrollBarDisplayType : System.Enum
---@field public Default FairyGUI.ScrollBarDisplayType @static
---@field public Visible FairyGUI.ScrollBarDisplayType @static
---@field public Auto FairyGUI.ScrollBarDisplayType @static
---@field public Hidden FairyGUI.ScrollBarDisplayType @static
---@field public value__ number
local m = {}

FairyGUI.ScrollBarDisplayType = m
return m
