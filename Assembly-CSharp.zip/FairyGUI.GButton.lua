---@class FairyGUI.GButton : FairyGUI.GComponent
---@field public UP string @static
---@field public DOWN string @static
---@field public OVER string @static
---@field public SELECTED_OVER string @static
---@field public DISABLED string @static
---@field public SELECTED_DISABLED string @static
---@field public sound UnityEngine.AudioClip
---@field public soundVolumeScale number
---@field public changeStateOnClick boolean
---@field public linkedPopup FairyGUI.GObject
---@field public pageOption FairyGUI.PageOption
---@field public onChanged FairyGUI.EventListener
---@field public icon string
---@field public title string
---@field public text string
---@field public selectedIcon string
---@field public selectedTitle string
---@field public titleColor UnityEngine.Color
---@field public titleFontSize number
---@field public selected boolean
---@field public mode FairyGUI.ButtonMode
---@field public relatedController FairyGUI.Controller
local m = {}

---@param downEffect boolean
function m:FireClick(downEffect) end

---@virtual
---@param c FairyGUI.Controller
function m:HandleControllerChanged(c) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:ConstructFromXML(cxml) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:Setup_AfterAdd(cxml) end

FairyGUI.GButton = m
return m
