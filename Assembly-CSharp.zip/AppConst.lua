---@class AppConst : System.Object
---@field public ExtName string @static
---@field public DebugMode boolean @static
---@field public serverIP string @static
---@field public LuaExtNames string[] @static
---@field public AppExternalDataPath string @static
---@field public AppExternalDataPathUrl string @static
---@field public SourceResPathUrl string @static
---@field public LuaPath string @static
---@field public ABPath string @static
---@field public TestAccount any @static
local m = {}

---@static
---@param rootPath string
---@param fileName string
---@return string
function m.ToValidFileName(rootPath, fileName) end

AppConst = m
return m
