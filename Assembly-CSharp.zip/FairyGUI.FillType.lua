---@class FairyGUI.FillType : System.Enum
---@field public None FairyGUI.FillType @static
---@field public Scale FairyGUI.FillType @static
---@field public ScaleMatchHeight FairyGUI.FillType @static
---@field public ScaleMatchWidth FairyGUI.FillType @static
---@field public ScaleFree FairyGUI.FillType @static
---@field public ScaleNoBorder FairyGUI.FillType @static
---@field public value__ number
local m = {}

FairyGUI.FillType = m
return m
