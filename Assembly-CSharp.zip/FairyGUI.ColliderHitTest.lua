---@class FairyGUI.ColliderHitTest : System.Object
---@field public collider UnityEngine.Collider
local m = {}

---@virtual
---@param x number
---@param y number
---@param width number
---@param height number
function m:SetArea(x, y, width, height) end

---@virtual
---@param value boolean
function m:SetEnabled(value) end

---@virtual
---@param container FairyGUI.Container
---@param localPoint UnityEngine.Vector2
---@return boolean, UnityEngine.Vector2
function m:HitTest(container, localPoint) end

FairyGUI.ColliderHitTest = m
return m
