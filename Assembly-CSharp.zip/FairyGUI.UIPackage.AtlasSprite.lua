---@class FairyGUI.UIPackage.AtlasSprite : System.Object
---@field public atlas string
---@field public rect UnityEngine.Rect
---@field public rotated boolean
local m = {}

FairyGUI.UIPackage.AtlasSprite = m
return m
