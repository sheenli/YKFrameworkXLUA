---@class FairyGUI.TransitionItem : System.Object
---@field public time number
---@field public targetId string
---@field public type FairyGUI.TransitionActionType
---@field public duration number
---@field public value FairyGUI.TransitionValue
---@field public startValue FairyGUI.TransitionValue
---@field public endValue FairyGUI.TransitionValue
---@field public easeType DG.Tweening.Ease
---@field public repeat number
---@field public yoyo boolean
---@field public tween boolean
---@field public label string
---@field public label2 string
---@field public hook fun()
---@field public hook2 fun()
---@field public tweener DG.Tweening.Tween
---@field public completed boolean
---@field public target FairyGUI.GObject
---@field public displayLockToken number
---@field public delayedCallDelegate fun()
---@field public tweenStartDelegate fun()
---@field public tweenUpdateDelegate fun()
---@field public tweenCompleteDelegate fun()
local m = {}

---@static
---@param type FairyGUI.TransitionActionType
---@return FairyGUI.TransitionItem
function m.createInstance(type) end

---@virtual
---@param owner FairyGUI.Transition
function m:Setup(owner) end

---@param source FairyGUI.TransitionItem
function m:Copy(source) end

FairyGUI.TransitionItem = m
return m
