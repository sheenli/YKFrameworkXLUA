---@class FairyGUI.UIConfig.ConfigValue : System.Object
---@field public valid boolean
---@field public s string
---@field public i number
---@field public f number
---@field public b boolean
---@field public c UnityEngine.Color
local m = {}

function m:Reset() end

FairyGUI.UIConfig.ConfigValue = m
return m
