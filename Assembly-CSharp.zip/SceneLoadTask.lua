---@class SceneLoadTask : System.Object
---@field public IsFailure boolean
---@field public IsFinished boolean
local m = {}

---@virtual
---@return string
function m:FailureInfo() end

---@virtual
function m:OnExecute() end

---@virtual
function m:Rest() end

---@virtual
---@return string
function m:TaskName() end

SceneLoadTask = m
return m
