---@class FairyGUI.TreeView : FairyGUI.EventDispatcher
---@field public indent number
---@field public treeNodeCreateCell fun(node:FairyGUI.TreeNode):FairyGUI.GComponent
---@field public treeNodeRender fun(node:FairyGUI.TreeNode)
---@field public treeNodeWillExpand fun(node:FairyGUI.TreeNode, expand:boolean)
---@field public list FairyGUI.GList
---@field public root FairyGUI.TreeNode
---@field public onClickNode FairyGUI.EventListener
---@field public onRightClickNode FairyGUI.EventListener
local m = {}

---@return FairyGUI.TreeNode
function m:GetSelectedNode() end

---@return FairyGUI.TreeNode[]
function m:GetSelection() end

---@overload fun(node:FairyGUI.TreeNode)
---@param node FairyGUI.TreeNode
---@param scrollItToView boolean
function m:AddSelection(node, scrollItToView) end

---@param node FairyGUI.TreeNode
function m:RemoveSelection(node) end

function m:ClearSelection() end

---@param node FairyGUI.TreeNode
---@return number
function m:GetNodeIndex(node) end

---@param node FairyGUI.TreeNode
function m:UpdateNode(node) end

---@param nodes FairyGUI.TreeNode[]
function m:UpdateNodes(nodes) end

---@param folderNode FairyGUI.TreeNode
function m:ExpandAll(folderNode) end

---@param folderNode FairyGUI.TreeNode
function m:CollapseAll(folderNode) end

FairyGUI.TreeView = m
return m
