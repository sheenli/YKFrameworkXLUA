---@class FairyGUI.MaterialManager : System.Object
---@field public texture FairyGUI.NTexture
---@field public shaderName string
local m = {}

---@static
---@param texture FairyGUI.NTexture
---@param shaderName string
---@param keywords string[]
---@return FairyGUI.MaterialManager
function m.GetInstance(texture, shaderName, keywords) end

---@param grahpics FairyGUI.NGraphics
---@param context FairyGUI.UpdateContext
---@return FairyGUI.NMaterial
function m:GetMaterial(grahpics, context) end

---@return FairyGUI.NMaterial
function m:CreateMaterial() end

function m:Dispose() end

function m:Release() end

FairyGUI.MaterialManager = m
return m
