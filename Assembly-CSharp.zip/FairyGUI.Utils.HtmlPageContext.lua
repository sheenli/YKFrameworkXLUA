---@class FairyGUI.Utils.HtmlPageContext : System.Object
---@field public inst FairyGUI.Utils.HtmlPageContext @static
local m = {}

---@virtual
---@param owner FairyGUI.RichTextField
---@param element FairyGUI.Utils.HtmlElement
---@return FairyGUI.Utils.IHtmlObject
function m:CreateObject(owner, element) end

---@virtual
---@param obj FairyGUI.Utils.IHtmlObject
function m:FreeObject(obj) end

---@virtual
---@param image FairyGUI.Utils.HtmlImage
---@return FairyGUI.NTexture
function m:GetImageTexture(image) end

---@virtual
---@param image FairyGUI.Utils.HtmlImage
---@param texture FairyGUI.NTexture
function m:FreeImageTexture(image, texture) end

FairyGUI.Utils.HtmlPageContext = m
return m
