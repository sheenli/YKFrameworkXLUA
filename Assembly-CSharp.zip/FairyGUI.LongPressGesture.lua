---@class FairyGUI.LongPressGesture : FairyGUI.EventDispatcher
---@field public TRIGGER number @static
---@field public INTERVAL number @static
---@field public trigger number
---@field public interval number
---@field public once boolean
---@field public holdRangeRadius number
---@field public host FairyGUI.GObject
---@field public onBegin FairyGUI.EventListener
---@field public onEnd FairyGUI.EventListener
---@field public onAction FairyGUI.EventListener
local m = {}

function m:Dispose() end

---@param value boolean
function m:Enable(value) end

function m:Cancel() end

FairyGUI.LongPressGesture = m
return m
