---@class SocketConnect : System.Object
local m = {}

---@static
---@param actionId number
---@param action GameAction
function m.PushActionPool(actionId, action) end

---@static
---@param actionId number
function m.RemoveActionPool(actionId) end

---@return SocketPackage
function m:Dequeue() end

---@return SocketPackage
function m:DequeuePush() end

function m:Open() end

---@return SocketPackage
function m:ReBuildHearbeat() end

function m:EnsureConnected() end

function m:Close() end

---@param data string
---@param package SocketPackage
function m:Send(data, package) end

function m:Dispose() end

function m:ProcessTimeOut() end

SocketConnect = m
return m
