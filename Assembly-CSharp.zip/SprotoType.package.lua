---@class SprotoType.package : Sproto.SprotoTypeBase
---@field public protoId number
---@field public HasProtoId boolean
---@field public session number
---@field public HasSession boolean
---@field public errorcode number
---@field public HasErrorcode boolean
local m = {}

---@virtual
---@param stream Sproto.SprotoStream
---@return number
function m:encode(stream) end

SprotoType.package = m
return m
