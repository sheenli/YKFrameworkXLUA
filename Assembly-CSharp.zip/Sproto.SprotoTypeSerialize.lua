---@class Sproto.SprotoTypeSerialize : System.Object
local m = {}

---@overload fun(d_list:number[], floor:number, tag:number)
---@param d number
---@param floor number
---@param tag number
function m:write_decimal(d, floor, tag) end

---@overload fun(integer_list:number[], tag:number)
---@param integer number
---@param tag number
function m:write_integer(integer, tag) end

---@overload fun(b_list:boolean[], tag:number)
---@param b boolean
---@param tag number
function m:write_boolean(b, tag) end

---@overload fun(bytes_list:string[], tag:number)
---@param bytes string
---@param tag number
function m:write_binary(bytes, tag) end

---@overload fun(str_list:string[], tag:number)
---@param str string
---@param tag number
function m:write_string(str, tag) end

---@overload fun(obj_list:Sproto.SprotoTypeBase[], tag:number)
---@overload fun(map:table<any, Sproto.SprotoTypeBase>, tag:number)
---@param obj Sproto.SprotoTypeBase
---@param tag number
function m:write_obj(obj, tag) end

---@param stream Sproto.SprotoStream
function m:open(stream) end

---@return number
function m:close() end

Sproto.SprotoTypeSerialize = m
return m
