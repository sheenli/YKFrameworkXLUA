---@class FairyGUI.PackageItemType : System.Enum
---@field public Image FairyGUI.PackageItemType @static
---@field public MovieClip FairyGUI.PackageItemType @static
---@field public Sound FairyGUI.PackageItemType @static
---@field public Component FairyGUI.PackageItemType @static
---@field public Atlas FairyGUI.PackageItemType @static
---@field public Font FairyGUI.PackageItemType @static
---@field public Misc FairyGUI.PackageItemType @static
---@field public value__ number
local m = {}

FairyGUI.PackageItemType = m
return m
