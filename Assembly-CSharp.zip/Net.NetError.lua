---@class Net.NetError : System.MulticastDelegate
local m = {}

---@virtual
---@param nType Net.eNetError
---@param actionId number
---@param strMsg string
function m:Invoke(nType, actionId, strMsg) end

---@virtual
---@param nType Net.eNetError
---@param actionId number
---@param strMsg string
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(nType, actionId, strMsg, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

Net.NetError = m
return m
