---@class LzmaAlone.Properties.Resources : System.Object
---@field public ResourceManager System.Resources.ResourceManager @static
---@field public Culture System.Globalization.CultureInfo @static
local m = {}

LzmaAlone.Properties.Resources = m
return m
