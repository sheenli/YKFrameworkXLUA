---@class XLua.ObjectCheckers : System.Object
local m = {}

---@param type System.Type
---@return fun(L:System.IntPtr, idx:number):boolean
function m:GetChecker(type) end

XLua.ObjectCheckers = m
return m
