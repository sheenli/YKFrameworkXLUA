---@class FairyGUI.TimerCallback : System.MulticastDelegate
local m = {}

---@virtual
---@param param any
function m:Invoke(param) end

---@virtual
---@param param any
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(param, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.TimerCallback = m
return m
