---@class IHeadFormater : table
local m = {}

---@overload fun(data:string):boolean, PackageHead, System.Byte__ @abstract
---@abstract
---@param data string
---@param type NetworkType
---@return boolean, PackageHead, System.Object
function m:TryParse(data, type) end

---@abstract
---@return string
function m:BuildHearbeatPackage() end

IHeadFormater = m
return m
