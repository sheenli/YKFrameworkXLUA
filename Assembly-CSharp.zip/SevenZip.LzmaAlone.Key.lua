---@class SevenZip.LzmaAlone.Key : System.Enum
---@field public Help1 SevenZip.LzmaAlone.Key @static
---@field public Help2 SevenZip.LzmaAlone.Key @static
---@field public Mode SevenZip.LzmaAlone.Key @static
---@field public Dictionary SevenZip.LzmaAlone.Key @static
---@field public FastBytes SevenZip.LzmaAlone.Key @static
---@field public LitContext SevenZip.LzmaAlone.Key @static
---@field public LitPos SevenZip.LzmaAlone.Key @static
---@field public PosBits SevenZip.LzmaAlone.Key @static
---@field public MatchFinder SevenZip.LzmaAlone.Key @static
---@field public EOS SevenZip.LzmaAlone.Key @static
---@field public StdIn SevenZip.LzmaAlone.Key @static
---@field public StdOut SevenZip.LzmaAlone.Key @static
---@field public Train SevenZip.LzmaAlone.Key @static
---@field public value__ number
local m = {}

SevenZip.LzmaAlone.Key = m
return m
