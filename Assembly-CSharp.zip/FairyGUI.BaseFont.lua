---@class FairyGUI.BaseFont : System.Object
---@field public mainTexture FairyGUI.NTexture
---@field public canTint boolean
---@field public canLight boolean
---@field public canOutline boolean
---@field public hasChannel boolean
---@field public customBold boolean
---@field public customBoldAndItalic boolean
---@field public shader string
---@field public keepCrisp boolean
---@field public packageItem FairyGUI.PackageItem
---@field public name string
local m = {}

---@virtual
---@param format FairyGUI.TextFormat
---@param fontSizeScale number
function m:SetFormat(format, fontSizeScale) end

---@virtual
---@param text string
function m:PrepareCharacters(text) end

---@virtual
---@param ch number
---@return boolean, System.Single, System.Single
function m:GetGlyphSize(ch) end

---@virtual
---@param ch number
---@param glyph FairyGUI.GlyphInfo
---@return boolean
function m:GetGlyph(ch, glyph) end

FairyGUI.BaseFont = m
return m
