---@class YKSupportLua.LuaWindow : BaseUI
---@field public ResName string
---@field public PackName string
local m = {}

---@virtual
function m:Dispose() end

YKSupportLua.LuaWindow = m
return m
