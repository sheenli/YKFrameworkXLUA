---@class SevenZip.IWriteCoderProperties : table
local m = {}

---@abstract
---@param outStream System.IO.Stream
function m:WriteCoderProperties(outStream) end

SevenZip.IWriteCoderProperties = m
return m
