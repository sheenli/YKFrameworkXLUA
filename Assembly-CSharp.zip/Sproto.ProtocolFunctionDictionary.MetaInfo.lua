---@class Sproto.ProtocolFunctionDictionary.MetaInfo : System.Object
---@field public ProtocolType System.Type
---@field public Request System.Collections.Generic.KeyValuePair_2_System_Type_Sproto_ProtocolFunctionDictionary_typeFunc_
---@field public Response System.Collections.Generic.KeyValuePair_2_System_Type_Sproto_ProtocolFunctionDictionary_typeFunc_
local m = {}

Sproto.ProtocolFunctionDictionary.MetaInfo = m
return m
