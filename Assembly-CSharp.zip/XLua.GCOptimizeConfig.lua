---@class XLua.GCOptimizeConfig : table
---@field public TypeList System.Type[]
---@field public AdditionalProperties table<System.Type, string[]>
local m = {}

XLua.GCOptimizeConfig = m
return m
