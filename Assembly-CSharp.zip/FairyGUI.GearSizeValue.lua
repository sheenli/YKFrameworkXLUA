---@class FairyGUI.GearSizeValue : System.Object
---@field public width number
---@field public height number
---@field public scaleX number
---@field public scaleY number
local m = {}

FairyGUI.GearSizeValue = m
return m
