---@class ABMgr.LoadPack : System.Object
---@field public request UnityEngine.AssetBundleCreateRequest
---@field public info ABMgr.PackInfo
---@field public listeners fun(obj:UnityEngine.AssetBundle)[]
---@field public IsDone boolean
local m = {}

function m:Load() end

---@param listener fun(obj:UnityEngine.AssetBundle)
function m:AddListener(listener) end

function m:CallBack() end

ABMgr.LoadPack = m
return m
