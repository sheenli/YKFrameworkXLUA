---@class GamUtil : System.Object
---@field public CenterPivot UnityEngine.Vector2 @static
---@field public UIStartScale UnityEngine.Vector2 @static
local m = {}

GamUtil = m
return m
