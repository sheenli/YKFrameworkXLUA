---@class FairyGUI.PlayState : System.Object
---@field public ignoreTimeScale boolean
---@field public reachEnding boolean
---@field public reversed boolean
---@field public repeatedCount number
---@field public currrentFrame number
local m = {}

---@param mc FairyGUI.MovieClip
---@param context FairyGUI.UpdateContext
function m:Update(mc, context) end

function m:Rewind() end

function m:Reset() end

---@param src FairyGUI.PlayState
function m:Copy(src) end

FairyGUI.PlayState = m
return m
