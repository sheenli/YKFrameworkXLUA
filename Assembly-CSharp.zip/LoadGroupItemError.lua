---@class LoadGroupItemError : EventData_1_LoadGroupItemErrorInfo_
---@field public eventName string @static
local m = {}

LoadGroupItemError = m
return m
