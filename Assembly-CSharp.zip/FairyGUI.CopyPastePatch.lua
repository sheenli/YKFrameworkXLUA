---@class FairyGUI.CopyPastePatch : System.Object
local m = {}

---@static
function m.Apply() end

---@static
---@param textField FairyGUI.InputTextField
---@param value string
function m.OnCopy(textField, value) end

---@static
---@param textField FairyGUI.InputTextField
function m.OnPaste(textField) end

FairyGUI.CopyPastePatch = m
return m
