---@class FairyGUI.RotationGesture : FairyGUI.EventDispatcher
---@field public rotation number
---@field public delta number
---@field public snapping boolean
---@field public host FairyGUI.GObject
---@field public onBegin FairyGUI.EventListener
---@field public onEnd FairyGUI.EventListener
---@field public onAction FairyGUI.EventListener
local m = {}

function m:Dispose() end

---@param value boolean
function m:Enable(value) end

FairyGUI.RotationGesture = m
return m
