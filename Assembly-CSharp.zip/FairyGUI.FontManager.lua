---@class FairyGUI.FontManager : System.Object
local m = {}

---@static
---@param font FairyGUI.BaseFont
---@param alias string
function m.RegisterFont(font, alias) end

---@static
---@param font FairyGUI.BaseFont
function m.UnregisterFont(font) end

---@static
---@param name string
---@return FairyGUI.BaseFont
function m.GetFont(name) end

---@static
function m.Clear() end

FairyGUI.FontManager = m
return m
