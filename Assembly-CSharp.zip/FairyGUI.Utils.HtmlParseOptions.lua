---@class FairyGUI.Utils.HtmlParseOptions : System.Object
---@field public DefaultLinkUnderline boolean @static
---@field public DefaultLinkColor UnityEngine.Color @static
---@field public DefaultLinkBgColor UnityEngine.Color @static
---@field public DefaultLinkHoverBgColor UnityEngine.Color @static
---@field public linkUnderline boolean
---@field public linkColor UnityEngine.Color
---@field public linkBgColor UnityEngine.Color
---@field public linkHoverBgColor UnityEngine.Color
---@field public ignoreWhiteSpace boolean
local m = {}

FairyGUI.Utils.HtmlParseOptions = m
return m
