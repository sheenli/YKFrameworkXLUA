---@class NetReader : System.Object
---@field public Success boolean
---@field public StatusCode number
---@field public Description string
---@field public ActionId number
---@field public RmId number
---@field public StrTime string
---@field public Buffer string
local m = {}

---@param buf string
function m:SetBuffer(buf) end

---@param buffer string
---@param type NetworkType
---@param respContentType ResponseContentType
---@return boolean
function m:pushNetStream(buffer, type, respContentType) end

---@return any
function m:readValue() end

---@return boolean
function m:recordBegin() end

function m:recordEnd() end

---@return number
function m:getRecordNumber() end

---@return number
function m:getByte() end

---@return number
function m:getSByte() end

---@return number
function m:getShort() end

---@return number
function m:getUShort() end

---@return number
function m:getInt() end

---@return number
function m:getUInt() end

---@return number
function m:getFloat() end

---@return number
function m:getDouble() end

---@return number
function m:getULong() end

---@return number
function m:getLong() end

---@return number
function m:readInt64() end

---@return number
function m:ReverseInt() end

---@return string
function m:ReadReverseString() end

---@return System.DateTime
function m:getDateTime() end

---@param nLen number
---@return string
function m:getString(nLen) end

---@return string
function m:readString() end

---@overload fun(nLen:number):string
---@return string
function m:readBytes() end

NetReader = m
return m
