---@class XLua.CSharpCallLuaAttribute : System.Attribute
local m = {}

XLua.CSharpCallLuaAttribute = m
return m
