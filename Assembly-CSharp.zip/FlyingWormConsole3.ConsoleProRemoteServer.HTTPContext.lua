---@class FlyingWormConsole3.ConsoleProRemoteServer.HTTPContext : System.Object
---@field public context System.Net.HttpListenerContext
---@field public path string
---@field public Command string
---@field public Request System.Net.HttpListenerRequest
---@field public Response System.Net.HttpListenerResponse
local m = {}

---@param inString string
function m:RespondWithString(inString) end

FlyingWormConsole3.ConsoleProRemoteServer.HTTPContext = m
return m
