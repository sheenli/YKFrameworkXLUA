---@class IState : table
---@field public StateId number
local m = {}

---@overload fun(prevState:IState, param1:any) @abstract
---@overload fun(prevState:IState) @abstract
---@abstract
---@param prevState IState
---@param param1 any
---@param param2 any
function m:OnEnter(prevState, param1, param2) end

---@overload fun(nextState:IState, param1:any) @abstract
---@overload fun(nextState:IState) @abstract
---@abstract
---@param nextState IState
---@param param1 any
---@param param2 any
function m:OnLeave(nextState, param1, param2) end

---@abstract
function m:OnRelease() end

---@abstract
function m:OnUpdate() end

---@abstract
function m:OnFixedUpdate() end

---@abstract
function m:OnLateUpdate() end

IState = m
return m
