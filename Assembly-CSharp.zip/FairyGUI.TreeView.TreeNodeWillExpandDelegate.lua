---@class FairyGUI.TreeView.TreeNodeWillExpandDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param node FairyGUI.TreeNode
---@param expand boolean
function m:Invoke(node, expand) end

---@virtual
---@param node FairyGUI.TreeNode
---@param expand boolean
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(node, expand, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

FairyGUI.TreeView.TreeNodeWillExpandDelegate = m
return m
