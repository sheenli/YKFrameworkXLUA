---@class EventData : System.Object
---@field public isBreak boolean
---@field public name string
---@field public value any
local m = {}

function m:Break() end

EventData = m
return m
