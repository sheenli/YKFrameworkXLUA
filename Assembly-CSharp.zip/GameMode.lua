---@class GameMode : EventDispatcherNode
---@field public Instance GameMode @static
---@field public IP string
---@field public latitude number
---@field public longitude number
---@field public AuditMode boolean
---@field public pos string
---@field public OpenId string
---@field public CardBack number
---@field public DeskBack number
local m = {}

---@param mode IMode
function m:AddMode(mode) end

function m:InitDtata() end

---@return number
function m:SendLoginMsgs() end

function m:ClearData() end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnDestroy() end

GameMode = m
return m
