---@class FairyGUI.ITextColorGear : table
---@field public strokeColor UnityEngine.Color
local m = {}

FairyGUI.ITextColorGear = m
return m
