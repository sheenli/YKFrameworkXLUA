---@class FairyGUI.Window : FairyGUI.GComponent
---@field public bringToFontOnClick boolean
---@field public contentPane FairyGUI.GComponent
---@field public frame FairyGUI.GComponent
---@field public closeButton FairyGUI.GObject
---@field public dragArea FairyGUI.GObject
---@field public contentArea FairyGUI.GObject
---@field public modalWaitingPane FairyGUI.GObject
---@field public isShowing boolean
---@field public isTop boolean
---@field public modal boolean
---@field public modalWaiting boolean
local m = {}

---@param source FairyGUI.IUISource
function m:AddUISource(source) end

function m:Show() end

---@param r FairyGUI.GRoot
function m:ShowOn(r) end

function m:Hide() end

function m:HideImmediately() end

---@param r FairyGUI.GRoot
---@param restraint boolean
function m:CenterOn(r, restraint) end

function m:ToggleStatus() end

function m:BringToFront() end

---@overload fun(requestingCmd:number)
function m:ShowModalWait() end

---@overload fun(requestingCmd:number):boolean
---@return boolean
function m:CloseModalWait() end

function m:Init() end

---@virtual
function m:Dispose() end

FairyGUI.Window = m
return m
