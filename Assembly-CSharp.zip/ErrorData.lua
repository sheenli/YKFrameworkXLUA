---@class ErrorData : System.Object
---@field public actionId number
---@field public code number
---@field public errorMsg string
local m = {}

ErrorData = m
return m
