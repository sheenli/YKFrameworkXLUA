---@class FairyGUI.GTextField : FairyGUI.GObject
---@field public text string
---@field public textFormat FairyGUI.TextFormat
---@field public color UnityEngine.Color
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public singleLine boolean
---@field public stroke number
---@field public strokeColor UnityEngine.Color
---@field public shadowOffset UnityEngine.Vector2
---@field public UBBEnabled boolean
---@field public autoSize FairyGUI.AutoSizeType
---@field public textWidth number
---@field public textHeight number
local m = {}

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup_BeforeAdd(xml) end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup_AfterAdd(xml) end

FairyGUI.GTextField = m
return m
