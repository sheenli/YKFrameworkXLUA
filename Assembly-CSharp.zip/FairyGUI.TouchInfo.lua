---@class FairyGUI.TouchInfo : System.Object
---@field public x number
---@field public y number
---@field public touchId number
---@field public clickCount number
---@field public keyCode UnityEngine.KeyCode
---@field public character number
---@field public modifiers UnityEngine.EventModifiers
---@field public mouseWheelDelta number
---@field public button number
---@field public downX number
---@field public downY number
---@field public began boolean
---@field public clickCancelled boolean
---@field public lastClickTime number
---@field public target FairyGUI.DisplayObject
---@field public downTargets FairyGUI.DisplayObject[]
---@field public lastRollOver FairyGUI.DisplayObject
---@field public touchMonitors FairyGUI.EventDispatcher[]
---@field public evt FairyGUI.InputEvent
local m = {}

function m:Reset() end

function m:UpdateEvent() end

function m:Begin() end

function m:Move() end

function m:End() end

---@return FairyGUI.DisplayObject
function m:ClickTest() end

FairyGUI.TouchInfo = m
return m
