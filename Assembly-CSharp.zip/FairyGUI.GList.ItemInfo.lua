---@class FairyGUI.GList.ItemInfo : System.Object
---@field public size UnityEngine.Vector2
---@field public obj FairyGUI.GObject
---@field public updateFlag number
---@field public selected boolean
local m = {}

FairyGUI.GList.ItemInfo = m
return m
