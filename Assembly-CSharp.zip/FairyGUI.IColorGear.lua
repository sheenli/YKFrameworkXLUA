---@class FairyGUI.IColorGear : table
---@field public color UnityEngine.Color
local m = {}

FairyGUI.IColorGear = m
return m
