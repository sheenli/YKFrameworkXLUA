---@class FairyGUI.UIPainter : UnityEngine.MonoBehaviour
---@field public packageName string
---@field public componentName string
---@field public sortingOrder number
---@field public container FairyGUI.Container
---@field public ui FairyGUI.GComponent
---@field public EM_sortingOrder number
local m = {}

---@param value number
---@param apply boolean
function m:SetSortingOrder(value, apply) end

function m:CreateUI() end

---@param sortingOrderChanged boolean
function m:ApplyModifiedProperties(sortingOrderChanged) end

---@param data any[]
function m:OnUpdateSource(data) end

---@virtual
function m:EM_BeforeUpdate() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:EM_Update(context) end

---@virtual
function m:EM_Reload() end

FairyGUI.UIPainter = m
return m
