---@class SevenZip.Compression.LZ.InWindow : System.Object
---@field public _bufferBase string
---@field public _bufferOffset number
---@field public _blockSize number
---@field public _pos number
---@field public _streamPos number
local m = {}

function m:MoveBlock() end

---@virtual
function m:ReadBlock() end

---@param keepSizeBefore number
---@param keepSizeAfter number
---@param keepSizeReserv number
function m:Create(keepSizeBefore, keepSizeAfter, keepSizeReserv) end

---@param stream System.IO.Stream
function m:SetStream(stream) end

function m:ReleaseStream() end

function m:Init() end

function m:MovePos() end

---@param index number
---@return number
function m:GetIndexByte(index) end

---@param index number
---@param distance number
---@param limit number
---@return number
function m:GetMatchLen(index, distance, limit) end

---@return number
function m:GetNumAvailableBytes() end

---@param subValue number
function m:ReduceOffsets(subValue) end

SevenZip.Compression.LZ.InWindow = m
return m
