---@class Net.eNetError : System.Enum
---@field public eConnectFailed Net.eNetError @static
---@field public eTimeOut Net.eNetError @static
---@field public DuplicateCode Net.eNetError @static
---@field public ServerTimeoutCode Net.eNetError @static
---@field public value__ number
local m = {}

Net.eNetError = m
return m
