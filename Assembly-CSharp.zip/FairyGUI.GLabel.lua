---@class FairyGUI.GLabel : FairyGUI.GComponent
---@field public icon string
---@field public title string
---@field public text string
---@field public editable boolean
---@field public titleColor UnityEngine.Color
---@field public titleFontSize number
---@field public color UnityEngine.Color
local m = {}

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:ConstructFromXML(cxml) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:Setup_AfterAdd(cxml) end

FairyGUI.GLabel = m
return m
