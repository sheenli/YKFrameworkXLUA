---@class EventListenerMgr.EventListenerData : System.Object
---@field public dis EventDispatcherNode
---@field public dele fun(data:EventData)
---@field public type string
local m = {}

function m:DetachListener() end

EventListenerMgr.EventListenerData = m
return m
