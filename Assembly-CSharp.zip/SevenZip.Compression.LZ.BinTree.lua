---@class SevenZip.Compression.LZ.BinTree : SevenZip.Compression.LZ.InWindow
local m = {}

---@param numHashBytes number
function m:SetType(numHashBytes) end

---@virtual
---@param stream System.IO.Stream
function m:SetStream(stream) end

---@virtual
function m:ReleaseStream() end

---@virtual
function m:Init() end

function m:MovePos() end

---@virtual
---@param index number
---@return number
function m:GetIndexByte(index) end

---@virtual
---@param index number
---@param distance number
---@param limit number
---@return number
function m:GetMatchLen(index, distance, limit) end

---@virtual
---@return number
function m:GetNumAvailableBytes() end

---@virtual
---@param historySize number
---@param keepAddBufferBefore number
---@param matchMaxLen number
---@param keepAddBufferAfter number
function m:Create(historySize, keepAddBufferBefore, matchMaxLen, keepAddBufferAfter) end

---@virtual
---@param distances number[]
---@return number
function m:GetMatches(distances) end

---@virtual
---@param num number
function m:Skip(num) end

---@param cutValue number
function m:SetCutValue(cutValue) end

SevenZip.Compression.LZ.BinTree = m
return m
