---@class DownLoadTask : System.Object
---@field public downInfo ABInfo
---@field public IsFailure boolean
---@field public IsFinished boolean
local m = {}

---@virtual
---@return string
function m:FailureInfo() end

---@virtual
function m:OnExecute() end

---@return System.Collections.IEnumerator
function m:StartDown() end

---@virtual
function m:Rest() end

---@virtual
---@return string
function m:TaskName() end

DownLoadTask = m
return m
