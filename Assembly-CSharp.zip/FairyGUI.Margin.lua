---@class FairyGUI.Margin : System.ValueType
---@field public left number
---@field public right number
---@field public top number
---@field public bottom number
local m = {}

---@param str string
function m:Parse(str) end

FairyGUI.Margin = m
return m
