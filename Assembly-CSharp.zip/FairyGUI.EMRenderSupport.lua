---@class FairyGUI.EMRenderSupport : System.Object
---@field public orderChanged boolean @static
---@field public packageListReady boolean @static
---@field public hasTarget boolean @static
local m = {}

---@static
---@param value FairyGUI.EMRenderTarget
function m.Add(value) end

---@static
---@param value FairyGUI.EMRenderTarget
function m.Remove(value) end

---@static
function m.Update() end

---@static
function m.Reload() end

FairyGUI.EMRenderSupport = m
return m
