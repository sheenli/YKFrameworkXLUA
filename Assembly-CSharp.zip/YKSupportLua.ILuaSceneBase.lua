---@class YKSupportLua.ILuaSceneBase : table
local m = {}

---@abstract
---@param param any
function m:OnInit(param) end

---@abstract
function m:OnEnter() end

---@abstract
function m:OnLeave() end

---@abstract
function m:OnResLoaded() end

---@abstract
---@param taskName string
---@param error string
function m:OnTaskFailure(taskName, error) end

---@abstract
---@param ev EventData
function m:OnHandler(ev) end

---@abstract
function m:OnDestroy() end

YKSupportLua.ILuaSceneBase = m
return m
