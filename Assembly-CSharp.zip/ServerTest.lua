---@class ServerTest : UnityEngine.MonoBehaviour
local m = {}

ServerTest = m
return m
