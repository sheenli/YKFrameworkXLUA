---@class Sproto.ProtocolBase : System.Object
---@field public Protocol Sproto.ProtocolFunctionDictionary
local m = {}

Sproto.ProtocolBase = m
return m
