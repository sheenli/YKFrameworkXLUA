---@class FairyGUI.ListLayoutType : System.Enum
---@field public SingleColumn FairyGUI.ListLayoutType @static
---@field public SingleRow FairyGUI.ListLayoutType @static
---@field public FlowHorizontal FairyGUI.ListLayoutType @static
---@field public FlowVertical FairyGUI.ListLayoutType @static
---@field public Pagination FairyGUI.ListLayoutType @static
---@field public value__ number
local m = {}

FairyGUI.ListLayoutType = m
return m
