---@class FairyGUI.Utils.ByteBuffer : System.Object
---@field public endian FairyGUI.Utils.ByteBuffer.Endian
---@field public length number
---@field public position number
---@field public bytesAvailable boolean
---@field public buffer string
local m = {}

---@param numberBytes number
---@return number
function m:SkipBytes(numberBytes) end

---@return number
function m:ReadByte() end

---@overload fun(output:System.Byte__, destIndex:number, length:number):string, System.Byte__
---@param output System.Byte__
---@param startIndex number
---@param destIndex number
---@param length number
---@return string, System.Byte__
function m:ReadBytes(output, startIndex, destIndex, length) end

---@return number
function m:ReadInt() end

---@return number
function m:ReadUint() end

---@return number
function m:ReadFloat() end

---@return number
function m:ReadLong() end

---@return number
function m:ReadDouble() end

---@return number
function m:ReadShort() end

---@return number
function m:ReadUshort() end

---@return number
function m:ReadChar() end

---@return boolean
function m:ReadBool() end

---@overload fun(len:number):string
---@return string
function m:ReadString() end

FairyGUI.Utils.ByteBuffer = m
return m
