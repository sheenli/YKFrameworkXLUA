---@class FairyGUI.TextField : FairyGUI.DisplayObject
---@field public textFormat FairyGUI.TextFormat
---@field public align FairyGUI.AlignType
---@field public verticalAlign FairyGUI.VertAlignType
---@field public text string
---@field public htmlText string
---@field public parsedText string
---@field public autoSize FairyGUI.AutoSizeType
---@field public wordWrap boolean
---@field public singleLine boolean
---@field public stroke number
---@field public strokeColor UnityEngine.Color
---@field public shadowOffset UnityEngine.Vector2
---@field public textWidth number
---@field public textHeight number
---@field public htmlElements FairyGUI.Utils.HtmlElement[]
---@field public lines FairyGUI.TextField.LineInfo[]
---@field public charPositions FairyGUI.TextField.CharPosition[]
---@field public richTextField FairyGUI.RichTextField
local m = {}

function m:EnableCharPositionSupport() end

---@return boolean
function m:Redraw() end

---@param startLine number
---@param startCharX number
---@param endLine number
---@param endCharX number
---@param clipped boolean
---@param resultRects UnityEngine.Rect[]
function m:GetLinesShape(startLine, startCharX, endLine, endCharX, clipped, resultRects) end

---@virtual
function m:EnsureSizeCorrect() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

FairyGUI.TextField = m
return m
