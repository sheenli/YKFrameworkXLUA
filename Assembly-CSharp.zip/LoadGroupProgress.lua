---@class LoadGroupProgress : EventData_1_GroupProgress_
---@field public eventName string @static
local m = {}

LoadGroupProgress = m
return m
