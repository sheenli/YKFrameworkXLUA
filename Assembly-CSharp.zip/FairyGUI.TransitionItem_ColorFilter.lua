---@class FairyGUI.TransitionItem_ColorFilter : FairyGUI.TransitionItem
---@field public getter fun():UnityEngine.Vector4
---@field public setter fun(pNewValue:UnityEngine.Vector4)
local m = {}

function m:SetFilter() end

function m:ClearFilter() end

FairyGUI.TransitionItem_ColorFilter = m
return m
