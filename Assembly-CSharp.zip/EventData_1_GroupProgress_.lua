---@class EventData_1_GroupProgress_ : EventData
local m = {}

EventData_1_GroupProgress_ = m
return m
