---@class NetPackage : System.Object
---@field public ActionId number
---@field public Action GameAction
---@field public IsOverTime boolean
---@field public ErrorMsg string
---@field public ErrorCode number
---@field public UserData any
---@field public Reader NetReader
local m = {}

NetPackage = m
return m
