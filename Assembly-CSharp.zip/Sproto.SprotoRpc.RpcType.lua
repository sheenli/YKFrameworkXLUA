---@class Sproto.SprotoRpc.RpcType : System.Enum
---@field public REQUEST Sproto.SprotoRpc.RpcType @static
---@field public RESPONSE Sproto.SprotoRpc.RpcType @static
---@field public value__ number
local m = {}

Sproto.SprotoRpc.RpcType = m
return m
