---@class FairyGUI.UIConfig : UnityEngine.MonoBehaviour
---@field public defaultFont string @static
---@field public renderingTextBrighterOnDesktop boolean @static
---@field public windowModalWaiting string @static
---@field public globalModalWaiting string @static
---@field public modalLayerColor UnityEngine.Color @static
---@field public buttonSound UnityEngine.AudioClip @static
---@field public buttonSoundVolumeScale number @static
---@field public horizontalScrollBar string @static
---@field public verticalScrollBar string @static
---@field public defaultScrollStep number @static
---@field public defaultScrollSpeed number @static
---@field public defaultScrollDecelerationRate number @static
---@field public defaultTouchScrollSpeedRatio number @static
---@field public defaultScrollBarDisplay FairyGUI.ScrollBarDisplayType @static
---@field public defaultScrollTouchEffect boolean @static
---@field public defaultScrollBounceEffect boolean @static
---@field public popupMenu string @static
---@field public popupMenu_seperator string @static
---@field public loaderErrorSign string @static
---@field public tooltipsWin string @static
---@field public defaultComboBoxVisibleItemCount number @static
---@field public touchScrollSensitivity number @static
---@field public touchDragSensitivity number @static
---@field public clickDragSensitivity number @static
---@field public allowSoftnessOnTopOrLeftSide boolean @static
---@field public bringWindowToFrontOnClick boolean @static
---@field public inputCaretSize number @static
---@field public inputHighlightColor UnityEngine.Color @static
---@field public frameTimeForAsyncUIConstruction number @static
---@field public depthSupportForPaintingMode boolean @static
---@field public soundLoader fun(url:string):UnityEngine.AudioClip @static
---@field public Items FairyGUI.UIConfig.ConfigValue[]
---@field public PreloadPackages string[]
local m = {}

function m:Load() end

---@static
function m.ClearResourceRefs() end

function m:ApplyModifiedProperties() end

FairyGUI.UIConfig = m
return m
