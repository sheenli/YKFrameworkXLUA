---@class FairyGUI.UIContentScaler : UnityEngine.MonoBehaviour
---@field public scaleFactor number @static
---@field public scaleMode FairyGUI.UIContentScaler.ScaleMode
---@field public screenMatchMode FairyGUI.UIContentScaler.ScreenMatchMode
---@field public designResolutionX number
---@field public designResolutionY number
---@field public fallbackScreenDPI number
---@field public defaultSpriteDPI number
---@field public constantScaleFactor number
---@field public ignoreOrientation boolean
local m = {}

function m:ApplyModifiedProperties() end

function m:ApplyChange() end

FairyGUI.UIContentScaler = m
return m
