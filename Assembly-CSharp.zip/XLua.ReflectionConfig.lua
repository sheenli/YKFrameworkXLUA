---@class XLua.ReflectionConfig : table
---@field public ReflectionUse System.Type[]
local m = {}

XLua.ReflectionConfig = m
return m
