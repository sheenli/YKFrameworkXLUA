---@class SevenZip.Compression.LZMA.Decoder.LiteralDecoder : System.Object
local m = {}

---@param numPosBits number
---@param numPrevBits number
function m:Create(numPosBits, numPrevBits) end

function m:Init() end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@param pos number
---@param prevByte number
---@return number
function m:DecodeNormal(rangeDecoder, pos, prevByte) end

---@param rangeDecoder SevenZip.Compression.RangeCoder.Decoder
---@param pos number
---@param prevByte number
---@param matchByte number
---@return number
function m:DecodeWithMatchByte(rangeDecoder, pos, prevByte, matchByte) end

SevenZip.Compression.LZMA.Decoder.LiteralDecoder = m
return m
