---@class FairyGUI.Utils.HtmlElementType : System.Enum
---@field public Text FairyGUI.Utils.HtmlElementType @static
---@field public Link FairyGUI.Utils.HtmlElementType @static
---@field public Image FairyGUI.Utils.HtmlElementType @static
---@field public Input FairyGUI.Utils.HtmlElementType @static
---@field public Select FairyGUI.Utils.HtmlElementType @static
---@field public Object FairyGUI.Utils.HtmlElementType @static
---@field public LinkEnd FairyGUI.Utils.HtmlElementType @static
---@field public value__ number
local m = {}

FairyGUI.Utils.HtmlElementType = m
return m
