---@class FairyGUI.RelationDef : System.Object
---@field public percent boolean
---@field public type FairyGUI.RelationType
---@field public axis number
local m = {}

---@param source FairyGUI.RelationDef
function m:copyFrom(source) end

FairyGUI.RelationDef = m
return m
