---@class FairyGUI.Image : FairyGUI.DisplayObject
---@field public texture FairyGUI.NTexture
---@field public color UnityEngine.Color
---@field public flip FairyGUI.FlipType
---@field public fillMethod FairyGUI.FillMethod
---@field public fillOrigin number
---@field public fillClockwise boolean
---@field public fillAmount number
---@field public scale9Grid System.Nullable_1_UnityEngine_Rect_
---@field public scaleByTile boolean
---@field public tileGridIndice number
local m = {}

function m:SetNativeSize() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

---@param mesh UnityEngine.Mesh
---@param localRect UnityEngine.Rect
function m:PrintTo(mesh, localRect) end

FairyGUI.Image = m
return m
