---@class YKSupportLua.LuaSceneBase : SceneBase
local m = {}

---@virtual
function m:OnDestroy() end

YKSupportLua.LuaSceneBase = m
return m
