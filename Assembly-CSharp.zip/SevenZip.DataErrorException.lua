---@class SevenZip.DataErrorException : System.ApplicationException
local m = {}

SevenZip.DataErrorException = m
return m
