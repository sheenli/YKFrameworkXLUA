---@class FairyGUI.BlendModeUtils : System.Object
---@field public Factors FairyGUI.BlendModeUtils.BlendFactor[] @static
local m = {}

---@static
---@param mat UnityEngine.Material
---@param blendMode FairyGUI.BlendMode
function m.Apply(mat, blendMode) end

---@static
---@param blendMode FairyGUI.BlendMode
---@param srcFactor UnityEngine.Rendering.BlendMode
---@param dstFactor UnityEngine.Rendering.BlendMode
function m.Override(blendMode, srcFactor, dstFactor) end

FairyGUI.BlendModeUtils = m
return m
