---@class Net.CanRequestDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param actionId number
---@param actionParam ActionParam
---@return boolean
function m:Invoke(actionId, actionParam) end

---@virtual
---@param actionId number
---@param actionParam ActionParam
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(actionId, actionParam, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return boolean
function m:EndInvoke(result) end

Net.CanRequestDelegate = m
return m
