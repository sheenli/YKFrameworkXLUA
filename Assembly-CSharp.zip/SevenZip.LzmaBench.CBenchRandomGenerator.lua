---@class SevenZip.LzmaBench.CBenchRandomGenerator : System.Object
---@field public BufferSize number
---@field public Buffer string
local m = {}

---@param bufferSize number
function m:Set(bufferSize) end

function m:Generate() end

SevenZip.LzmaBench.CBenchRandomGenerator = m
return m
