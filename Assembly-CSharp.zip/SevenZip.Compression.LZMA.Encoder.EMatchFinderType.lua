---@class SevenZip.Compression.LZMA.Encoder.EMatchFinderType : System.Enum
---@field public BT2 SevenZip.Compression.LZMA.Encoder.EMatchFinderType @static
---@field public BT4 SevenZip.Compression.LZMA.Encoder.EMatchFinderType @static
---@field public value__ number
local m = {}

SevenZip.Compression.LZMA.Encoder.EMatchFinderType = m
return m
