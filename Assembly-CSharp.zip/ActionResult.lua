---@class ActionResult : ActionParam
local m = {}

ActionResult = m
return m
