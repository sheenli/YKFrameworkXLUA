---@class SevenZip.LzmaBench.CRandomGenerator : System.Object
local m = {}

function m:Init() end

---@return number
function m:GetRnd() end

SevenZip.LzmaBench.CRandomGenerator = m
return m
