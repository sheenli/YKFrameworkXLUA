---@class FairyGUI.DisplayListItem : System.Object
---@field public packageItem FairyGUI.PackageItem
---@field public type string
---@field public desc FairyGUI.Utils.XML
---@field public listItemCount number
local m = {}

FairyGUI.DisplayListItem = m
return m
