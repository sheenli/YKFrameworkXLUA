---@class FairyGUI.Utils.HtmlElement : System.Object
---@field public type FairyGUI.Utils.HtmlElementType
---@field public name string
---@field public text string
---@field public format FairyGUI.TextFormat
---@field public charIndex number
---@field public htmlObject FairyGUI.Utils.IHtmlObject
---@field public status number
---@field public space number
---@field public position UnityEngine.Vector2
---@field public isEntity boolean
local m = {}

---@param attrName string
---@return any
function m:Get(attrName) end

---@param attrName string
---@param attrValue any
function m:Set(attrName, attrValue) end

---@overload fun(attrName:string, defValue:string):string
---@param attrName string
---@return string
function m:GetString(attrName) end

---@overload fun(attrName:string, defValue:number):number
---@param attrName string
---@return number
function m:GetInt(attrName) end

---@overload fun(attrName:string, defValue:number):number
---@param attrName string
---@return number
function m:GetFloat(attrName) end

---@overload fun(attrName:string, defValue:boolean):boolean
---@param attrName string
---@return boolean
function m:GetBool(attrName) end

---@param attrName string
---@param defValue UnityEngine.Color
---@return UnityEngine.Color
function m:GetColor(attrName, defValue) end

function m:FetchAttributes() end

---@static
---@param type FairyGUI.Utils.HtmlElementType
---@return FairyGUI.Utils.HtmlElement
function m.GetElement(type) end

---@static
---@param element FairyGUI.Utils.HtmlElement
function m.ReturnElement(element) end

---@static
---@param elements FairyGUI.Utils.HtmlElement[]
function m.ReturnElements(elements) end

FairyGUI.Utils.HtmlElement = m
return m
