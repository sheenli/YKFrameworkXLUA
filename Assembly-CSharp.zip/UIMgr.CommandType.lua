---@class UIMgr.CommandType : System.Enum
---@field public Create UIMgr.CommandType @static
---@field public Show UIMgr.CommandType @static
---@field public Hide UIMgr.CommandType @static
---@field public Delete UIMgr.CommandType @static
---@field public HideList UIMgr.CommandType @static
---@field public value__ number
local m = {}

UIMgr.CommandType = m
return m
