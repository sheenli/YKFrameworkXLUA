---@class YKSupportLua : System.Object
local m = {}

---@overload fun(uiName:string, param:any, lunFun:XLua.LuaTable, hideAll:boolean) @static
---@overload fun(uiName:string, param:any, lunFun:XLua.LuaTable) @static
---@static
---@param uiName string
---@param param any
---@param lunFun XLua.LuaTable
---@param hideAll boolean
---@param hideDotDel boolean
function m.ShowWindow(uiName, param, lunFun, hideAll, hideDotDel) end

---@static
---@param sceneName string
---@param param any
---@param lunFun XLua.LuaTable
function m.GotoScene(sceneName, param, lunFun) end

YKSupportLua = m
return m
