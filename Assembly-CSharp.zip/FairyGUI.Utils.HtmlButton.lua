---@class FairyGUI.Utils.HtmlButton : System.Object
---@field public CLICK_EVENT string @static
---@field public resource string @static
---@field public button FairyGUI.GComponent
---@field public displayObject FairyGUI.DisplayObject
---@field public element FairyGUI.Utils.HtmlElement
---@field public width number
---@field public height number
local m = {}

---@virtual
---@param owner FairyGUI.RichTextField
---@param element FairyGUI.Utils.HtmlElement
function m:Create(owner, element) end

---@virtual
---@param x number
---@param y number
function m:SetPosition(x, y) end

---@virtual
function m:Add() end

---@virtual
function m:Remove() end

---@virtual
function m:Release() end

---@virtual
function m:Dispose() end

FairyGUI.Utils.HtmlButton = m
return m
