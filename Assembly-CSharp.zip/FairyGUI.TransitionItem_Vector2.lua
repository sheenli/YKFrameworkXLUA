---@class FairyGUI.TransitionItem_Vector2 : FairyGUI.TransitionItem
---@field public getter fun():UnityEngine.Vector2
---@field public setter fun(pNewValue:UnityEngine.Vector2)
local m = {}

FairyGUI.TransitionItem_Vector2 = m
return m
