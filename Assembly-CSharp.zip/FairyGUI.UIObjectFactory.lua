---@class FairyGUI.UIObjectFactory : System.Object
local m = {}

---@overload fun(url:string, creator:(fun():FairyGUI.GComponent)) @static
---@static
---@param url string
---@param type System.Type
function m.SetPackageItemExtension(url, type) end

---@overload fun(creator:(fun():FairyGUI.GLoader)) @static
---@static
---@param type System.Type
function m.SetLoaderExtension(type) end

---@overload fun(type:string):FairyGUI.GObject @static
---@static
---@param pi FairyGUI.PackageItem
---@return FairyGUI.GObject
function m.NewObject(pi) end

FairyGUI.UIObjectFactory = m
return m
