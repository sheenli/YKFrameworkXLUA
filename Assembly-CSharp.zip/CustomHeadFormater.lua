---@class CustomHeadFormater : System.Object
local m = {}

---@overload fun(data:string):boolean, PackageHead, System.Byte__ @virtual
---@virtual
---@param data string
---@param type NetworkType
---@return boolean, PackageHead, System.Object
function m:TryParse(data, type) end

---@virtual
---@return string
function m:BuildHearbeatPackage() end

CustomHeadFormater = m
return m
