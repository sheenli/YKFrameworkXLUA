---@class Sproto.ProtocolFunctionDictionary : System.Object
---@field public Item Sproto.ProtocolFunctionDictionary.MetaInfo
---@field public Item number
local m = {}

---@param tag number
function m:SetProtocol(tag) end

---@param tag number
function m:SetRequest(tag) end

---@param tag number
function m:SetResponse(tag) end

---@overload fun(tag:number, buffer:string):Sproto.SprotoTypeBase
---@param tag number
---@param buffer string
---@param offset number
---@return Sproto.SprotoTypeBase
function m:GenResponse(tag, buffer, offset) end

---@overload fun(tag:number, buffer:string):Sproto.SprotoTypeBase
---@param tag number
---@param buffer string
---@param offset number
---@return Sproto.SprotoTypeBase
function m:GenRequest(tag, buffer, offset) end

Sproto.ProtocolFunctionDictionary = m
return m
