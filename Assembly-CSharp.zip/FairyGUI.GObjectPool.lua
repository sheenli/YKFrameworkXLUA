---@class FairyGUI.GObjectPool : System.Object
---@field public initCallback fun(obj:FairyGUI.GObject)
---@field public count number
local m = {}

function m:Clear() end

---@param url string
---@return FairyGUI.GObject
function m:GetObject(url) end

---@param obj FairyGUI.GObject
function m:ReturnObject(obj) end

FairyGUI.GObjectPool = m
return m
