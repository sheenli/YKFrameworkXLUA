---@class Sproto.SprotoTypeBase : System.Object
local m = {}

---@overload fun(buffer:string):number
---@overload fun(reader:Sproto.SprotoTypeReader):number
---@param buffer string
---@param offset number
---@return number
function m:init(buffer, offset) end

---@overload fun():string
---@abstract
---@param stream Sproto.SprotoStream
---@return number
function m:encode(stream) end

function m:clear() end

Sproto.SprotoTypeBase = m
return m
