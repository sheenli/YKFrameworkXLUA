---@class Sproto.SprotoRpc.RpcRequest : System.Object
local m = {}

---@overload fun(request:Sproto.SprotoTypeBase):string
---@overload fun():string
---@param request Sproto.SprotoTypeBase
---@param session System.Nullable_1_System_Int64_
---@return string
function m:Invoke(request, session) end

Sproto.SprotoRpc.RpcRequest = m
return m
