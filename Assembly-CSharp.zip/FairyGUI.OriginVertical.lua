---@class FairyGUI.OriginVertical : System.Enum
---@field public Top FairyGUI.OriginVertical @static
---@field public Bottom FairyGUI.OriginVertical @static
---@field public value__ number
local m = {}

FairyGUI.OriginVertical = m
return m
