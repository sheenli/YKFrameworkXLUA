---@class ComparisonInfo : System.Object
---@field public flag number
---@field public needDecompressionList ABInfo[]
---@field public Size number
---@field public isNotHotUpdata boolean
---@field public SizeString string
local m = {}

ComparisonInfo = m
return m
