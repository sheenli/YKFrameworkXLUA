---@class LuaMgr : System.Object
---@field public Instance LuaMgr @static
---@field public mLua XLua.LuaEnv
local m = {}

function m:Init() end

function m:OnDestroy() end

---@param path string
---@param ab UnityEngine.AssetBundle
function m:AddFile(path, ab) end

---@param fileName string
---@return string
function m:GetLuaFileByte(fileName) end

function m:StartGame() end

---@param root string
---@param luaPath string
---@param dic System.Collections.Generic.Dictionary_2_System_String_System_Byte___
---@return System.Collections.Generic.Dictionary_2_System_String_System_Byte___
function m:EeditorLoadLuaFile(root, luaPath, dic) end

function m:GC() end

LuaMgr = m
return m
