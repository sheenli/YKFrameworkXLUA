---@class FairyGUI.CaptureCamera : UnityEngine.MonoBehaviour
---@field public Name string @static
---@field public LayerName string @static
---@field public HiddenLayerName string @static
---@field public layer number @static
---@field public hiddenLayer number @static
---@field public cachedTransform UnityEngine.Transform
---@field public cachedCamera UnityEngine.Camera
local m = {}

---@static
function m.CheckMain() end

---@static
---@param width number
---@param height number
---@param stencilSupport boolean
---@return UnityEngine.RenderTexture
function m.CreateRenderTexture(width, height, stencilSupport) end

---@static
---@param target FairyGUI.DisplayObject
---@param texture UnityEngine.RenderTexture
---@param offset UnityEngine.Vector2
function m.Capture(target, texture, offset) end

FairyGUI.CaptureCamera = m
return m
