---@class FairyGUI.UIPackage : System.Object
---@field public id string
---@field public name string
---@field public assetPath string
---@field public customId string
local m = {}

---@static
---@param id string
---@return FairyGUI.UIPackage
function m.GetById(id) end

---@static
---@param name string
---@return FairyGUI.UIPackage
function m.GetByName(name) end

---@overload fun(desc:UnityEngine.AssetBundle, res:UnityEngine.AssetBundle):FairyGUI.UIPackage @static
---@overload fun(desc:UnityEngine.AssetBundle, res:UnityEngine.AssetBundle, mainAssetName:string):FairyGUI.UIPackage @static
---@overload fun(bundle:UnityEngine.AssetBundle, unloadBundleAfterLoaded:boolean):FairyGUI.UIPackage @static
---@overload fun(desc:UnityEngine.AssetBundle, res:UnityEngine.AssetBundle, unloadBundleAfterLoaded:boolean):FairyGUI.UIPackage @static
---@overload fun(desc:UnityEngine.AssetBundle, res:UnityEngine.AssetBundle, mainAssetName:string, unloadBundleAfterLoaded:boolean):FairyGUI.UIPackage @static
---@overload fun(descFilePath:string):FairyGUI.UIPackage @static
---@overload fun(assetPath:string, loadFunc:(fun(name:string, extension:string, type:System.Type):any)):FairyGUI.UIPackage @static
---@overload fun(descData:string, assetNamePrefix:string, loadFunc:(fun(name:string, extension:string, type:System.Type):any)):FairyGUI.UIPackage @static
---@static
---@param bundle UnityEngine.AssetBundle
---@return FairyGUI.UIPackage
function m.AddPackage(bundle) end

---@overload fun(packageIdOrName:string, allowDestroyingAssets:boolean) @static
---@static
---@param packageIdOrName string
function m.RemovePackage(packageIdOrName) end

---@overload fun(allowDestroyAssets:boolean) @static
---@static
function m.RemoveAllPackages() end

---@static
---@return FairyGUI.UIPackage[]
function m.GetPackages() end

---@overload fun(pkgName:string, resName:string, userClass:System.Type):FairyGUI.GObject @static
---@overload fun(resName:string):FairyGUI.GObject
---@overload fun(resName:string, userClass:System.Type):FairyGUI.GObject
---@static
---@param pkgName string
---@param resName string
---@return FairyGUI.GObject
function m.CreateObject(pkgName, resName) end

---@overload fun(url:string, userClass:System.Type):FairyGUI.GObject @static
---@overload fun(url:string, callback:(fun(result:FairyGUI.GObject))) @static
---@static
---@param url string
---@return FairyGUI.GObject
function m.CreateObjectFromURL(url) end

---@overload fun(resName:string, callback:(fun(result:FairyGUI.GObject)))
---@static
---@param pkgName string
---@param resName string
---@param callback fun(result:FairyGUI.GObject)
function m.CreateObjectAsync(pkgName, resName, callback) end

---@overload fun(resName:string):any
---@overload fun(item:FairyGUI.PackageItem):any
---@static
---@param pkgName string
---@param resName string
---@return any
function m.GetItemAsset(pkgName, resName) end

---@static
---@param url string
---@return any
function m.GetItemAssetByURL(url) end

---@static
---@param pkgName string
---@param resName string
---@return string
function m.GetItemURL(pkgName, resName) end

---@static
---@param url string
---@return FairyGUI.PackageItem
function m.GetItemByURL(url) end

---@static
---@param url string
---@return string
function m.NormalizeURL(url) end

---@static
---@param source FairyGUI.Utils.XML
function m.SetStringsSource(source) end

---@param itemId string
---@return FairyGUI.PixelHitTestData
function m:GetPixelHitTestData(itemId) end

---@return FairyGUI.PackageItem[]
function m:GetItems() end

---@param itemId string
---@return FairyGUI.PackageItem
function m:GetItem(itemId) end

---@param itemName string
---@return FairyGUI.PackageItem
function m:GetItemByName(itemName) end

FairyGUI.UIPackage = m
return m
