---@class FairyGUI.Utils.XMLList : System.Object
---@field public rawList FairyGUI.Utils.XML[]
---@field public Count number
---@field public Item FairyGUI.Utils.XML
local m = {}

---@param xml FairyGUI.Utils.XML
function m:Add(xml) end

function m:Clear() end

---@overload fun(selector:string):FairyGUI.Utils.XMLList.Enumerator
---@return FairyGUI.Utils.XMLList.Enumerator
function m:GetEnumerator() end

---@param selector string
---@return FairyGUI.Utils.XMLList
function m:Filter(selector) end

---@param selector string
---@return FairyGUI.Utils.XML
function m:Find(selector) end

FairyGUI.Utils.XMLList = m
return m
