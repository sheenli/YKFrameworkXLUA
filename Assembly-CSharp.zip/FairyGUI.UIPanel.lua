---@class FairyGUI.UIPanel : UnityEngine.MonoBehaviour
---@field public packageName string
---@field public componentName string
---@field public fitScreen FairyGUI.FitScreen
---@field public sortingOrder number
---@field public container FairyGUI.Container
---@field public ui FairyGUI.GComponent
---@field public EM_sortingOrder number
local m = {}

function m:CreateUI() end

---@param value number
---@param apply boolean
function m:SetSortingOrder(value, apply) end

---@param value FairyGUI.HitTestMode
function m:SetHitTestMode(value) end

function m:CacheNativeChildrenRenderers() end

---@param sortingOrderChanged boolean
---@param fitScreenChanged boolean
function m:ApplyModifiedProperties(sortingOrderChanged, fitScreenChanged) end

---@param delta UnityEngine.Vector3
function m:MoveUI(delta) end

---@return UnityEngine.Vector3
function m:GetUIWorldPosition() end

---@virtual
function m:EM_BeforeUpdate() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:EM_Update(context) end

---@virtual
function m:EM_Reload() end

FairyGUI.UIPanel = m
return m
