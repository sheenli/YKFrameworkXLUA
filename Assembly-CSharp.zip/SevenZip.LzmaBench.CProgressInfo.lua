---@class SevenZip.LzmaBench.CProgressInfo : System.Object
---@field public ApprovedStart number
---@field public InSize number
---@field public Time System.DateTime
local m = {}

function m:Init() end

---@virtual
---@param inSize number
---@param outSize number
function m:SetProgress(inSize, outSize) end

SevenZip.LzmaBench.CProgressInfo = m
return m
