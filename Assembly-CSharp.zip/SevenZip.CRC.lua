---@class SevenZip.CRC : System.Object
---@field public Table number[] @static
local m = {}

function m:Init() end

---@param b number
function m:UpdateByte(b) end

---@param data string
---@param offset number
---@param size number
function m:Update(data, offset, size) end

---@return number
function m:GetDigest() end

SevenZip.CRC = m
return m
