---@class SevenZip.LzmaAlone : System.Object
local m = {}

SevenZip.LzmaAlone = m
return m
