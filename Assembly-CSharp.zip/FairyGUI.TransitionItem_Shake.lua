---@class FairyGUI.TransitionItem_Shake : FairyGUI.TransitionItem
---@field public shakeAmplitude number
---@field public shakePeriod number
local m = {}

---@virtual
---@param owner FairyGUI.Transition
function m:Setup(owner) end

function m:Start() end

---@param resetPosition boolean
function m:Stop(resetPosition) end

FairyGUI.TransitionItem_Shake = m
return m
