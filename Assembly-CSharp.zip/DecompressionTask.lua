---@class DecompressionTask : System.Object
---@field public downLoadInfo ABInfo
---@field public mFileName string
---@field public IsFailure boolean
---@field public IsFinished boolean
local m = {}

---@virtual
---@return string
function m:FailureInfo() end

---@virtual
function m:OnExecute() end

---@return System.Collections.IEnumerator
function m:Start() end

---@virtual
function m:Rest() end

---@virtual
---@return string
function m:TaskName() end

DecompressionTask = m
return m
