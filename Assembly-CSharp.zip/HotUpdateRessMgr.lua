---@class HotUpdateRessMgr : System.Object
---@field public Instance HotUpdateRessMgr @static
---@field public verInfo VerInfo
---@field public downLoadInfo RemotelyVersionInfo.RemotelyInfo
local m = {}

---@param callBack fun()
function m:Init(callBack) end

---@param callBack fun()
function m:RefreshLocalVerInfo(callBack) end

---@param localVer VerInfo
---@param callBack fun(obj:HotUpdateRessMgr.DecompressionOrDownInfo)
function m:GetDownList(localVer, callBack) end

---@param localVer VerInfo
---@param callBack fun(obj:HotUpdateRessMgr.DecompressionOrDownInfo)
function m:GetDecompressionTaskList(localVer, callBack) end

---@param info HotUpdateRessMgr.DecompressionOrDownInfo
---@param saveVer boolean
function m:Save(info, saveVer) end

HotUpdateRessMgr = m
return m
