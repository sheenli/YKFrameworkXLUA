---@class Sproto.SprotoStream : System.Object
---@field public Position number
---@field public Buffer string
---@field public Item number
local m = {}

---@param v number
function m:WriteByte(v) end

---@param data string
---@param offset number
---@param count number
function m:Write(data, offset, count) end

---@param offset number
---@param loc System.IO.SeekOrigin
---@return number
function m:Seek(offset, loc) end

---@param buffer string
---@param offset number
---@param count number
function m:Read(buffer, offset, count) end

---@param position number
---@param up_count number
function m:MoveUp(position, up_count) end

Sproto.SprotoStream = m
return m
