---@class ResponseContentType : System.Enum
---@field public Stream ResponseContentType @static
---@field public Json ResponseContentType @static
---@field public value__ number
local m = {}

ResponseContentType = m
return m
