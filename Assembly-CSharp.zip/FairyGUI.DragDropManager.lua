---@class FairyGUI.DragDropManager : System.Object
---@field public inst FairyGUI.DragDropManager @static
---@field public dragAgent FairyGUI.GLoader
---@field public dragging boolean
local m = {}

---@overload fun(source:FairyGUI.GObject, icon:string, sourceData:any)
---@param source FairyGUI.GObject
---@param icon string
---@param sourceData any
---@param touchPointID number
function m:StartDrag(source, icon, sourceData, touchPointID) end

function m:Cancel() end

FairyGUI.DragDropManager = m
return m
