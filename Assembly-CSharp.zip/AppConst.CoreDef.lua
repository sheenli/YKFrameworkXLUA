---@class AppConst.CoreDef : System.Object
---@field public READINFOED string @static
---@field public INITHOTUPDATA string @static
---@field public INSTALLATIONED string @static
---@field public DOWNED string @static
---@field public LoadLuaFinished string @static
---@field public CfgABName string @static
---@field public CfgAssetName string @static
---@field public EditorResCfgPath string @static
---@field public CfgExternalFileName string @static
local m = {}

AppConst.CoreDef = m
return m
