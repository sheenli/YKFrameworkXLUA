---@class ResInfoData : System.Object
---@field public ABName string
---@field public path string
---@field public name string
---@field public type string
---@field public isKeepInMemory boolean
---@field public isResourcesPath boolean
---@field public isFairyGuiPack boolean
local m = {}

---@param data ResInfoData
---@return boolean
function m:IsDirty(data) end

ResInfoData = m
return m
