---@class FairyGUI.Utils.UBBParser : System.Object
---@field public inst FairyGUI.Utils.UBBParser @static
---@field public defaultImgWidth number
---@field public defaultImgHeight number
local m = {}

---@param text string
---@return string
function m:Parse(text) end

FairyGUI.Utils.UBBParser = m
return m
