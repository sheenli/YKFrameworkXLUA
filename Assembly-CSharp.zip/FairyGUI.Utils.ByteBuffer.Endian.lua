---@class FairyGUI.Utils.ByteBuffer.Endian : System.Enum
---@field public BIG_ENDIAN FairyGUI.Utils.ByteBuffer.Endian @static
---@field public LITTLE_ENDIAN FairyGUI.Utils.ByteBuffer.Endian @static
---@field public value__ number
local m = {}

FairyGUI.Utils.ByteBuffer.Endian = m
return m
