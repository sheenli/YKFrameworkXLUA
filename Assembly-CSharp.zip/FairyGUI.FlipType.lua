---@class FairyGUI.FlipType : System.Enum
---@field public None FairyGUI.FlipType @static
---@field public Horizontal FairyGUI.FlipType @static
---@field public Vertical FairyGUI.FlipType @static
---@field public Both FairyGUI.FlipType @static
---@field public value__ number
local m = {}

FairyGUI.FlipType = m
return m
