---@class BGMMgr : UnityEngine.MonoBehaviour
---@field public Instance BGMMgr @static
---@field public IsValid boolean @static
---@field public scourceCtrls BGMMgr.SoundSourceCtrl[]
---@field public Volume number
---@field public IsOn boolean
local m = {}

function m:Awake() end

function m:OnDestroy() end

---@param strBGMName string
function m:PlayBGMAsync(strBGMName) end

function m:StopBGM() end

function m:PauseBGM() end

function m:Resume() end

function m:Release() end

function m:FixedUpdate() end

BGMMgr = m
return m
