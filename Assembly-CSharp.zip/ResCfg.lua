---@class ResCfg : System.Object
---@field public groups ResGroupCfg[]
---@field public resources ResInfoData[]
local m = {}

---@param groupName string
---@return boolean
function m:HasGroup(groupName) end

---@param groupName string
---@return ResGroupCfg
function m:GetGroupInfo(groupName) end

---@return string[]
function m:GetAllGroupNames() end

---@param groupName string
---@return string[]
function m:GetAssetsNames(groupName) end

---@param assetName string
---@return ResInfoData
function m:GetResInfo(assetName) end

ResCfg = m
return m
