---@class AsynTask : TaskBase
local m = {}

---@virtual
function m:OnExecute() end

AsynTask = m
return m
