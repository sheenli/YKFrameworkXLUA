---@class SevenZip.Compression.LZMA.Encoder.LenEncoder : System.Object
local m = {}

---@param numPosStates number
function m:Init(numPosStates) end

---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
---@param posState number
function m:Encode(rangeEncoder, symbol, posState) end

---@param posState number
---@param numSymbols number
---@param prices number[]
---@param st number
function m:SetPrices(posState, numSymbols, prices, st) end

SevenZip.Compression.LZMA.Encoder.LenEncoder = m
return m
