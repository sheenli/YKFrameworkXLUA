---@class SevenZip.Compression.LZMA.Encoder.LiteralEncoder.Encoder2 : System.ValueType
local m = {}

function m:Create() end

function m:Init() end

---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param symbol number
function m:Encode(rangeEncoder, symbol) end

---@param rangeEncoder SevenZip.Compression.RangeCoder.Encoder
---@param matchByte number
---@param symbol number
function m:EncodeMatched(rangeEncoder, matchByte, symbol) end

---@param matchMode boolean
---@param matchByte number
---@param symbol number
---@return number
function m:GetPrice(matchMode, matchByte, symbol) end

SevenZip.Compression.LZMA.Encoder.LiteralEncoder.Encoder2 = m
return m
