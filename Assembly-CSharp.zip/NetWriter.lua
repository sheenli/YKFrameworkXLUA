---@class NetWriter : System.Object
---@field public Instance NetWriter @static
---@field public IsGet boolean @static
---@field public ResponseContentType ResponseContentType @static
---@field public MsgId number @static
---@field public UserID number @static
---@field public SessionID string @static
---@field public St string @static
local m = {}

---@static
---@param value string
function m.SetMd5Key(value) end

---@static
function m.resetData() end

---@static
---@param pszSessionID string
function m.setSessionID(pszSessionID) end

---@static
---@param value number
function m.setUserID(value) end

---@static
---@param pszTime string
function m.setStime(pszTime) end

---@param buffer string
function m:SetHeadBuffer(buffer) end

---@param buffer string
function m:SetBodyData(buffer) end

---@param szKey string
---@param nValue number
function m:writeInt32(szKey, nValue) end

---@param szKey string
---@param fvalue number
function m:writeFloat(szKey, fvalue) end

---@param szKey string
---@param szValue string
function m:writeString(szKey, szValue) end

---@param szKey string
---@param nValue number
function m:writeInt64(szKey, nValue) end

---@param szKey string
---@param sValue number
function m:writeWord(szKey, sValue) end

---@param szKey string
---@param buf string
---@param nSize number
function m:writeBuf(szKey, buf, nSize) end

---@overload fun(szUrl:string, respContentType:ResponseContentType, isGet:boolean) @static
---@overload fun(szUrl:string, respContentType:ResponseContentType) @static
---@static
---@param szUrl string
function m.SetUrl(szUrl) end

---@static
---@return string
function m.GetUrl() end

---@static
---@return boolean
function m.IsSocket() end

---@param str string
---@return string
function m:url_encode(str) end

---@overload fun(input:string):string @static
---@static
---@param buf string
---@return string
function m.getMd5String(buf) end

---@return string
function m:PostData() end

NetWriter = m
return m
