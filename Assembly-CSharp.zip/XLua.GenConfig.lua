---@class XLua.GenConfig : table
---@field public LuaCallCSharp System.Type[]
---@field public CSharpCallLua System.Type[]
---@field public BlackList string[][]
local m = {}

XLua.GenConfig = m
return m
