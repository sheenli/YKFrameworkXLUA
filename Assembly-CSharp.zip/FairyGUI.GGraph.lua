---@class FairyGUI.GGraph : FairyGUI.GObject
---@field public color UnityEngine.Color
---@field public shape FairyGUI.Shape
local m = {}

---@param target FairyGUI.GObject
function m:ReplaceMe(target) end

---@param target FairyGUI.GObject
function m:AddBeforeMe(target) end

---@param target FairyGUI.GObject
function m:AddAfterMe(target) end

---@param obj FairyGUI.DisplayObject
function m:SetNativeObject(obj) end

---@param aWidth number
---@param aHeight number
---@param lineSize number
---@param lineColor UnityEngine.Color
---@param fillColor UnityEngine.Color
function m:DrawRect(aWidth, aHeight, lineSize, lineColor, fillColor) end

---@param aWidth number
---@param aHeight number
---@param fillColor UnityEngine.Color
---@param corner number[]
function m:DrawRoundRect(aWidth, aHeight, fillColor, corner) end

---@param aWidth number
---@param aHeight number
---@param fillColor UnityEngine.Color
function m:DrawEllipse(aWidth, aHeight, fillColor) end

---@param aWidth number
---@param aHeight number
---@param points UnityEngine.Vector2[]
---@param fillColor UnityEngine.Color
function m:DrawPolygon(aWidth, aHeight, points, fillColor) end

---@virtual
---@param xml FairyGUI.Utils.XML
function m:Setup_BeforeAdd(xml) end

FairyGUI.GGraph = m
return m
