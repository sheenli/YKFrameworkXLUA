---@class FairyGUI.GProgressBar : FairyGUI.GComponent
---@field public titleType FairyGUI.ProgressTitleType
---@field public max number
---@field public value number
---@field public reverse boolean
local m = {}

---@param value number
---@param duration number
---@return DG.Tweening.Tweener
function m:TweenValue(value, duration) end

---@param newValue number
function m:Update(newValue) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:ConstructFromXML(cxml) end

---@virtual
---@param cxml FairyGUI.Utils.XML
function m:Setup_AfterAdd(cxml) end

---@virtual
function m:Dispose() end

FairyGUI.GProgressBar = m
return m
