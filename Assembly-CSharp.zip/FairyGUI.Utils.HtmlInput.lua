---@class FairyGUI.Utils.HtmlInput : System.Object
---@field public defaultBorderSize number @static
---@field public defaultBorderColor UnityEngine.Color @static
---@field public textInput FairyGUI.GTextInput
---@field public displayObject FairyGUI.DisplayObject
---@field public element FairyGUI.Utils.HtmlElement
---@field public width number
---@field public height number
local m = {}

---@virtual
---@param owner FairyGUI.RichTextField
---@param element FairyGUI.Utils.HtmlElement
function m:Create(owner, element) end

---@virtual
---@param x number
---@param y number
function m:SetPosition(x, y) end

---@virtual
function m:Add() end

---@virtual
function m:Remove() end

---@virtual
function m:Release() end

---@virtual
function m:Dispose() end

FairyGUI.Utils.HtmlInput = m
return m
