---@class FairyGUI.EventBridge : System.Object
---@field public owner FairyGUI.EventDispatcher
---@field public isEmpty boolean
local m = {}

---@param callback fun(context:FairyGUI.EventContext)
function m:AddCapture(callback) end

---@param callback fun(context:FairyGUI.EventContext)
function m:RemoveCapture(callback) end

---@overload fun(callback:(fun()))
---@param callback fun(context:FairyGUI.EventContext)
function m:Add(callback) end

---@overload fun(callback:(fun()))
---@param callback fun(context:FairyGUI.EventContext)
function m:Remove(callback) end

function m:Clear() end

---@param context FairyGUI.EventContext
function m:CallInternal(context) end

---@param context FairyGUI.EventContext
function m:CallCaptureInternal(context) end

FairyGUI.EventBridge = m
return m
