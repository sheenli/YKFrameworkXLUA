---@class FairyGUI.SelectionShape : FairyGUI.DisplayObject
---@field public rects UnityEngine.Rect[]
---@field public color UnityEngine.Color
local m = {}

function m:Clear() end

---@virtual
---@param context FairyGUI.UpdateContext
function m:Update(context) end

FairyGUI.SelectionShape = m
return m
