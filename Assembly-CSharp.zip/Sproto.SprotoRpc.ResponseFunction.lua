---@class Sproto.SprotoRpc.ResponseFunction : System.MulticastDelegate
local m = {}

---@virtual
---@param response Sproto.SprotoTypeBase
---@return string
function m:Invoke(response) end

---@virtual
---@param response Sproto.SprotoTypeBase
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(response, callback, object) end

---@virtual
---@param result System.IAsyncResult
---@return string
function m:EndInvoke(result) end

Sproto.SprotoRpc.ResponseFunction = m
return m
