---@class FairyGUI.TransitionItem_Animation : FairyGUI.TransitionItem
---@field public frame number
---@field public playing boolean
local m = {}

FairyGUI.TransitionItem_Animation = m
return m
