---@class EntranceScene : SceneBase
local m = {}

function m:DownLoadApk() end

---@param arg1 string
---@param arg2 string
function m:DownLoadFailue(arg1, arg2) end

function m:StartGame() end

---@overload fun()
---@param delAllFile boolean
function m:DeleteAllKey(delAllFile) end

EntranceScene = m
return m
