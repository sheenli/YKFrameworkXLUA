---@class System.KnownTerminals : System.Object
---@field public linux string @static
---@field public xterm string @static
---@field public ansi string @static
local m = {}

System.KnownTerminals = m
return m
