---@class System.MonoListItem : System.Object
local m = {}

System.MonoListItem = m
return m
