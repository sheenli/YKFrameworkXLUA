---@class System.MonoAsyncCall : System.Object
local m = {}

System.MonoAsyncCall = m
return m
