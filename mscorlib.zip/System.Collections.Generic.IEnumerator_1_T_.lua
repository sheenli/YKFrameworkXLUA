---@class System.Collections.Generic.IEnumerator_1_T_ : table
---@field public Current any
local m = {}

System.Collections.Generic.IEnumerator_1_T_ = m
return m
