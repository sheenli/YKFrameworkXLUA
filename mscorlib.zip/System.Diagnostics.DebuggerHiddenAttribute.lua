---@class System.Diagnostics.DebuggerHiddenAttribute : System.Attribute
local m = {}

System.Diagnostics.DebuggerHiddenAttribute = m
return m
