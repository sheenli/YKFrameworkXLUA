---@class System.Runtime.InteropServices.ComImportAttribute : System.Attribute
local m = {}

System.Runtime.InteropServices.ComImportAttribute = m
return m
