---@class System.Collections.CollectionBase : System.Object
---@field public Count number
---@field public Capacity number
local m = {}

---@virtual
---@return System.Collections.IEnumerator
function m:GetEnumerator() end

---@virtual
function m:Clear() end

---@virtual
---@param index number
function m:RemoveAt(index) end

System.Collections.CollectionBase = m
return m
