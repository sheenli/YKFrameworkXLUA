---@class System.DivideByZeroException : System.ArithmeticException
local m = {}

System.DivideByZeroException = m
return m
