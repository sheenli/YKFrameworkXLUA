---@class System.Runtime.CompilerServices.UnsafeValueTypeAttribute : System.Attribute
local m = {}

System.Runtime.CompilerServices.UnsafeValueTypeAttribute = m
return m
