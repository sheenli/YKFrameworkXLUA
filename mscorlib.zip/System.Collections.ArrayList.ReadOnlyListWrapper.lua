---@class System.Collections.ArrayList.ReadOnlyListWrapper : System.Collections.ArrayList.FixedSizeListWrapper
---@field public IsReadOnly boolean
---@field public Item any
local m = {}

System.Collections.ArrayList.ReadOnlyListWrapper = m
return m
