---@class System.ControlCharacters : System.Object
---@field public Intr number @static
---@field public Quit number @static
---@field public Erase number @static
---@field public Kill number @static
---@field public EOF number @static
---@field public Time number @static
---@field public Min number @static
---@field public SWTC number @static
---@field public Start number @static
---@field public Stop number @static
---@field public Susp number @static
---@field public EOL number @static
---@field public Reprint number @static
---@field public Discard number @static
---@field public WErase number @static
---@field public LNext number @static
---@field public EOL2 number @static
local m = {}

System.ControlCharacters = m
return m
