---@class System.AccessViolationException : System.SystemException
local m = {}

System.AccessViolationException = m
return m
