---@class System.Collections.CollectionDebuggerView : System.Object
---@field public Items any[]
local m = {}

System.Collections.CollectionDebuggerView = m
return m
