---@class Mono.Runtime : System.Object
local m = {}

Mono.Runtime = m
return m
