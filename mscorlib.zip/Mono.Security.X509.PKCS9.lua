---@class Mono.Security.X509.PKCS9 : System.Object
---@field public friendlyName string @static
---@field public localKeyId string @static
local m = {}

Mono.Security.X509.PKCS9 = m
return m
