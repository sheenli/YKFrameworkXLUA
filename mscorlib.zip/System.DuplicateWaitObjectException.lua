---@class System.DuplicateWaitObjectException : System.ArgumentException
local m = {}

System.DuplicateWaitObjectException = m
return m
