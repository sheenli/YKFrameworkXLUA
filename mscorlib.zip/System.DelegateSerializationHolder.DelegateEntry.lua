---@class System.DelegateSerializationHolder.DelegateEntry : System.Object
---@field public target any
---@field public delegateEntry System.DelegateSerializationHolder.DelegateEntry
local m = {}

---@param info System.Runtime.Serialization.SerializationInfo
---@return fun(args:any[]):any
function m:DeserializeDelegate(info) end

System.DelegateSerializationHolder.DelegateEntry = m
return m
