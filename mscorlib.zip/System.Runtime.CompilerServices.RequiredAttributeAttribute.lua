---@class System.Runtime.CompilerServices.RequiredAttributeAttribute : System.Attribute
---@field public RequiredContract System.Type
local m = {}

System.Runtime.CompilerServices.RequiredAttributeAttribute = m
return m
