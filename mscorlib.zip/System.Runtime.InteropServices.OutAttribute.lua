---@class System.Runtime.InteropServices.OutAttribute : System.Attribute
local m = {}

System.Runtime.InteropServices.OutAttribute = m
return m
