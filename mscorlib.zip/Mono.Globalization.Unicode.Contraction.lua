---@class Mono.Globalization.Unicode.Contraction : System.Object
---@field public Source number[]
---@field public Replacement string
---@field public SortKey string
local m = {}

Mono.Globalization.Unicode.Contraction = m
return m
