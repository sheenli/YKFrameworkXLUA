---@class System.Nullable : System.Object
local m = {}

---@static
---@param value1 System.Nullable_1_T_
---@param value2 System.Nullable_1_T_
---@return number
function m.Compare(value1, value2) end

---@static
---@param value1 System.Nullable_1_T_
---@param value2 System.Nullable_1_T_
---@return boolean
function m.Equals(value1, value2) end

---@static
---@param nullableType System.Type
---@return System.Type
function m.GetUnderlyingType(nullableType) end

System.Nullable = m
return m
