---@class System.Collections.SortedList : System.Object
---@field public Count number
---@field public IsSynchronized boolean
---@field public SyncRoot any
---@field public IsFixedSize boolean
---@field public IsReadOnly boolean
---@field public Keys System.Collections.ICollection
---@field public Values System.Collections.ICollection
---@field public Item any
---@field public Capacity number
local m = {}

---@virtual
---@param key any
---@param value any
function m:Add(key, value) end

---@virtual
function m:Clear() end

---@virtual
---@param key any
---@return boolean
function m:Contains(key) end

---@virtual
---@return System.Collections.IDictionaryEnumerator
function m:GetEnumerator() end

---@virtual
---@param key any
function m:Remove(key) end

---@virtual
---@param array System.Array
---@param arrayIndex number
function m:CopyTo(array, arrayIndex) end

---@virtual
---@return any
function m:Clone() end

---@virtual
---@return System.Collections.IList
function m:GetKeyList() end

---@virtual
---@return System.Collections.IList
function m:GetValueList() end

---@virtual
---@param index number
function m:RemoveAt(index) end

---@virtual
---@param key any
---@return number
function m:IndexOfKey(key) end

---@virtual
---@param value any
---@return number
function m:IndexOfValue(value) end

---@virtual
---@param key any
---@return boolean
function m:ContainsKey(key) end

---@virtual
---@param value any
---@return boolean
function m:ContainsValue(value) end

---@virtual
---@param index number
---@return any
function m:GetByIndex(index) end

---@virtual
---@param index number
---@param value any
function m:SetByIndex(index, value) end

---@virtual
---@param index number
---@return any
function m:GetKey(index) end

---@static
---@param list System.Collections.SortedList
---@return System.Collections.SortedList
function m.Synchronized(list) end

---@virtual
function m:TrimToSize() end

System.Collections.SortedList = m
return m
