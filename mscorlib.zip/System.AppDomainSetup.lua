---@class System.AppDomainSetup : System.Object
---@field public ApplicationBase string
---@field public ApplicationName string
---@field public CachePath string
---@field public ConfigurationFile string
---@field public DisallowPublisherPolicy boolean
---@field public DynamicBase string
---@field public LicenseFile string
---@field public LoaderOptimization System.LoaderOptimization
---@field public PrivateBinPath string
---@field public PrivateBinPathProbe string
---@field public ShadowCopyDirectories string
---@field public ShadowCopyFiles string
---@field public DisallowBindingRedirects boolean
---@field public DisallowCodeDownload boolean
---@field public ActivationArguments System.Runtime.Hosting.ActivationArguments
---@field public AppDomainInitializer fun(args:string[])
---@field public AppDomainInitializerArguments string[]
---@field public ApplicationTrust System.Security.Policy.ApplicationTrust
---@field public DisallowApplicationBaseProbing boolean
local m = {}

---@return string
function m:GetConfigurationBytes() end

---@param value string
function m:SetConfigurationBytes(value) end

System.AppDomainSetup = m
return m
