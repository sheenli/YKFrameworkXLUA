---@class System.Delegate : System.Object
---@field public Method System.Reflection.MethodInfo
---@field public Target any
local m = {}

---@overload fun(type:System.Type, firstArgument:any, method:System.Reflection.MethodInfo):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, method:System.Reflection.MethodInfo, throwOnBindFailure:boolean):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, method:System.Reflection.MethodInfo):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:any, method:string):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:System.Type, method:string, ignoreCase:boolean, throwOnBindFailure:boolean):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:System.Type, method:string):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:System.Type, method:string, ignoreCase:boolean):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:any, method:string, ignoreCase:boolean, throwOnBindFailure:boolean):(fun(args:any[]):any) @static
---@overload fun(type:System.Type, target:any, method:string, ignoreCase:boolean):(fun(args:any[]):any) @static
---@static
---@param type System.Type
---@param firstArgument any
---@param method System.Reflection.MethodInfo
---@param throwOnBindFailure boolean
---@return fun(args:any[]):any
function m.CreateDelegate(type, firstArgument, method, throwOnBindFailure) end

---@overload fun():any
---@param args any[]|any
---@return any
function m:DynamicInvoke(args) end

---@virtual
---@return any
function m:Clone() end

---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param info System.Runtime.Serialization.SerializationInfo
---@param context System.Runtime.Serialization.StreamingContext
function m:GetObjectData(info, context) end

---@virtual
---@return fun(args:any[]):any[]
function m:GetInvocationList() end

---@overload fun(delegates:fun(args:any[]):any[]):(fun(args:any[]):any) @static
---@overload fun():(fun(args:any[]):any) @static
---@static
---@param a fun(args:any[]):any
---@param b fun(args:any[]):any
---@return fun(args:any[]):any
function m.Combine(a, b) end

---@static
---@param source fun(args:any[]):any
---@param value fun(args:any[]):any
---@return fun(args:any[]):any
function m.Remove(source, value) end

---@static
---@param source fun(args:any[]):any
---@param value fun(args:any[]):any
---@return fun(args:any[]):any
function m.RemoveAll(source, value) end

---@static
---@param d1 fun(args:any[]):any
---@param d2 fun(args:any[]):any
---@return boolean
function m.op_Equality(d1, d2) end

---@static
---@param d1 fun(args:any[]):any
---@param d2 fun(args:any[]):any
---@return boolean
function m.op_Inequality(d1, d2) end

---@extension
---@return System.Reflection.MethodInfo
function m.GetMethodInfo() end

System.Delegate = m
return m
