---@class System.Collections.IDictionaryEnumerator : table
---@field public Entry System.Collections.DictionaryEntry
---@field public Key any
---@field public Value any
local m = {}

System.Collections.IDictionaryEnumerator = m
return m
