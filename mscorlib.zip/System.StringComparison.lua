---@class System.StringComparison : System.Enum
---@field public CurrentCulture System.StringComparison @static
---@field public CurrentCultureIgnoreCase System.StringComparison @static
---@field public InvariantCulture System.StringComparison @static
---@field public InvariantCultureIgnoreCase System.StringComparison @static
---@field public Ordinal System.StringComparison @static
---@field public OrdinalIgnoreCase System.StringComparison @static
---@field public value__ number
local m = {}

System.StringComparison = m
return m
