---@class System.TimeSpan : System.ValueType
---@field public TicksPerDay number @static
---@field public TicksPerHour number @static
---@field public TicksPerMillisecond number @static
---@field public TicksPerMinute number @static
---@field public TicksPerSecond number @static
---@field public MaxValue System.TimeSpan @static
---@field public MinValue System.TimeSpan @static
---@field public Zero System.TimeSpan @static
---@field public Days number
---@field public Hours number
---@field public Milliseconds number
---@field public Minutes number
---@field public Seconds number
---@field public Ticks number
---@field public TotalDays number
---@field public TotalHours number
---@field public TotalMilliseconds number
---@field public TotalMinutes number
---@field public TotalSeconds number
local m = {}

---@param ts System.TimeSpan
---@return System.TimeSpan
function m:Add(ts) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return number
function m.Compare(t1, t2) end

---@overload fun(value:System.TimeSpan):number @virtual
---@virtual
---@param value any
---@return number
function m:CompareTo(value) end

---@overload fun(value:any):boolean @virtual
---@overload fun(t1:System.TimeSpan, t2:System.TimeSpan):boolean @static
---@virtual
---@param obj System.TimeSpan
---@return boolean
function m:Equals(obj) end

---@return System.TimeSpan
function m:Duration() end

---@static
---@param value number
---@return System.TimeSpan
function m.FromDays(value) end

---@static
---@param value number
---@return System.TimeSpan
function m.FromHours(value) end

---@static
---@param value number
---@return System.TimeSpan
function m.FromMinutes(value) end

---@static
---@param value number
---@return System.TimeSpan
function m.FromSeconds(value) end

---@static
---@param value number
---@return System.TimeSpan
function m.FromMilliseconds(value) end

---@static
---@param value number
---@return System.TimeSpan
function m.FromTicks(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@return System.TimeSpan
function m:Negate() end

---@static
---@param s string
---@return System.TimeSpan
function m.Parse(s) end

---@static
---@param s string
---@return boolean, System.TimeSpan
function m.TryParse(s) end

---@param ts System.TimeSpan
---@return System.TimeSpan
function m:Subtract(ts) end

---@virtual
---@return string
function m:ToString() end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return System.TimeSpan
function m.op_Addition(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_Equality(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_GreaterThan(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_GreaterThanOrEqual(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_Inequality(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_LessThan(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return boolean
function m.op_LessThanOrEqual(t1, t2) end

---@static
---@param t1 System.TimeSpan
---@param t2 System.TimeSpan
---@return System.TimeSpan
function m.op_Subtraction(t1, t2) end

---@static
---@param t System.TimeSpan
---@return System.TimeSpan
function m.op_UnaryNegation(t) end

---@static
---@param t System.TimeSpan
---@return System.TimeSpan
function m.op_UnaryPlus(t) end

System.TimeSpan = m
return m
