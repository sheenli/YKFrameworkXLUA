---@class UnityEngine.EventProvider : System.Object
local m = {}

---@static
---@param value number
---@param text string
function m.WriteCustomEvent(value, text) end

UnityEngine.EventProvider = m
return m
