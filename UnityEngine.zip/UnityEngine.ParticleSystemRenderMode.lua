---@class UnityEngine.ParticleSystemRenderMode : System.Enum
---@field public Billboard UnityEngine.ParticleSystemRenderMode @static
---@field public Stretch UnityEngine.ParticleSystemRenderMode @static
---@field public HorizontalBillboard UnityEngine.ParticleSystemRenderMode @static
---@field public VerticalBillboard UnityEngine.ParticleSystemRenderMode @static
---@field public Mesh UnityEngine.ParticleSystemRenderMode @static
---@field public None UnityEngine.ParticleSystemRenderMode @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemRenderMode = m
return m
