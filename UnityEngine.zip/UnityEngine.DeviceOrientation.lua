---@class UnityEngine.DeviceOrientation : System.Enum
---@field public Unknown UnityEngine.DeviceOrientation @static
---@field public Portrait UnityEngine.DeviceOrientation @static
---@field public PortraitUpsideDown UnityEngine.DeviceOrientation @static
---@field public LandscapeLeft UnityEngine.DeviceOrientation @static
---@field public LandscapeRight UnityEngine.DeviceOrientation @static
---@field public FaceUp UnityEngine.DeviceOrientation @static
---@field public FaceDown UnityEngine.DeviceOrientation @static
---@field public value__ number
local m = {}

UnityEngine.DeviceOrientation = m
return m
