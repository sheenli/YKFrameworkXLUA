---@class UnityEngine.ParticleSystem.ShapeModule : System.ValueType
---@field public enabled boolean
---@field public shapeType UnityEngine.ParticleSystemShapeType
---@field public randomDirectionAmount number
---@field public sphericalDirectionAmount number
---@field public alignToDirection boolean
---@field public radius number
---@field public radiusMode UnityEngine.ParticleSystemShapeMultiModeValue
---@field public radiusSpread number
---@field public radiusSpeed UnityEngine.ParticleSystem.MinMaxCurve
---@field public radiusSpeedMultiplier number
---@field public angle number
---@field public length number
---@field public box UnityEngine.Vector3
---@field public meshShapeType UnityEngine.ParticleSystemMeshShapeType
---@field public mesh UnityEngine.Mesh
---@field public meshRenderer UnityEngine.MeshRenderer
---@field public skinnedMeshRenderer UnityEngine.SkinnedMeshRenderer
---@field public useMeshMaterialIndex boolean
---@field public meshMaterialIndex number
---@field public useMeshColors boolean
---@field public normalOffset number
---@field public meshScale number
---@field public arc number
---@field public arcMode UnityEngine.ParticleSystemShapeMultiModeValue
---@field public arcSpread number
---@field public arcSpeed UnityEngine.ParticleSystem.MinMaxCurve
---@field public arcSpeedMultiplier number
---@field public randomDirection boolean
local m = {}

UnityEngine.ParticleSystem.ShapeModule = m
return m
