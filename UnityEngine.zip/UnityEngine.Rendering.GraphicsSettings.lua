---@class UnityEngine.Rendering.GraphicsSettings : UnityEngine.Object
---@field public renderPipelineAsset UnityEngine.Experimental.Rendering.RenderPipelineAsset @static
---@field public transparencySortMode UnityEngine.TransparencySortMode @static
---@field public transparencySortAxis UnityEngine.Vector3 @static
---@field public lightsUseLinearIntensity boolean @static
---@field public lightsUseColorTemperature boolean @static
local m = {}

---@static
---@param type UnityEngine.Rendering.BuiltinShaderType
---@param mode UnityEngine.Rendering.BuiltinShaderMode
function m.SetShaderMode(type, mode) end

---@static
---@param type UnityEngine.Rendering.BuiltinShaderType
---@return UnityEngine.Rendering.BuiltinShaderMode
function m.GetShaderMode(type) end

---@static
---@param type UnityEngine.Rendering.BuiltinShaderType
---@param shader UnityEngine.Shader
function m.SetCustomShader(type, shader) end

---@static
---@param type UnityEngine.Rendering.BuiltinShaderType
---@return UnityEngine.Shader
function m.GetCustomShader(type) end

UnityEngine.Rendering.GraphicsSettings = m
return m
