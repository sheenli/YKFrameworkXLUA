---@class UnityEngine.LightProbeProxyVolume.BoundingBoxMode : System.Enum
---@field public AutomaticLocal UnityEngine.LightProbeProxyVolume.BoundingBoxMode @static
---@field public AutomaticWorld UnityEngine.LightProbeProxyVolume.BoundingBoxMode @static
---@field public Custom UnityEngine.LightProbeProxyVolume.BoundingBoxMode @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.BoundingBoxMode = m
return m
