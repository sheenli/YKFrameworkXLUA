---@class UnityEngine.Keyframe : System.ValueType
---@field public time number
---@field public value number
---@field public inTangent number
---@field public outTangent number
---@field public tangentMode number
local m = {}

UnityEngine.Keyframe = m
return m
