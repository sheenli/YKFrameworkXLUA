---@class UnityEngine.CompositeCollider2D.GenerationType : System.Enum
---@field public Synchronous UnityEngine.CompositeCollider2D.GenerationType @static
---@field public Manual UnityEngine.CompositeCollider2D.GenerationType @static
---@field public value__ number
local m = {}

UnityEngine.CompositeCollider2D.GenerationType = m
return m
