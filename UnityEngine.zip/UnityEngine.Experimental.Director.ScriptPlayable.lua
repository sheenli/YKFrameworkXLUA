---@class UnityEngine.Experimental.Director.ScriptPlayable : UnityEngine.Experimental.Director.Playable
local m = {}

---@virtual
function m:OnGraphStart() end

---@virtual
function m:OnGraphStop() end

---@virtual
function m:OnDestroy() end

---@virtual
---@param info UnityEngine.Experimental.Director.FrameData
function m:PrepareFrame(info) end

---@virtual
---@param info UnityEngine.Experimental.Director.FrameData
---@param playerData any
function m:ProcessFrame(info, playerData) end

---@virtual
---@param info UnityEngine.Experimental.Director.FrameData
---@param newState UnityEngine.Experimental.Director.PlayState
function m:OnPlayStateChanged(info, newState) end

UnityEngine.Experimental.Director.ScriptPlayable = m
return m
