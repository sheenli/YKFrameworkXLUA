---@class UnityEngine.SamsungTV.OpenAPI : System.Object
---@field public serverType UnityEngine.SamsungTV.OpenAPI.OpenAPIServerType @static
---@field public timeOnTV string @static
---@field public uid string @static
---@field public dUid string @static
local m = {}

UnityEngine.SamsungTV.OpenAPI = m
return m
