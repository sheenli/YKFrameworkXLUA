---@class UnityEngine.ColliderDistance2D : System.ValueType
---@field public pointA UnityEngine.Vector2
---@field public pointB UnityEngine.Vector2
---@field public normal UnityEngine.Vector2
---@field public distance number
---@field public isOverlapped boolean
---@field public isValid boolean
local m = {}

UnityEngine.ColliderDistance2D = m
return m
