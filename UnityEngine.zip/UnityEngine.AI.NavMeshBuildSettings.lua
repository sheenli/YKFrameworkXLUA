---@class UnityEngine.AI.NavMeshBuildSettings : System.ValueType
---@field public agentTypeID number
---@field public agentRadius number
---@field public agentHeight number
---@field public agentSlope number
---@field public agentClimb number
---@field public minRegionArea number
---@field public overrideVoxelSize boolean
---@field public voxelSize number
---@field public overrideTileSize boolean
---@field public tileSize number
local m = {}

---@param buildBounds UnityEngine.Bounds
---@return string[]
function m:ValidationReport(buildBounds) end

UnityEngine.AI.NavMeshBuildSettings = m
return m
