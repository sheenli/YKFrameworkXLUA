---@class UnityEngine.ParticleSystem.CustomDataModule : System.ValueType
---@field public enabled boolean
local m = {}

---@param stream UnityEngine.ParticleSystemCustomData
---@param mode UnityEngine.ParticleSystemCustomDataMode
function m:SetMode(stream, mode) end

---@param stream UnityEngine.ParticleSystemCustomData
---@return UnityEngine.ParticleSystemCustomDataMode
function m:GetMode(stream) end

---@param stream UnityEngine.ParticleSystemCustomData
---@param count number
function m:SetVectorComponentCount(stream, count) end

---@param stream UnityEngine.ParticleSystemCustomData
---@return number
function m:GetVectorComponentCount(stream) end

---@param stream UnityEngine.ParticleSystemCustomData
---@param component number
---@param curve UnityEngine.ParticleSystem.MinMaxCurve
function m:SetVector(stream, component, curve) end

---@param stream UnityEngine.ParticleSystemCustomData
---@param component number
---@return UnityEngine.ParticleSystem.MinMaxCurve
function m:GetVector(stream, component) end

---@param stream UnityEngine.ParticleSystemCustomData
---@param gradient UnityEngine.ParticleSystem.MinMaxGradient
function m:SetColor(stream, gradient) end

---@param stream UnityEngine.ParticleSystemCustomData
---@return UnityEngine.ParticleSystem.MinMaxGradient
function m:GetColor(stream) end

UnityEngine.ParticleSystem.CustomDataModule = m
return m
