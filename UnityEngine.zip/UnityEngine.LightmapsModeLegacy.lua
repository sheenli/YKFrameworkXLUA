---@class UnityEngine.LightmapsModeLegacy : System.Enum
---@field public Single UnityEngine.LightmapsModeLegacy @static
---@field public Dual UnityEngine.LightmapsModeLegacy @static
---@field public Directional UnityEngine.LightmapsModeLegacy @static
---@field public value__ number
local m = {}

UnityEngine.LightmapsModeLegacy = m
return m
