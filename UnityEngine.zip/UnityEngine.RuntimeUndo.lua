---@class UnityEngine.RuntimeUndo : System.Object
local m = {}

---@static
---@param transform UnityEngine.Transform
---@param newParent UnityEngine.Transform
---@param name string
function m.SetTransformParent(transform, newParent, name) end

---@static
---@param objectToUndo UnityEngine.Object
---@param name string
function m.RecordObject(objectToUndo, name) end

---@static
---@param objectsToUndo UnityEngine.Object[]
---@param name string
function m.RecordObjects(objectsToUndo, name) end

UnityEngine.RuntimeUndo = m
return m
