---@class UnityEngine.ContactPoint : System.ValueType
---@field public point UnityEngine.Vector3
---@field public normal UnityEngine.Vector3
---@field public thisCollider UnityEngine.Collider
---@field public otherCollider UnityEngine.Collider
---@field public separation number
local m = {}

UnityEngine.ContactPoint = m
return m
