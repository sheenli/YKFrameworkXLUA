---@class UnityEngine.AI.NavMeshQueryFilter : System.ValueType
---@field public areaMask number
---@field public agentTypeID number
local m = {}

---@param areaIndex number
---@return number
function m:GetAreaCost(areaIndex) end

---@param areaIndex number
---@param cost number
function m:SetAreaCost(areaIndex, cost) end

UnityEngine.AI.NavMeshQueryFilter = m
return m
