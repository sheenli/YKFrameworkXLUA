---@class UnityEngine.Experimental.Director.PlayableOutput : System.ValueType
local m = {}

UnityEngine.Experimental.Director.PlayableOutput = m
return m
