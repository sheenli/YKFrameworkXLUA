---@class UnityEngine.SpriteAlignment : System.Enum
---@field public Center UnityEngine.SpriteAlignment @static
---@field public TopLeft UnityEngine.SpriteAlignment @static
---@field public TopCenter UnityEngine.SpriteAlignment @static
---@field public TopRight UnityEngine.SpriteAlignment @static
---@field public LeftCenter UnityEngine.SpriteAlignment @static
---@field public RightCenter UnityEngine.SpriteAlignment @static
---@field public BottomLeft UnityEngine.SpriteAlignment @static
---@field public BottomCenter UnityEngine.SpriteAlignment @static
---@field public BottomRight UnityEngine.SpriteAlignment @static
---@field public Custom UnityEngine.SpriteAlignment @static
---@field public value__ number
local m = {}

UnityEngine.SpriteAlignment = m
return m
