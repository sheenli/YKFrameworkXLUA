---@class UnityEngine.RigidbodyConstraints2D : System.Enum
---@field public None UnityEngine.RigidbodyConstraints2D @static
---@field public FreezePositionX UnityEngine.RigidbodyConstraints2D @static
---@field public FreezePositionY UnityEngine.RigidbodyConstraints2D @static
---@field public FreezeRotation UnityEngine.RigidbodyConstraints2D @static
---@field public FreezePosition UnityEngine.RigidbodyConstraints2D @static
---@field public FreezeAll UnityEngine.RigidbodyConstraints2D @static
---@field public value__ number
local m = {}

UnityEngine.RigidbodyConstraints2D = m
return m
