---@class UnityEngine.NetworkPlayer : System.ValueType
---@field public ipAddress string
---@field public port number
---@field public guid string
---@field public externalIP string
---@field public externalPort number
local m = {}

---@static
---@param lhs UnityEngine.NetworkPlayer
---@param rhs UnityEngine.NetworkPlayer
---@return boolean
function m.op_Equality(lhs, rhs) end

---@static
---@param lhs UnityEngine.NetworkPlayer
---@param rhs UnityEngine.NetworkPlayer
---@return boolean
function m.op_Inequality(lhs, rhs) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@param other any
---@return boolean
function m:Equals(other) end

---@virtual
---@return string
function m:ToString() end

UnityEngine.NetworkPlayer = m
return m
