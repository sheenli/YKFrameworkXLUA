---@class UnityEngine.ConstantForce : UnityEngine.Behaviour
---@field public force UnityEngine.Vector3
---@field public relativeForce UnityEngine.Vector3
---@field public torque UnityEngine.Vector3
---@field public relativeTorque UnityEngine.Vector3
local m = {}

UnityEngine.ConstantForce = m
return m
