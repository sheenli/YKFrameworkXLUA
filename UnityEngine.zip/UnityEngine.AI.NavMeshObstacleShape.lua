---@class UnityEngine.AI.NavMeshObstacleShape : System.Enum
---@field public Capsule UnityEngine.AI.NavMeshObstacleShape @static
---@field public Box UnityEngine.AI.NavMeshObstacleShape @static
---@field public value__ number
local m = {}

UnityEngine.AI.NavMeshObstacleShape = m
return m
