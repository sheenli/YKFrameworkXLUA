---@class UnityEngine.RotationOrder : System.Enum
---@field public OrderXYZ UnityEngine.RotationOrder @static
---@field public OrderXZY UnityEngine.RotationOrder @static
---@field public OrderYZX UnityEngine.RotationOrder @static
---@field public OrderYXZ UnityEngine.RotationOrder @static
---@field public OrderZXY UnityEngine.RotationOrder @static
---@field public OrderZYX UnityEngine.RotationOrder @static
---@field public value__ number
local m = {}

UnityEngine.RotationOrder = m
return m
