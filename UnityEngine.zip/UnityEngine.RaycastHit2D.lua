---@class UnityEngine.RaycastHit2D : System.ValueType
---@field public centroid UnityEngine.Vector2
---@field public point UnityEngine.Vector2
---@field public normal UnityEngine.Vector2
---@field public distance number
---@field public fraction number
---@field public collider UnityEngine.Collider2D
---@field public rigidbody UnityEngine.Rigidbody2D
---@field public transform UnityEngine.Transform
local m = {}

---@static
---@param hit UnityEngine.RaycastHit2D
---@return boolean
function m.op_Implicit(hit) end

---@param other UnityEngine.RaycastHit2D
---@return number
function m:CompareTo(other) end

UnityEngine.RaycastHit2D = m
return m
