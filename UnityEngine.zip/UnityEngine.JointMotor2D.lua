---@class UnityEngine.JointMotor2D : System.ValueType
---@field public motorSpeed number
---@field public maxMotorTorque number
local m = {}

UnityEngine.JointMotor2D = m
return m
