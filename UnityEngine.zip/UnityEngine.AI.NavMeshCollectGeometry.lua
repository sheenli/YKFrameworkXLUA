---@class UnityEngine.AI.NavMeshCollectGeometry : System.Enum
---@field public RenderMeshes UnityEngine.AI.NavMeshCollectGeometry @static
---@field public PhysicsColliders UnityEngine.AI.NavMeshCollectGeometry @static
---@field public value__ number
local m = {}

UnityEngine.AI.NavMeshCollectGeometry = m
return m
