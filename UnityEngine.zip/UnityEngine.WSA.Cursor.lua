---@class UnityEngine.WSA.Cursor : System.Object
local m = {}

---@static
---@param id number
function m.SetCustomCursor(id) end

UnityEngine.WSA.Cursor = m
return m
