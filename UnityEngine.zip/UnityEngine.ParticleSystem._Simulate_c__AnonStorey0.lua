---@class UnityEngine.ParticleSystem._Simulate_c__AnonStorey0 : System.Object
local m = {}

UnityEngine.ParticleSystem._Simulate_c__AnonStorey0 = m
return m
