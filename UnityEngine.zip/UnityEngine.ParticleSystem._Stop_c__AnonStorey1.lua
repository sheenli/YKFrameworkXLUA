---@class UnityEngine.ParticleSystem._Stop_c__AnonStorey1 : System.Object
local m = {}

UnityEngine.ParticleSystem._Stop_c__AnonStorey1 = m
return m
