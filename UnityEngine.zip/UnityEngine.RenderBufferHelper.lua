---@class UnityEngine.RenderBufferHelper : System.ValueType
local m = {}

UnityEngine.RenderBufferHelper = m
return m
