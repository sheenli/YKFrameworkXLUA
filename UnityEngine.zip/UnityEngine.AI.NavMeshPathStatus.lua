---@class UnityEngine.AI.NavMeshPathStatus : System.Enum
---@field public PathComplete UnityEngine.AI.NavMeshPathStatus @static
---@field public PathPartial UnityEngine.AI.NavMeshPathStatus @static
---@field public PathInvalid UnityEngine.AI.NavMeshPathStatus @static
---@field public value__ number
local m = {}

UnityEngine.AI.NavMeshPathStatus = m
return m
