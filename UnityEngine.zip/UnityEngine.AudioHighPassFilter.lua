---@class UnityEngine.AudioHighPassFilter : UnityEngine.Behaviour
---@field public highpassResonaceQ number
---@field public cutoffFrequency number
---@field public highpassResonanceQ number
local m = {}

UnityEngine.AudioHighPassFilter = m
return m
