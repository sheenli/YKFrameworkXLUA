---@class UnityEngine.ComputeShader : UnityEngine.Object
local m = {}

---@param name string
---@return number
function m:FindKernel(name) end

---@param name string
---@return boolean
function m:HasKernel(name) end

---@param kernelIndex number
---@return System.UInt32, System.UInt32, System.UInt32
function m:GetKernelThreadGroupSizes(kernelIndex) end

---@overload fun(nameID:number, val:number)
---@param name string
---@param val number
function m:SetFloat(name, val) end

---@overload fun(nameID:number, val:number)
---@param name string
---@param val number
function m:SetInt(name, val) end

---@overload fun(nameID:number, val:boolean)
---@param name string
---@param val boolean
function m:SetBool(name, val) end

---@overload fun(nameID:number, val:UnityEngine.Vector4)
---@param name string
---@param val UnityEngine.Vector4
function m:SetVector(name, val) end

---@overload fun(name:string)
---@overload fun(nameID:number, values:number[]|number)
---@overload fun(nameID:number)
---@param name string
---@param values number[]|number
function m:SetFloats(name, values) end

---@overload fun(name:string)
---@overload fun(nameID:number, values:number[]|number)
---@overload fun(nameID:number)
---@param name string
---@param values number[]|number
function m:SetInts(name, values) end

---@overload fun(kernelIndex:number, nameID:number, texture:UnityEngine.Texture)
---@param kernelIndex number
---@param name string
---@param texture UnityEngine.Texture
function m:SetTexture(kernelIndex, name, texture) end

---@overload fun(kernelIndex:number, nameID:number, globalTextureNameID:number)
---@param kernelIndex number
---@param name string
---@param globalTextureName string
function m:SetTextureFromGlobal(kernelIndex, name, globalTextureName) end

---@overload fun(kernelIndex:number, nameID:number, buffer:UnityEngine.ComputeBuffer)
---@param kernelIndex number
---@param name string
---@param buffer UnityEngine.ComputeBuffer
function m:SetBuffer(kernelIndex, name, buffer) end

---@param kernelIndex number
---@param threadGroupsX number
---@param threadGroupsY number
---@param threadGroupsZ number
function m:Dispatch(kernelIndex, threadGroupsX, threadGroupsY, threadGroupsZ) end

---@overload fun(kernelIndex:number, argsBuffer:UnityEngine.ComputeBuffer, argsOffset:number)
---@param kernelIndex number
---@param argsBuffer UnityEngine.ComputeBuffer
function m:DispatchIndirect(kernelIndex, argsBuffer) end

UnityEngine.ComputeShader = m
return m
