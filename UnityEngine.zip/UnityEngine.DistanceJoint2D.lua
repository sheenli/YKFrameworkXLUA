---@class UnityEngine.DistanceJoint2D : UnityEngine.AnchoredJoint2D
---@field public autoConfigureDistance boolean
---@field public distance number
---@field public maxDistanceOnly boolean
local m = {}

UnityEngine.DistanceJoint2D = m
return m
