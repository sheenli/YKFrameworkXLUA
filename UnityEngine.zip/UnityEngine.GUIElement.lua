---@class UnityEngine.GUIElement : UnityEngine.Behaviour
local m = {}

---@overload fun(screenPosition:UnityEngine.Vector3):boolean
---@param screenPosition UnityEngine.Vector3
---@param camera UnityEngine.Camera
---@return boolean
function m:HitTest(screenPosition, camera) end

---@overload fun():UnityEngine.Rect
---@param camera UnityEngine.Camera
---@return UnityEngine.Rect
function m:GetScreenRect(camera) end

UnityEngine.GUIElement = m
return m
