---@class UnityEngine.ImageEffectTransformsToLDR : System.Attribute
local m = {}

UnityEngine.ImageEffectTransformsToLDR = m
return m
