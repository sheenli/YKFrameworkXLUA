---@class UnityEngine.SamsungTV.GestureMode : System.Enum
---@field public Off UnityEngine.SamsungTV.GestureMode @static
---@field public Mouse UnityEngine.SamsungTV.GestureMode @static
---@field public Joystick UnityEngine.SamsungTV.GestureMode @static
---@field public value__ number
local m = {}

UnityEngine.SamsungTV.GestureMode = m
return m
