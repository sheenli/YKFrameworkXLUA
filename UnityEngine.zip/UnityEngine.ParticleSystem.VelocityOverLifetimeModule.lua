---@class UnityEngine.ParticleSystem.VelocityOverLifetimeModule : System.ValueType
---@field public enabled boolean
---@field public x UnityEngine.ParticleSystem.MinMaxCurve
---@field public y UnityEngine.ParticleSystem.MinMaxCurve
---@field public z UnityEngine.ParticleSystem.MinMaxCurve
---@field public xMultiplier number
---@field public yMultiplier number
---@field public zMultiplier number
---@field public space UnityEngine.ParticleSystemSimulationSpace
local m = {}

UnityEngine.ParticleSystem.VelocityOverLifetimeModule = m
return m
