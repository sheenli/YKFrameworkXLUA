---@class UnityEngine.RectTransform.Edge : System.Enum
---@field public Left UnityEngine.RectTransform.Edge @static
---@field public Right UnityEngine.RectTransform.Edge @static
---@field public Top UnityEngine.RectTransform.Edge @static
---@field public Bottom UnityEngine.RectTransform.Edge @static
---@field public value__ number
local m = {}

UnityEngine.RectTransform.Edge = m
return m
