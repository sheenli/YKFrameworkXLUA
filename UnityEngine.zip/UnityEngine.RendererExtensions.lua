---@class UnityEngine.RendererExtensions : System.Object
local m = {}

---@static
---@param renderer UnityEngine.Renderer
function m.UpdateGIMaterials(renderer) end

UnityEngine.RendererExtensions = m
return m
