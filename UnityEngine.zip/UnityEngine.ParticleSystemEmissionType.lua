---@class UnityEngine.ParticleSystemEmissionType : System.Enum
---@field public Time UnityEngine.ParticleSystemEmissionType @static
---@field public Distance UnityEngine.ParticleSystemEmissionType @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemEmissionType = m
return m
