---@class UnityEngine.Coroutine : UnityEngine.YieldInstruction
local m = {}

UnityEngine.Coroutine = m
return m
