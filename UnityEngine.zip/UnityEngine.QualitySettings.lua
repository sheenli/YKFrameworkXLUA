---@class UnityEngine.QualitySettings : UnityEngine.Object
---@field public names string[] @static
---@field public pixelLightCount number @static
---@field public shadows UnityEngine.ShadowQuality @static
---@field public shadowProjection UnityEngine.ShadowProjection @static
---@field public shadowCascades number @static
---@field public shadowDistance number @static
---@field public shadowResolution UnityEngine.ShadowResolution @static
---@field public shadowNearPlaneOffset number @static
---@field public shadowCascade2Split number @static
---@field public shadowCascade4Split UnityEngine.Vector3 @static
---@field public masterTextureLimit number @static
---@field public anisotropicFiltering UnityEngine.AnisotropicFiltering @static
---@field public lodBias number @static
---@field public maximumLODLevel number @static
---@field public particleRaycastBudget number @static
---@field public softParticles boolean @static
---@field public softVegetation boolean @static
---@field public realtimeReflectionProbes boolean @static
---@field public billboardsFaceCameraPosition boolean @static
---@field public maxQueuedFrames number @static
---@field public vSyncCount number @static
---@field public antiAliasing number @static
---@field public desiredColorSpace UnityEngine.ColorSpace @static
---@field public activeColorSpace UnityEngine.ColorSpace @static
---@field public blendWeights UnityEngine.BlendWeights @static
---@field public asyncUploadTimeSlice number @static
---@field public asyncUploadBufferSize number @static
---@field public currentLevel UnityEngine.QualityLevel @static
local m = {}

---@static
---@return number
function m.GetQualityLevel() end

---@overload fun(index:number) @static
---@static
---@param index number
---@param applyExpensiveChanges boolean
function m.SetQualityLevel(index, applyExpensiveChanges) end

---@overload fun() @static
---@static
---@param applyExpensiveChanges boolean
function m.IncreaseLevel(applyExpensiveChanges) end

---@overload fun() @static
---@static
---@param applyExpensiveChanges boolean
function m.DecreaseLevel(applyExpensiveChanges) end

UnityEngine.QualitySettings = m
return m
