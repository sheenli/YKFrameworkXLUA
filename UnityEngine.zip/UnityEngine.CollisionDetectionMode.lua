---@class UnityEngine.CollisionDetectionMode : System.Enum
---@field public Discrete UnityEngine.CollisionDetectionMode @static
---@field public Continuous UnityEngine.CollisionDetectionMode @static
---@field public ContinuousDynamic UnityEngine.CollisionDetectionMode @static
---@field public value__ number
local m = {}

UnityEngine.CollisionDetectionMode = m
return m
