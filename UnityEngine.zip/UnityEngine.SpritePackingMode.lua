---@class UnityEngine.SpritePackingMode : System.Enum
---@field public Tight UnityEngine.SpritePackingMode @static
---@field public Rectangle UnityEngine.SpritePackingMode @static
---@field public value__ number
local m = {}

UnityEngine.SpritePackingMode = m
return m
