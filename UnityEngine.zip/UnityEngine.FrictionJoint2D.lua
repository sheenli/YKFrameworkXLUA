---@class UnityEngine.FrictionJoint2D : UnityEngine.AnchoredJoint2D
---@field public maxForce number
---@field public maxTorque number
local m = {}

UnityEngine.FrictionJoint2D = m
return m
