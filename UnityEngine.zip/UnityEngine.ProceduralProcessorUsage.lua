---@class UnityEngine.ProceduralProcessorUsage : System.Enum
---@field public Unsupported UnityEngine.ProceduralProcessorUsage @static
---@field public One UnityEngine.ProceduralProcessorUsage @static
---@field public Half UnityEngine.ProceduralProcessorUsage @static
---@field public All UnityEngine.ProceduralProcessorUsage @static
---@field public value__ number
local m = {}

UnityEngine.ProceduralProcessorUsage = m
return m
