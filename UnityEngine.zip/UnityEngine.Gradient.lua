---@class UnityEngine.Gradient : System.Object
---@field public colorKeys UnityEngine.GradientColorKey[]
---@field public alphaKeys UnityEngine.GradientAlphaKey[]
---@field public mode UnityEngine.GradientMode
local m = {}

---@param time number
---@return UnityEngine.Color
function m:Evaluate(time) end

---@param colorKeys UnityEngine.GradientColorKey[]
---@param alphaKeys UnityEngine.GradientAlphaKey[]
function m:SetKeys(colorKeys, alphaKeys) end

UnityEngine.Gradient = m
return m
