---@class UnityEngine.JointMotor : System.ValueType
---@field public targetVelocity number
---@field public force number
---@field public freeSpin boolean
local m = {}

UnityEngine.JointMotor = m
return m
