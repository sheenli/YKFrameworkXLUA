---@class UnityEngine.ParticleSystem.TrailModule : System.ValueType
---@field public enabled boolean
---@field public ratio number
---@field public lifetime UnityEngine.ParticleSystem.MinMaxCurve
---@field public lifetimeMultiplier number
---@field public minVertexDistance number
---@field public textureMode UnityEngine.ParticleSystemTrailTextureMode
---@field public worldSpace boolean
---@field public dieWithParticles boolean
---@field public sizeAffectsWidth boolean
---@field public sizeAffectsLifetime boolean
---@field public inheritParticleColor boolean
---@field public colorOverLifetime UnityEngine.ParticleSystem.MinMaxGradient
---@field public widthOverTrail UnityEngine.ParticleSystem.MinMaxCurve
---@field public widthOverTrailMultiplier number
---@field public colorOverTrail UnityEngine.ParticleSystem.MinMaxGradient
local m = {}

UnityEngine.ParticleSystem.TrailModule = m
return m
