---@class UnityEngine.AssetBundleRequest : UnityEngine.AsyncOperation
---@field public asset UnityEngine.Object
---@field public allAssets UnityEngine.Object[]
local m = {}

UnityEngine.AssetBundleRequest = m
return m
