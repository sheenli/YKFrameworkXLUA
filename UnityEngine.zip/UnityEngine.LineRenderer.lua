---@class UnityEngine.LineRenderer : UnityEngine.Renderer
---@field public startWidth number
---@field public endWidth number
---@field public widthCurve UnityEngine.AnimationCurve
---@field public widthMultiplier number
---@field public startColor UnityEngine.Color
---@field public endColor UnityEngine.Color
---@field public colorGradient UnityEngine.Gradient
---@field public positionCount number
---@field public numPositions number
---@field public useWorldSpace boolean
---@field public loop boolean
---@field public numCornerVertices number
---@field public numCapVertices number
---@field public textureMode UnityEngine.LineTextureMode
---@field public alignment UnityEngine.LineAlignment
local m = {}

---@param index number
---@param position UnityEngine.Vector3
function m:SetPosition(index, position) end

---@param index number
---@return UnityEngine.Vector3
function m:GetPosition(index) end

---@param positions UnityEngine.Vector3[]
function m:SetPositions(positions) end

---@param positions UnityEngine.Vector3[]
---@return number
function m:GetPositions(positions) end

---@param start number
---@param _end number
function m:SetWidth(start, _end) end

---@param start UnityEngine.Color
---@param _end UnityEngine.Color
function m:SetColors(start, _end) end

---@param count number
function m:SetVertexCount(count) end

UnityEngine.LineRenderer = m
return m
