---@class UnityEngine.MasterServerEvent : System.Enum
---@field public RegistrationFailedGameName UnityEngine.MasterServerEvent @static
---@field public RegistrationFailedGameType UnityEngine.MasterServerEvent @static
---@field public RegistrationFailedNoServer UnityEngine.MasterServerEvent @static
---@field public RegistrationSucceeded UnityEngine.MasterServerEvent @static
---@field public HostListReceived UnityEngine.MasterServerEvent @static
---@field public value__ number
local m = {}

UnityEngine.MasterServerEvent = m
return m
