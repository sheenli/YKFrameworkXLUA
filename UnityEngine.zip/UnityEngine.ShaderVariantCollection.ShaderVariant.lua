---@class UnityEngine.ShaderVariantCollection.ShaderVariant : System.ValueType
---@field public shader UnityEngine.Shader
---@field public passType UnityEngine.Rendering.PassType
---@field public keywords string[]
local m = {}

UnityEngine.ShaderVariantCollection.ShaderVariant = m
return m
