---@class UnityEngine.ParticleSystemCustomData : System.Enum
---@field public Custom1 UnityEngine.ParticleSystemCustomData @static
---@field public Custom2 UnityEngine.ParticleSystemCustomData @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemCustomData = m
return m
