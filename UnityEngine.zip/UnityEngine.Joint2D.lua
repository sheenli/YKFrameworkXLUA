---@class UnityEngine.Joint2D : UnityEngine.Behaviour
---@field public collideConnected boolean
---@field public connectedBody UnityEngine.Rigidbody2D
---@field public enableCollision boolean
---@field public breakForce number
---@field public breakTorque number
---@field public reactionForce UnityEngine.Vector2
---@field public reactionTorque number
local m = {}

---@param timeStep number
---@return UnityEngine.Vector2
function m:GetReactionForce(timeStep) end

---@param timeStep number
---@return number
function m:GetReactionTorque(timeStep) end

UnityEngine.Joint2D = m
return m
