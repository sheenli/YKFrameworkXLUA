---@class UnityEngine.Texture2D.EXRFlags : System.Enum
---@field public None UnityEngine.Texture2D.EXRFlags @static
---@field public OutputAsFloat UnityEngine.Texture2D.EXRFlags @static
---@field public CompressZIP UnityEngine.Texture2D.EXRFlags @static
---@field public CompressRLE UnityEngine.Texture2D.EXRFlags @static
---@field public CompressPIZ UnityEngine.Texture2D.EXRFlags @static
---@field public value__ number
local m = {}

UnityEngine.Texture2D.EXRFlags = m
return m
