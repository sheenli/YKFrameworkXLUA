---@class UnityEngine.Tizen.Window : System.Object
---@field public windowHandle System.IntPtr @static
---@field public evasGL System.IntPtr @static
local m = {}

UnityEngine.Tizen.Window = m
return m
