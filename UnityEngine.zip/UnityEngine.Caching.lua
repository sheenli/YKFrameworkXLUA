---@class UnityEngine.Caching : System.Object
---@field public index UnityEngine.CacheIndex[] @static
---@field public spaceFree number @static
---@field public maximumAvailableDiskSpace number @static
---@field public spaceOccupied number @static
---@field public spaceAvailable number @static
---@field public spaceUsed number @static
---@field public expirationDelay number @static
---@field public enabled boolean @static
---@field public compressionEnabled boolean @static
---@field public ready boolean @static
local m = {}

---@overload fun(name:string, domain:string, size:number, expiration:number, signature:string):boolean @static
---@overload fun(name:string, domain:string, size:number, expiration:number, signature:string):boolean @static
---@overload fun(name:string, domain:string, size:number, signature:string):boolean @static
---@static
---@param name string
---@param domain string
---@param size number
---@param signature string
---@return boolean
function m.Authorize(name, domain, size, signature) end

---@static
---@return boolean
function m.CleanCache() end

---@static
---@param name string
---@return boolean
function m.CleanNamedCache(name) end

---@static
---@param url string
---@return boolean
function m.DeleteFromCache(url) end

---@static
---@param url string
---@return number
function m.GetVersionFromCache(url) end

---@overload fun(url:string, hash:UnityEngine.Hash128):boolean @static
---@static
---@param url string
---@param version number
---@return boolean
function m.IsVersionCached(url, version) end

---@overload fun(url:string, hash:UnityEngine.Hash128):boolean @static
---@static
---@param url string
---@param version number
---@return boolean
function m.MarkAsUsed(url, version) end

---@overload fun(url:string, hash:UnityEngine.Hash128) @static
---@static
---@param url string
---@param version number
function m.SetNoBackupFlag(url, version) end

---@overload fun(url:string, hash:UnityEngine.Hash128) @static
---@static
---@param url string
---@param version number
function m.ResetNoBackupFlag(url, version) end

UnityEngine.Caching = m
return m
