---@class UnityEngine.AssetBundleCreateRequest : UnityEngine.AsyncOperation
---@field public assetBundle UnityEngine.AssetBundle
local m = {}

UnityEngine.AssetBundleCreateRequest = m
return m
