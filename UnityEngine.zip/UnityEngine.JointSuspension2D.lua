---@class UnityEngine.JointSuspension2D : System.ValueType
---@field public dampingRatio number
---@field public frequency number
---@field public angle number
local m = {}

UnityEngine.JointSuspension2D = m
return m
