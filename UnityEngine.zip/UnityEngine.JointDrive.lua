---@class UnityEngine.JointDrive : System.ValueType
---@field public mode UnityEngine.JointDriveMode
---@field public positionSpring number
---@field public positionDamper number
---@field public maximumForce number
local m = {}

UnityEngine.JointDrive = m
return m
