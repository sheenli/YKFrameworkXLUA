---@class UnityEngine.WSA.WindowActivationState : System.Enum
---@field public CodeActivated UnityEngine.WSA.WindowActivationState @static
---@field public Deactivated UnityEngine.WSA.WindowActivationState @static
---@field public PointerActivated UnityEngine.WSA.WindowActivationState @static
---@field public value__ number
local m = {}

UnityEngine.WSA.WindowActivationState = m
return m
