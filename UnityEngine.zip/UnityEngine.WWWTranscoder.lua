---@class UnityEngine.WWWTranscoder : System.Object
local m = {}

---@overload fun(toEncode:string, e:System.Text.Encoding):string @static
---@overload fun(toEncode:string):string @static
---@static
---@param toEncode string
---@return string
function m.URLEncode(toEncode) end

---@overload fun(toEncode:string, e:System.Text.Encoding):string @static
---@overload fun(toEncode:string):string @static
---@static
---@param toEncode string
---@return string
function m.QPEncode(toEncode) end

---@static
---@param input string
---@param escapeChar number
---@param space number
---@param forbidden string
---@param uppercase boolean
---@return string
function m.Encode(input, escapeChar, space, forbidden, uppercase) end

---@overload fun(toEncode:string, e:System.Text.Encoding):string @static
---@overload fun(toEncode:string):string @static
---@static
---@param toEncode string
---@return string
function m.URLDecode(toEncode) end

---@overload fun(toEncode:string, e:System.Text.Encoding):string @static
---@overload fun(toEncode:string):string @static
---@static
---@param toEncode string
---@return string
function m.QPDecode(toEncode) end

---@static
---@param input string
---@param escapeChar number
---@param space number
---@return string
function m.Decode(input, escapeChar, space) end

---@overload fun(s:string, e:System.Text.Encoding):boolean @static
---@overload fun(input:string):boolean @static
---@static
---@param s string
---@return boolean
function m.SevenBitClean(s) end

UnityEngine.WWWTranscoder = m
return m
