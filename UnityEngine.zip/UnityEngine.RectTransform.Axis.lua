---@class UnityEngine.RectTransform.Axis : System.Enum
---@field public Horizontal UnityEngine.RectTransform.Axis @static
---@field public Vertical UnityEngine.RectTransform.Axis @static
---@field public value__ number
local m = {}

UnityEngine.RectTransform.Axis = m
return m
