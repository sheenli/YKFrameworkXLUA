---@class UnityEngine.CompositeCollider2D.GeometryType : System.Enum
---@field public Outlines UnityEngine.CompositeCollider2D.GeometryType @static
---@field public Polygons UnityEngine.CompositeCollider2D.GeometryType @static
---@field public value__ number
local m = {}

UnityEngine.CompositeCollider2D.GeometryType = m
return m
