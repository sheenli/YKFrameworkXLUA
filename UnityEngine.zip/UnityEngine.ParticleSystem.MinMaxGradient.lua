---@class UnityEngine.ParticleSystem.MinMaxGradient : System.ValueType
---@field public mode UnityEngine.ParticleSystemGradientMode
---@field public gradientMax UnityEngine.Gradient
---@field public gradientMin UnityEngine.Gradient
---@field public colorMax UnityEngine.Color
---@field public colorMin UnityEngine.Color
---@field public color UnityEngine.Color
---@field public gradient UnityEngine.Gradient
local m = {}

---@overload fun(time:number, lerpFactor:number):UnityEngine.Color
---@param time number
---@return UnityEngine.Color
function m:Evaluate(time) end

---@overload fun(gradient:UnityEngine.Gradient):UnityEngine.ParticleSystem.MinMaxGradient @static
---@static
---@param color UnityEngine.Color
---@return UnityEngine.ParticleSystem.MinMaxGradient
function m.op_Implicit(color) end

UnityEngine.ParticleSystem.MinMaxGradient = m
return m
