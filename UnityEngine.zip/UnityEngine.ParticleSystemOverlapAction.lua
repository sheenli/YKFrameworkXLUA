---@class UnityEngine.ParticleSystemOverlapAction : System.Enum
---@field public Ignore UnityEngine.ParticleSystemOverlapAction @static
---@field public Kill UnityEngine.ParticleSystemOverlapAction @static
---@field public Callback UnityEngine.ParticleSystemOverlapAction @static
---@field public value__ number
local m = {}

UnityEngine.ParticleSystemOverlapAction = m
return m
